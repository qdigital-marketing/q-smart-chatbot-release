<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Plugin {
    private $settings;
    private $repository;

    public function __construct() {
        $this->settings = new WPSC_Settings_Service();
        $this->repository = new WPSC_Repository();
    }

    public function run() {
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('plugins_loaded', [$this, 'maybe_upgrade']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_filter('cron_schedules', [$this, 'cron_schedules']);
        add_action('wpsc_handover_timeout_check', [$this, 'process_handover_timeouts']);
        add_action('wpsc_media_retention_cleanup', [$this, 'process_media_retention']);
        add_action('init', [$this, 'ensure_scheduled_jobs']);

        if (is_admin()) {
            WPSC_Plugin_Updater::init();
            (new WPSC_Admin_Menu($this->settings, $this->repository))->register();
        }

        (new WPSC_Public_Assets($this->settings))->register();
    }

    public function load_textdomain() {
        load_plugin_textdomain('wp-smart-chatbot', false, dirname(plugin_basename(WPSC_PLUGIN_FILE)) . '/languages');
    }

    public function maybe_upgrade() {
        if (get_option('wpsc_db_version') !== WPSC_VERSION) {
            $settings = get_option(WPSC_Settings_Service::OPTION, []);
            if (is_array($settings)) {
                if (!isset($settings['handover_timeout']) || (string) $settings['handover_timeout'] === '60') {
                    $settings['handover_timeout'] = '900';
                }
                if (
                    !isset($settings['handover_connecting_message'])
                    || $settings['handover_connecting_message'] === 'I am trying to connect you to a representative now.'
                ) {
                    $settings['handover_connecting_message'] = 'Trying to connect you to support...';
                }
                update_option(WPSC_Settings_Service::OPTION, $settings);
            }
            WPSC_Schema::create_tables();
            WPSC_Settings_Service::ensure_defaults();
            WPSC_Schema::seed_defaults();
            update_option('wpsc_db_version', WPSC_VERSION);
        }
    }

    public function register_rest_routes() {
        $controller = new WPSC_REST_Controller(
            $this->settings,
            $this->repository,
            new WPSC_Chat_Service($this->settings, $this->repository)
        );
        $controller->register_routes();
    }

    public function cron_schedules($schedules) {
        if (!isset($schedules['wpsc_five_minutes'])) {
            $schedules['wpsc_five_minutes'] = [
                'interval' => 5 * MINUTE_IN_SECONDS,
                'display' => __('Every 5 minutes', 'wp-smart-chatbot'),
            ];
        }

        return $schedules;
    }

    public function ensure_scheduled_jobs() {
        if (!wp_next_scheduled('wpsc_handover_timeout_check')) {
            wp_schedule_event(time() + MINUTE_IN_SECONDS, 'wpsc_five_minutes', 'wpsc_handover_timeout_check');
        }

        if (!wp_next_scheduled('wpsc_media_retention_cleanup')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'wpsc_media_retention_cleanup');
        }
    }

    public function process_handover_timeouts() {
        (new WPSC_Chat_Service($this->settings, $this->repository))->process_handover_timeouts();
    }

    public function process_media_retention() {
        wpsc_clear_old_chat_media((int) $this->settings->get('media_retention_days', '30'));
    }
}
