(function () {
  'use strict';

  if (!window.WPSCWidget || !document.getElementById('wpsc-chatbot-root')) {
    return;
  }

  const root = document.getElementById('wpsc-chatbot-root');
  const storageKey = 'wpsc_session';
  const safeEmojiOptions = [0x1F642, 0x1F604, 0x1F602, 0x1F60A, 0x1F60D, 0x1F633, 0x1F61F, 0x1F624, 0x1F622, 0x1F62D, 0x1F389, 0x2764, 0x1F44C, 0x1F44D, 0x1F44E, 0x1F64F].map(function (code) {
    return String.fromCodePoint(code);
  });
  const state = {
    config: null,
    session: loadSession(),
    conversationId: null,
    lastMessageId: 0,
    open: false,
    polling: null,
    started: false,
    startPromise: null,
    unreadCount: 0,
    originalTitle: document.title,
    originalFaviconHref: '',
    titleFlipTimer: null,
    titleFlipShowAlert: false,
    morphExpandTimer: null,
    morphHandoffTimer: null,
    morphFadeTimer: null,
    morphHideTimer: null,
    handoverTimer: null,
    nudgeTimer: null,
    nudgeDismissed: false,
    feedbackSubmitted: false,
    pendingUpload: null,
    pollErrorShown: false
  };

  function loadSession() {
    try {
      return JSON.parse(localStorage.getItem(storageKey)) || {};
    } catch (error) {
      return {};
    }
  }

  function saveSession() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state.session));
    } catch (error) {
      // Storage may be unavailable (private browsing, blocked cookies). The chat
      // still works for this page view; the session just will not persist.
    }
  }

  function uuid(prefix) {
    if (window.crypto && crypto.randomUUID) {
      return prefix + '_' + crypto.randomUUID();
    }
    return prefix + '_' + Math.random().toString(36).slice(2) + Date.now();
  }

  function api(path, options) {
    const opts = options || {};
    opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    return fetch(WPSCWidget.restUrl + path, opts).then(function (response) {
      return response.json().then(function (json) {
        if (!response.ok) {
          throw new Error(json.message || 'Request failed');
        }
        return json;
      });
    });
  }

  function init() {
    api('/widget/config').then(function (config) {
      if (!config.enabled) {
        return;
      }
      state.config = config;
      state.originalFaviconHref = currentFaviconHref();
      renderShell();
    }).catch(function (error) {
      console.warn('Q Digital Chatbot config could not load:', error);
      root.innerHTML = '<button type="button" class="wpsc-bubble" aria-label="Chat unavailable"><span>!</span></button>';
      root.querySelector('.wpsc-bubble').addEventListener('click', function () {
        window.alert('The chatbot could not load right now. Please refresh the page or contact the site directly.');
      });
    });
  }

  function startSession() {
    state.session.session_id = state.session.session_id || uuid('sess');
    state.session.visitor_uuid = state.session.visitor_uuid || uuid('vis');
    saveSession();

    return api('/session/start', {
      method: 'POST',
      body: JSON.stringify({
        session_id: state.session.session_id,
        visitor_uuid: state.session.visitor_uuid,
        current_url: window.location.href,
        referrer: document.referrer
      })
    }).then(function (data) {
      state.session.session_id = data.session_id;
      state.session.visitor_uuid = data.visitor_uuid;
      state.conversationId = data.conversation.id;
      saveSession();
    });
  }

  function sessionPayload(extra) {
    return Object.assign({
      session_id: state.session.session_id,
      visitor_uuid: state.session.visitor_uuid
    }, extra || {});
  }

  function sessionQuery(extra) {
    return new URLSearchParams(sessionPayload(extra || {})).toString();
  }

  function mediaImagesAllowed() {
    return state.config.mediaUploadImagesEnabled !== false;
  }

  function mediaPdfsAllowed() {
    return state.config.mediaUploadPdfsEnabled !== false;
  }

  function isMediaUploadAvailable() {
    return !!state.config.mediaUploadsEnabled && (mediaImagesAllowed() || mediaPdfsAllowed());
  }

  function mediaAcceptTypes() {
    const types = [];
    if (mediaImagesAllowed()) {
      types.push('image/jpeg', 'image/png');
    }
    if (mediaPdfsAllowed()) {
      types.push('application/pdf');
    }
    return types.join(',');
  }

  function mediaAllowedDescription() {
    if (mediaImagesAllowed() && mediaPdfsAllowed()) {
      return 'JPG, PNG, and PDF files accepted. Max 5 MB.';
    }
    if (mediaImagesAllowed()) {
      return 'JPG and PNG images accepted. Max 5 MB.';
    }
    if (mediaPdfsAllowed()) {
      return 'PDF files accepted. Max 5 MB.';
    }
    return 'Uploads are currently unavailable.';
  }

  function isAllowedUploadFile(file) {
    if (!file) {
      return false;
    }
    if (mediaImagesAllowed() && /^(image\/jpeg|image\/png)$/.test(file.type)) {
      return true;
    }
    if (mediaPdfsAllowed() && (file.type === 'application/pdf' || /\.pdf$/i.test(file.name || ''))) {
      return true;
    }
    return false;
  }

  function renderShell() {
    root.innerHTML = [
      '<button class="wpsc-bubble" type="button" aria-label="Open chat"><span class="wpsc-bubble-ping" aria-hidden="true"></span><span class="wpsc-launcher-glyph" aria-hidden="true"><span class="wpsc-launcher-logo"></span><span class="wpsc-chat-icon"></span></span><span class="wpsc-launcher-dots" aria-hidden="true"><i></i><i></i><i></i></span><span class="wpsc-launcher-morph" aria-hidden="true"><svg viewBox="0 0 44 44"><g class="wpsc-morph-dots"><circle cx="12" cy="22" r="4"></circle><circle cx="22" cy="22" r="4"></circle><circle cx="32" cy="22" r="4"></circle></g><line class="wpsc-morph-shaft" x1="8" y1="22" x2="29" y2="22"></line><polyline class="wpsc-morph-head" points="15,15 8,22 15,29"></polyline></svg></span></button>',
      '<div class="wpsc-nudge" hidden><button class="wpsc-nudge-body" type="button"><span class="wpsc-mini-icon" aria-hidden="true"><span class="wpsc-chat-icon"></span></span><span class="wpsc-nudge-text"></span></button><button class="wpsc-nudge-close" type="button" aria-label="Dismiss message">&times;</button></div>',
      '<section class="wpsc-panel" aria-label="Chat" hidden>',
      '<header class="wpsc-header"><div class="wpsc-header-left"><button type="button" class="wpsc-header-back" aria-label="Minimise chat"><span aria-hidden="true">&larr;</span></button><button type="button" class="wpsc-top-menu wpsc-top-menu-left" aria-label="Chat options"><span aria-hidden="true">...</span></button></div><div class="wpsc-brand"><img class="wpsc-logo" alt="" hidden><div><strong></strong><span></span></div></div><p class="wpsc-header-status"></p><div class="wpsc-header-actions"><button type="button" class="wpsc-top-menu wpsc-top-menu-right" aria-label="Chat options"><span aria-hidden="true">...</span></button><button type="button" class="wpsc-minimize" aria-label="Minimise chat"><span aria-hidden="true">&minus;</span></button><button type="button" class="wpsc-close" aria-label="End chat"><span aria-hidden="true">&times;</span></button></div></header>',
      '<div class="wpsc-welcome" hidden><div class="wpsc-welcome-icon"><span class="wpsc-chat-icon"></span></div><h2></h2><p class="wpsc-welcome-subtitle"></p><div class="wpsc-welcome-card"><div class="wpsc-welcome-avatar">o</div><div><strong></strong><p></p></div></div><button type="button" class="wpsc-start-chat"></button></div>',
      '<div class="wpsc-chat-view">',
      '<div class="wpsc-messages"></div>',
      '<div class="wpsc-quick"></div>',
      '<div class="wpsc-emoji-picker" hidden aria-label="Emoji picker"></div>',
      '<div class="wpsc-media-menu" hidden><button class="wpsc-media-action wpsc-support-request" type="button"><strong>Submit support request</strong><span>Send the team your details and issue.</span></button><button class="wpsc-media-action wpsc-media-upload" type="button"><strong>Upload media</strong><span>JPG, PNG, and PDF files accepted. Max 5 MB.</span></button></div>',
      '<div class="wpsc-pending-upload" hidden></div>',
      '<form class="wpsc-composer"><button class="wpsc-attachment-toggle" type="button" aria-label="Add media">+</button><input class="wpsc-image-input" type="file" accept="image/jpeg,image/png,application/pdf" hidden><input name="message" autocomplete="off" placeholder="Write a message..."><button class="wpsc-emoji-toggle" type="button" aria-label="Choose emoji"><span class="wpsc-emoji-placeholder" aria-hidden="true"></span></button><button class="wpsc-send" type="submit" aria-label="Send message"><span>Send</span></button></form>',
      '<div class="wpsc-tools" hidden><button type="button" data-action="restart">Restart chat</button><button type="button" data-action="lead">Leave details</button><button type="button" data-action="handover">Speak to a person</button><button type="button" data-action="bug">Report a problem</button></div>',
      '</div>',
      '<div class="wpsc-feedback-view" hidden><div class="wpsc-feedback-body"><p class="wpsc-closed-note"></p><form class="wpsc-feedback-form"><div class="wpsc-feedback-card"><fieldset><legend><span class="wpsc-feedback-first-question"></span> <span aria-hidden="true">*</span></legend><label><input type="radio" name="first_time" value="yes" required> <span class="wpsc-feedback-yes-label"></span></label><label><input type="radio" name="first_time" value="no"> <span class="wpsc-feedback-no-label"></span></label></fieldset><fieldset><legend><span class="wpsc-feedback-resolved-question"></span> <span aria-hidden="true">*</span></legend><label><input type="radio" name="resolved" value="yes" required> <span class="wpsc-feedback-yes-label"></span></label><label><input type="radio" name="resolved" value="no"> <span class="wpsc-feedback-no-label"></span></label></fieldset><fieldset><legend><span class="wpsc-feedback-rating-question"></span> <span aria-hidden="true">*</span></legend><div class="wpsc-rating-options"><label><input type="radio" name="rating" value="positive" required><span aria-hidden="true">&#128077;</span><span class="wpsc-sr-only wpsc-feedback-positive-label"></span></label><label><input type="radio" name="rating" value="negative"><span aria-hidden="true">&#128078;</span><span class="wpsc-sr-only wpsc-feedback-negative-label"></span></label></div></fieldset><label class="wpsc-feedback-comment"><span class="wpsc-feedback-comment-label"></span><textarea name="comment" rows="3"></textarea></label><div class="wpsc-feedback-actions"><button class="wpsc-feedback-submit" type="submit"></button><button class="wpsc-feedback-skip" type="button"></button></div><p class="wpsc-feedback-status" role="status"></p></div></form></div></div>',
      '<div class="wpsc-close-confirm" hidden><div class="wpsc-close-dialog" role="dialog" aria-modal="true" aria-labelledby="wpsc-close-title"><button type="button" class="wpsc-close-confirm-x" aria-label="Dismiss close confirmation">&times;</button><div class="wpsc-close-icon" aria-hidden="true"><span></span></div><p id="wpsc-close-title" class="wpsc-close-confirm-title"></p><button type="button" class="wpsc-close-confirm-button"></button></div></div>',
      '</section>'
    ].join('');

    root.style.setProperty('--wpsc-primary', state.config.primaryColor);
    root.style.setProperty('--wpsc-secondary', state.config.secondaryColor);
    root.style.setProperty('--wpsc-text', state.config.textColor);
    root.style.setProperty('--wpsc-bg', state.config.backgroundColor);
    root.style.setProperty('--wpsc-launcher', state.config.launcherColor || state.config.primaryColor);
    root.style.setProperty('--wpsc-carousel-button-bg', state.config.carouselButtonBgColor || state.config.primaryColor);
    root.style.setProperty('--wpsc-carousel-button-text', state.config.carouselButtonTextColor || '#ffffff');
    root.style.setProperty('--wpsc-carousel-button-radius', Number(state.config.carouselButtonRadius || 2) + 'px');
    const logoSize = Math.max(24, Math.min(96, Number(state.config.chatHeaderLogoSize || 38)));
    const logoWidth = state.config.chatHeaderLogoShape === 'rectangle' ? Math.round(logoSize * 1.9) : logoSize;
    root.style.setProperty('--wpsc-header-logo-size', logoSize + 'px');
    root.style.setProperty('--wpsc-header-logo-width', logoWidth + 'px');
    root.classList.add('wpsc-modern-launcher');
    root.classList.toggle('wpsc-left', state.config.position === 'left');
    root.classList.toggle(
      'wpsc-business-online',
      !!state.config.businessHoursEnabled && !!state.config.isBusinessOnline
    );
    root.classList.toggle('wpsc-media-disabled', !state.config.mediaUploadsEnabled);
    root.classList.toggle('wpsc-media-upload-disabled', !isMediaUploadAvailable());
    root.classList.toggle('wpsc-launcher-logo-mode', state.config.launcherIconStyle === 'logo' && !!state.config.headerLogoUrl);
    root.classList.toggle('wpsc-launcher-dots-mode', state.config.launcherIconStyle === 'dots');
    const headerStyle = ['brand_bar', 'floating_pill', 'compact_center'].indexOf(state.config.chatHeaderStyle) !== -1 ? state.config.chatHeaderStyle : 'brand_bar';
    const logoShape = ['circle', 'square', 'rounded_square', 'rectangle'].indexOf(state.config.chatHeaderLogoShape) !== -1 ? state.config.chatHeaderLogoShape : 'rounded_square';
    root.classList.add('wpsc-header-' + headerStyle);
    root.classList.add('wpsc-logo-shape-' + logoShape);
    root.classList.add('wpsc-logo-fit-' + (state.config.chatHeaderLogoFit === 'cover' ? 'cover' : 'contain'));
    root.classList.toggle('wpsc-header-hide-name', state.config.chatHeaderShowName === false);
    root.classList.toggle('wpsc-header-hide-status', state.config.chatHeaderShowStatus === false);
    root.querySelector('.wpsc-header strong').textContent = state.config.botName;
    root.querySelector('.wpsc-brand span').textContent = state.config.businessStatusText || state.config.businessName;
    root.querySelector('.wpsc-header-status').textContent = state.config.businessStatusText || state.config.businessName;
    root.querySelector('.wpsc-nudge-text').textContent = state.config.welcomeNudgeText || state.config.greeting;
    root.querySelector('.wpsc-welcome h2').textContent = state.config.welcomeScreenTitle || 'Welcome!';
    root.querySelector('.wpsc-welcome-subtitle').textContent = state.config.welcomeScreenSubtitle || 'Text us';
    root.querySelector('.wpsc-welcome-card strong').textContent = state.config.welcomeScreenCardTitle || state.config.botName || 'Assistant';
    root.querySelector('.wpsc-welcome-card p').textContent = state.config.welcomeScreenMessage || state.config.greeting;
    root.querySelector('.wpsc-start-chat').textContent = state.config.welcomeScreenButtonText || "Let's chat";
    root.querySelector('.wpsc-closed-note').textContent = state.config.feedbackClosedNote || 'You have closed the chat.';
    root.querySelector('.wpsc-feedback-first-question').textContent = state.config.feedbackFirstQuestion || 'Is this the first time you have chatted with us about this case?';
    root.querySelector('.wpsc-feedback-resolved-question').textContent = state.config.feedbackResolvedQuestion || 'Was the case resolved during the chat?';
    root.querySelector('.wpsc-feedback-rating-question').textContent = state.config.feedbackRatingQuestion || 'How would you rate this chat?';
    root.querySelector('.wpsc-feedback-comment-label').textContent = state.config.feedbackCommentLabel || 'Anything else we should know?';
    root.querySelectorAll('.wpsc-feedback-yes-label').forEach(function (label) { label.textContent = state.config.feedbackYesLabel || 'Yes'; });
    root.querySelectorAll('.wpsc-feedback-no-label').forEach(function (label) { label.textContent = state.config.feedbackNoLabel || 'No'; });
    root.querySelector('.wpsc-feedback-positive-label').textContent = state.config.feedbackPositiveLabel || 'Positive';
    root.querySelector('.wpsc-feedback-negative-label').textContent = state.config.feedbackNegativeLabel || 'Negative';
    root.querySelector('.wpsc-feedback-submit').textContent = state.config.feedbackSubmitLabel || 'Submit';
    root.querySelector('.wpsc-feedback-skip').textContent = state.config.feedbackSkipLabel || 'Skip';
    root.querySelector('.wpsc-close-confirm-title').textContent = state.config.feedbackConfirmTitle || 'Do you really want to close the chat?';
    root.querySelector('.wpsc-close-confirm-button').textContent = state.config.feedbackConfirmButtonLabel || 'Close the chat';
    root.querySelector('.wpsc-image-input').setAttribute('accept', mediaAcceptTypes());
    root.querySelector('.wpsc-media-upload span').textContent = mediaAllowedDescription();
    const logo = root.querySelector('.wpsc-logo');
    if (state.config.headerLogoUrl) {
      logo.src = state.config.headerLogoUrl;
      logo.hidden = false;
      const launcherLogo = root.querySelector('.wpsc-launcher-logo');
      launcherLogo.style.backgroundImage = 'url("' + state.config.headerLogoUrl.replace(/"/g, '%22') + '")';
    }

    root.querySelector('.wpsc-bubble').addEventListener('click', openPanel);
    root.querySelector('.wpsc-nudge-body').addEventListener('click', openPanel);
    root.querySelector('.wpsc-nudge-close').addEventListener('click', dismissNudge);
    root.querySelector('.wpsc-start-chat').addEventListener('click', beginChat);
    root.querySelector('.wpsc-header-back').addEventListener('click', minimizePanel);
    root.querySelector('.wpsc-minimize').addEventListener('click', minimizePanel);
    root.querySelector('.wpsc-close').addEventListener('click', closePanel);
    root.querySelector('.wpsc-close-confirm-x').addEventListener('click', hideCloseConfirm);
    root.querySelector('.wpsc-close-confirm-button').addEventListener('click', confirmClosePanel);
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && state.open) {
        if (isCloseConfirmVisible()) {
          hideCloseConfirm();
          return;
        }
        minimizePanel();
      }
    });
    root.querySelector('.wpsc-composer').addEventListener('submit', sendMessage);
    root.querySelectorAll('.wpsc-top-menu').forEach(function (button) {
      button.addEventListener('click', toggleMenu);
    });
    root.querySelector('.wpsc-attachment-toggle').addEventListener('click', toggleMediaMenu);
    root.querySelector('.wpsc-support-request').addEventListener('click', requestSupportForm);
    root.querySelector('.wpsc-media-upload').addEventListener('click', openImagePicker);
    root.querySelector('.wpsc-image-input').addEventListener('change', uploadSelectedImage);
    root.querySelector('.wpsc-emoji-toggle').addEventListener('click', toggleEmojiPicker);
    root.querySelector('.wpsc-feedback-form').addEventListener('submit', submitFeedback);
    root.querySelector('.wpsc-feedback-skip').addEventListener('click', skipFeedback);
    root.querySelectorAll('.wpsc-tools button').forEach(function (button) {
      button.addEventListener('click', handleTool);
    });
    renderEmojiPicker();

    const autoOpenDelay = Math.max(0, Number(state.config.autoOpenDelay || 0));
    if (autoOpenDelay > 0) {
      window.setTimeout(function () {
        if (!state.open) {
          openPanel();
        }
      }, autoOpenDelay);
    }
    scheduleNudge();
  }

  var MORPH_MS = 1540;
  var MORPH_EXPAND_AT = 550;
  var MORPH_HANDOFF_AT = 860;
  var MORPH_FADE_AT = 1220;
  var CLOSE_TO_LINE_MS = 500;
  var SETTLE_MS = 600;

  function clearMorphTimers() {
    if (state.morphExpandTimer) {
      window.clearTimeout(state.morphExpandTimer);
      state.morphExpandTimer = null;
    }
    if (state.morphHandoffTimer) {
      window.clearTimeout(state.morphHandoffTimer);
      state.morphHandoffTimer = null;
    }
    if (state.morphFadeTimer) {
      window.clearTimeout(state.morphFadeTimer);
      state.morphFadeTimer = null;
    }
    if (state.morphHideTimer) {
      window.clearTimeout(state.morphHideTimer);
      state.morphHideTimer = null;
    }
  }

  function openPanel() {
    state.open = true;
    state.unreadCount = 0;
    hideNudge();
    updateBadge();
    const panel = root.querySelector('.wpsc-panel');
    const bubble = root.querySelector('.wpsc-bubble');
    clearMorphTimers();
    root.classList.remove('wpsc-closing');
    root.classList.remove('wpsc-settling');
    root.classList.remove('wpsc-opening-welcome');
    root.classList.remove('wpsc-handoff');
    root.classList.remove('wpsc-handoff-fade');
    bubble.classList.remove('wpsc-bubble-leaving');
    panel.hidden = false;
    bubble.hidden = false;
    const openingWelcome = state.config.welcomeScreenEnabled && !state.started;
    // The first-time welcome screen only waves the dots. Once a conversation
    // exists, reopening the main chat keeps the full dots-to-arrow morph.
    root.classList.add(openingWelcome ? 'wpsc-opening-welcome' : 'wpsc-opening');
    state.morphExpandTimer = window.setTimeout(function () {
      if (state.open) {
        root.classList.add('wpsc-open');
      }
    }, MORPH_EXPAND_AT);
    if (!openingWelcome) {
      state.morphHandoffTimer = window.setTimeout(function () {
        if (state.open) {
          root.classList.add('wpsc-handoff');
        }
      }, MORPH_HANDOFF_AT);
      state.morphFadeTimer = window.setTimeout(function () {
        if (state.open) {
          root.classList.add('wpsc-handoff-fade');
        }
      }, MORPH_FADE_AT);
    }
    state.morphHideTimer = window.setTimeout(function () {
      root.classList.remove('wpsc-opening');
      root.classList.remove('wpsc-opening-welcome');
      root.classList.remove('wpsc-handoff');
      root.classList.remove('wpsc-handoff-fade');
      if (state.open) {
        bubble.hidden = true;
      }
    }, MORPH_MS);

    if (openingWelcome) {
      showWelcomeScreen();
      return;
    }
    beginChat();
  }

  function minimizePanel() {
    hideCloseConfirm();
    finishClosePanel();
  }

  function closePanel() {
    if (state.config.feedbackConfirmCloseEnabled !== false && !isFeedbackVisible()) {
      showCloseConfirm();
      return;
    }
    confirmClosePanel();
  }

  function confirmClosePanel() {
    hideCloseConfirm();
    if (isFeedbackVisible()) {
      skipFeedback();
      return;
    }
    if (shouldShowFeedbackSurvey()) {
      showFeedbackSurvey();
      return;
    }
    finishClosePanel();
  }

  function showCloseConfirm() {
    hideMenu();
    hideEmojiPicker();
    hideMediaMenu();
    const confirm = root.querySelector('.wpsc-close-confirm');
    if (confirm) {
      confirm.hidden = false;
      const button = confirm.querySelector('.wpsc-close-confirm-button');
      if (button) {
        button.focus();
      }
    }
  }

  function hideCloseConfirm() {
    const confirm = root.querySelector('.wpsc-close-confirm');
    if (confirm) {
      confirm.hidden = true;
    }
  }

  function isCloseConfirmVisible() {
    const confirm = root.querySelector('.wpsc-close-confirm');
    return !!(confirm && !confirm.hidden);
  }

  function finishClosePanel() {
    hideCloseConfirm();
    state.open = false;
    const panel = root.querySelector('.wpsc-panel');
    const bubble = root.querySelector('.wpsc-bubble');
    clearMorphTimers();
    root.classList.remove('wpsc-opening');
    root.classList.remove('wpsc-opening-welcome');
    root.classList.remove('wpsc-handoff');
    root.classList.remove('wpsc-handoff-fade');
    root.classList.remove('wpsc-open');
    root.classList.remove('wpsc-settling');
    bubble.classList.remove('wpsc-bubble-leaving');
    bubble.hidden = false;
    // Phase 1: the up arrow rotates back to a left arrow and the head retracts,
    // collapsing to a line, while the panel shrinks into the corner.
    root.classList.add('wpsc-closing');
    state.morphExpandTimer = window.setTimeout(function () {
      // Phase 2: hide the panel, then hand the line off to the message icon,
      // which fades in and rocks back and forth to settle.
      if (!state.open) {
        panel.hidden = true;
      }
      root.classList.remove('wpsc-closing');
      root.classList.add('wpsc-settling');
      state.morphHideTimer = window.setTimeout(function () {
        root.classList.remove('wpsc-settling');
      }, SETTLE_MS);
    }, CLOSE_TO_LINE_MS);

    updateBadge();
    if (state.started && state.conversationId) {
      startPolling();
    }
  }

  function showWelcomeScreen() {
    root.querySelector('.wpsc-welcome').hidden = false;
    root.querySelector('.wpsc-chat-view').hidden = true;
    root.querySelector('.wpsc-feedback-view').hidden = true;
  }

  function showChatView() {
    root.querySelector('.wpsc-welcome').hidden = true;
    root.querySelector('.wpsc-chat-view').hidden = false;
    root.querySelector('.wpsc-feedback-view').hidden = true;
  }

  function beginChat() {
    showChatView();
    ensureStarted().then(function () {
      startPolling();
      track('widget_opened');
    });
  }

  function scheduleNudge() {
    if (!state.config.welcomeNudgeEnabled || state.nudgeDismissed || state.session.nudge_dismissed) {
      return;
    }
    const delay = Math.max(0, Number(state.config.welcomeNudgeDelay || 0));
    if (!delay) {
      return;
    }
    state.nudgeTimer = window.setTimeout(function () {
      if (!state.open && !state.nudgeDismissed) {
        root.querySelector('.wpsc-nudge').hidden = false;
        root.classList.add('wpsc-nudge-visible');
      }
    }, delay);
  }

  function hideNudge() {
    if (state.nudgeTimer) {
      window.clearTimeout(state.nudgeTimer);
      state.nudgeTimer = null;
    }
    const nudge = root.querySelector('.wpsc-nudge');
    if (nudge) {
      root.classList.remove('wpsc-nudge-visible');
      nudge.hidden = true;
    }
  }

  function dismissNudge(event) {
    if (event) {
      event.stopPropagation();
    }
    state.nudgeDismissed = true;
    state.session.nudge_dismissed = true;
    saveSession();
    hideNudge();
  }

  function ensureStarted() {
    if (state.started) {
      return state.startPromise || Promise.resolve();
    }

    state.started = true;
    state.startPromise = startSession().then(function () {
      addMessage('bot', state.config.isBusinessOnline ? state.config.greeting : state.config.offlineGreeting);
      if (!state.config.isBusinessOnline && state.config.offlineAutoFormEnabled) {
        showLeadForm('lead');
      }
      renderQuickReplies(state.config.quickReplies || []);
      startPolling();
    }).catch(function () {
      addMessage('bot', state.config.fallbackMessage);
    });
    return state.startPromise;
  }

  function addMessage(sender, body, id, metadata) {
    if (metadata && (metadata.file_url || metadata.image_url)) {
      addFileMessage(sender, metadata.file_url || metadata.image_url, id, metadata.file_name || body || 'Attachment', metadata.attachment_type || (metadata.image_url ? 'image' : 'file'));
      return;
    }
    const messages = root.querySelector('.wpsc-messages');
    if (id && messages.querySelector('[data-id="' + id + '"]')) {
      return;
    }
    const item = document.createElement('div');
    item.className = 'wpsc-msg wpsc-msg-' + sender;
    if (id) {
      item.dataset.id = id;
      state.lastMessageId = Math.max(state.lastMessageId, Number(id));
    }
    if (sender === 'agent') {
      const agentName = (metadata && metadata.agent_name) || state.config.agentDisplayName || 'Customer Support Team';
      if (state.config.agentNameMode !== 'hidden' && agentName) {
        const label = document.createElement('span');
        label.className = 'wpsc-agent-label';
        label.textContent = agentName;
        item.appendChild(label);
      }
      const text = document.createElement('span');
      text.className = 'wpsc-message-text';
      text.textContent = body || '';
      item.appendChild(text);
    } else {
      item.textContent = body || '';
    }
    messages.appendChild(item);
    messages.scrollTop = messages.scrollHeight;
  }

  function isSafeUrl(url) {
    try {
      const parsed = new URL(String(url || ''), window.location.href);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:' || parsed.protocol === 'blob:';
    } catch (error) {
      return false;
    }
  }

  function addFileMessage(sender, url, id, label, attachmentType) {
    const messages = root.querySelector('.wpsc-messages');
    if (id && messages.querySelector('[data-id="' + id + '"]')) {
      return;
    }
    if (!isSafeUrl(url)) {
      return;
    }
    const item = document.createElement('div');
    const type = attachmentType === 'image' ? 'image' : 'file';
    item.className = 'wpsc-msg wpsc-msg-' + sender + ' wpsc-msg-' + type;
    if (id) {
      item.dataset.id = id;
      state.lastMessageId = Math.max(state.lastMessageId, Number(id));
    }
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    if (type === 'image') {
      const image = document.createElement('img');
      image.src = url;
      image.alt = label || 'Uploaded image';
      link.appendChild(image);
    } else {
      const badge = document.createElement('span');
      badge.className = 'wpsc-file-badge';
      badge.textContent = 'PDF';
      const text = document.createElement('span');
      text.textContent = label || 'PDF attachment';
      link.appendChild(badge);
      link.appendChild(text);
    }
    item.appendChild(link);
    messages.appendChild(item);
    messages.scrollTop = messages.scrollHeight;
  }

  function addTyping() {
    const typing = document.createElement('div');
    typing.className = 'wpsc-msg wpsc-msg-bot wpsc-typing';
    typing.setAttribute('role', 'status');
    typing.setAttribute('aria-label', 'Typing');
    for (let i = 0; i < 3; i++) {
      typing.appendChild(document.createElement('i'));
    }
    const messages = root.querySelector('.wpsc-messages');
    messages.appendChild(typing);
    messages.scrollTop = messages.scrollHeight;
    return typing;
  }

  function updateLiveTyping(typingState) {
    const messages = root.querySelector('.wpsc-messages');
    if (!messages) {
      return;
    }

    let wrap = messages.querySelector('.wpsc-live-typing');
    if (!typingState || !typingState.active) {
      if (wrap) {
        wrap.remove();
      }
      return;
    }

    // An active support heartbeat means the connection succeeded. Keep the
    // fallback deadline 15 minutes beyond the most recent typing activity.
    scheduleHandoverFallback();

    const agentName = String(typingState.agent_name || state.config.agentDisplayName || 'Customer Support Team').trim();
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'wpsc-live-typing';
      wrap.setAttribute('role', 'status');
      wrap.setAttribute('aria-live', 'polite');

      const bubble = document.createElement('div');
      bubble.className = 'wpsc-msg wpsc-msg-bot wpsc-typing';
      bubble.setAttribute('aria-hidden', 'true');
      for (let i = 0; i < 3; i++) {
        bubble.appendChild(document.createElement('i'));
      }

      const caption = document.createElement('p');
      caption.className = 'wpsc-live-typing-text';
      wrap.appendChild(bubble);
      wrap.appendChild(caption);
      messages.appendChild(wrap);
    }

    wrap.querySelector('.wpsc-live-typing-text').textContent = agentName + ' is writing a reply';
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
  }

  function typingDelayMs() {
    return Math.max(0, Math.min(10000, Number((state.config && state.config.typingDelay) || 0)));
  }

  function afterTypingDelay(startTime, callback) {
    const remaining = Math.max(0, typingDelayMs() - (Date.now() - startTime));
    window.setTimeout(callback, remaining);
  }

  function renderQuickReplies(replies) {
    const wrap = root.querySelector('.wpsc-quick');
    wrap.innerHTML = '';
    wrap.className = 'wpsc-quick';
    if (!replies.length) {
      return;
    }

    const display = replies[0].display === 'cards' ? 'cards' : 'bubbles';
    wrap.classList.add(display === 'cards' ? 'wpsc-quick-cards' : 'wpsc-quick-bubbles');

    replies.forEach(function (reply) {
      const button = document.createElement('button');
      button.type = 'button';
      if (display === 'cards') {
        button.className = 'wpsc-option-card';
        const cardStyle = (reply.card_style || state.config.cardDefaultStyle) === 'cover' ? 'cover' : 'split';
        const textPosition = (reply.card_text_position || state.config.cardDefaultTextPosition) === 'center' ? 'center' : 'bottom';
        const imageShape = ['landscape', 'square', 'portrait'].indexOf(reply.card_image_shape || state.config.cardDefaultImageShape) !== -1 ? (reply.card_image_shape || state.config.cardDefaultImageShape) : 'square';
        const opacityValue = reply.card_overlay_opacity !== undefined && reply.card_overlay_opacity !== null ? reply.card_overlay_opacity : state.config.cardDefaultOverlayOpacity;
        const opacity = Math.max(0, Math.min(100, Number(opacityValue || 88))) / 100;
        const textColor = reply.card_text_color || state.config.cardDefaultTextColor || '#ffffff';
        const labelBackground = reply.card_label_background_color || state.config.cardDefaultBackgroundColor || '#111827';
        const background = hexToRgba(labelBackground, opacity);
        button.classList.add('wpsc-card-' + cardStyle, 'wpsc-card-shape-' + imageShape, 'wpsc-card-text-' + textPosition);
        button.style.setProperty('--wpsc-card-text', textColor);
        button.style.setProperty('--wpsc-card-label-bg', background);
        if (reply.image) {
          const img = document.createElement('img');
          img.src = reply.image;
          img.alt = '';
          button.appendChild(img);
        } else {
          const placeholder = document.createElement('span');
          placeholder.className = 'wpsc-card-placeholder';
          button.appendChild(placeholder);
        }
        const span = document.createElement('span');
        span.textContent = reply.label;
        button.appendChild(span);
      } else {
        button.textContent = reply.label;
      }
      button.addEventListener('click', function () {
        sendQuickReply(reply);
      });
      wrap.appendChild(button);
    });
  }

  function hexToRgba(hex, opacity) {
    const clean = String(hex || '').replace('#', '').trim();
    const full = clean.length === 3 ? clean.split('').map(function (char) { return char + char; }).join('') : clean;
    if (!/^[0-9a-f]{6}$/i.test(full)) {
      return 'rgba(17, 24, 39, ' + opacity + ')';
    }
    return 'rgba(' + parseInt(full.slice(0, 2), 16) + ', ' + parseInt(full.slice(2, 4), 16) + ', ' + parseInt(full.slice(4, 6), 16) + ', ' + opacity + ')';
  }

  function sendMessage(event) {
    event.preventDefault();
    const input = event.currentTarget.elements.message;
    const message = input.value.trim();
    if (state.pendingUpload) {
      confirmPendingUpload(message);
      return;
    }
    if (!message) {
      return;
    }
    input.value = '';
    input.focus();
    deliverMessage(message);
  }

  function deliverMessage(message) {
    ensureStarted().then(function () {
      hideMenu();
      hideEmojiPicker();
      hideMediaMenu();
      renderQuickReplies([]);
      addMessage('visitor', message);
      const typing = addTyping();
      const typingStartedAt = Date.now();

      api('/chat/message', {
        method: 'POST',
        body: JSON.stringify(sessionPayload({
          conversation_id: state.conversationId,
          message: message,
          current_url: window.location.href,
          metadata: {
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            screen_width: window.innerWidth
          }
        }))
      }).then(function (data) {
        afterTypingDelay(typingStartedAt, function () {
          typing.remove();
          state.conversationId = data.conversation_id;
          ingestMessages(data.messages || []);
          renderQuickReplies(data.quick_replies || []);
        });
      }).catch(function (error) {
        afterTypingDelay(typingStartedAt, function () {
          typing.remove();
          addMessage('bot', error.message || state.config.fallbackMessage);
        });
      })
    });
  }

  function sendQuickReply(reply) {
    ensureStarted().then(function () {
      hideMenu();
      renderQuickReplies([]);
      addMessage('visitor', reply.label);
      if (!isFormAction(reply.action)) {
        hideLeadForm();
      }
      const pendingUrl = getReplyUrl(reply);
      const typing = addTyping();
      const typingStartedAt = Date.now();

      api('/chat/quick-reply', {
        method: 'POST',
        body: JSON.stringify(sessionPayload({
          conversation_id: state.conversationId,
          canned_response_id: reply.id,
          label: reply.label,
          inline_response: reply.id ? null : reply,
          current_url: window.location.href
        }))
      }).then(function (data) {
        afterTypingDelay(typingStartedAt, function () {
          typing.remove();
          state.conversationId = data.conversation_id;
          ingestMessages(data.messages || []);
          renderQuickReplies(data.quick_replies || []);
          if (reply.action === 'open_url' && pendingUrl) {
            window.open(pendingUrl, '_blank', 'noopener');
          }
        });
      }).catch(function (error) {
        afterTypingDelay(typingStartedAt, function () {
          typing.remove();
          addMessage('bot', error.message || state.config.fallbackMessage);
        });
      })
    });
  }

  function getReplyUrl(reply) {
    const payload = reply.payload || {};
    const value = payload.url || payload.target_url || payload.button_url || payload.response_text || reply.response_text || '';
    const match = String(value).match(/https?:\/\/[^\s<>"']+/i);
    return match ? match[0] : '';
  }

  function playNotificationSound() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const now = ctx.currentTime;
      
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc1.frequency.exponentialRampToValueAtTime(880.00, now + 0.1); // A5
      gain1.gain.setValueAtTime(0.15, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.25);
      
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880.00, now + 0.08); // A5
      osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.18); // D6
      gain2.gain.setValueAtTime(0.15, now + 0.08);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.35);
    } catch (e) {
      console.warn('Audio play blocked or failed:', e);
    }
  }

  function updateBadge() {
    const bubble = root.querySelector('.wpsc-bubble');
    if (!bubble) return;
    let badge = bubble.querySelector('.wpsc-badge');
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'wpsc-badge';
      bubble.appendChild(badge);
    }
    if (state.unreadCount > 0) {
      badge.textContent = state.unreadCount;
      badge.hidden = false;
    } else {
      badge.hidden = true;
    }
    updateTabNotification();
  }

  function unreadTitleText() {
    const count = Number(state.unreadCount || 0);
    return '💬 ' + count + ' new ' + (count === 1 ? 'message' : 'messages');
  }

  function startTitleFlip() {
    if (state.titleFlipTimer) {
      return;
    }
    state.titleFlipShowAlert = true;
    document.title = unreadTitleText();
    state.titleFlipTimer = window.setInterval(function () {
      if (Number(state.unreadCount || 0) <= 0) {
        stopTitleFlip();
        return;
      }
      state.titleFlipShowAlert = !state.titleFlipShowAlert;
      document.title = state.titleFlipShowAlert ? unreadTitleText() : state.originalTitle;
    }, 1300);
  }

  function stopTitleFlip() {
    if (state.titleFlipTimer) {
      window.clearInterval(state.titleFlipTimer);
      state.titleFlipTimer = null;
    }
    state.titleFlipShowAlert = false;
    document.title = state.originalTitle;
  }

  function updateTabNotification() {
    const count = Number(state.unreadCount || 0);
    if (count > 0) {
      startTitleFlip();
      setBadgeFavicon(count);
      return;
    }

    stopTitleFlip();
    restoreFavicon();
  }

  function currentFaviconHref() {
    const icon = document.querySelector('link[rel~="icon"]');
    return icon ? icon.href : '';
  }

  function faviconLink() {
    let icon = document.querySelector('link[rel~="icon"]');
    if (!icon) {
      icon = document.createElement('link');
      icon.rel = 'icon';
      document.head.appendChild(icon);
    }
    return icon;
  }

  function setBadgeFavicon(count) {
    const label = count > 9 ? '9+' : String(count);
    const svg = [
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">',
      '<rect width="64" height="64" rx="12" fill="#111827"/>',
      '<circle cx="44" cy="20" r="18" fill="#d63638"/>',
      '<text x="44" y="26" text-anchor="middle" font-family="Arial,sans-serif" font-size="' + (label.length > 1 ? '18' : '24') + '" font-weight="700" fill="#fff">' + label + '</text>',
      '<path d="M14 42h24l9 8v-8h3c3 0 5-2 5-5V18c0-3-2-5-5-5H14c-3 0-5 2-5 5v19c0 3 2 5 5 5z" fill="#fff" opacity=".92"/>',
      '</svg>'
    ].join('');
    faviconLink().href = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  function restoreFavicon() {
    const icon = document.querySelector('link[rel~="icon"]');
    if (!state.originalFaviconHref) {
      if (icon && icon.href.indexOf('data:image/svg+xml') === 0) {
        icon.remove();
      }
      return;
    }
    faviconLink().href = state.originalFaviconHref;
  }

  function ingestMessages(messages, includeVisitor) {
    let newUnreadCount = 0;
    messages.forEach(function (message) {
      if (message.id) {
        state.lastMessageId = Math.max(state.lastMessageId, Number(message.id));
      }
      if ((message.sender_type === 'visitor' && !includeVisitor) || message.sender_type === 'system' || Number(message.is_private_note || 0) === 1) {
        return;
      }

      if (message.sender_type === 'agent') {
        clearHandoverFallback();
        updateLiveTyping({ active: false });
      }
      
      const messagesContainer = root.querySelector('.wpsc-messages');
      const isDuplicate = message.id && messagesContainer && messagesContainer.querySelector('[data-id="' + message.id + '"]');
      
      const metadata = safeJson(message.metadata);
      addMessage(message.sender_type, message.body, message.id, metadata);

      if (!isDuplicate && !state.open && (message.sender_type === 'agent' || message.sender_type === 'bot')) {
        newUnreadCount++;
      }

      if (!isDuplicate && metadata.action_type === 'handover') {
        scheduleHandoverFallback();
      }
      if (!isDuplicate && metadata.content_element && metadata.content_element.type === 'slideshow') {
        renderSlideshow(metadata.content_element, message.id);
      }
      if (!isDuplicate && metadata.action_type === 'ask_contact' && !isCompletedFormMessage(message.id)) {
        showLeadForm(metadata.form_type || 'lead', message.id, metadata.custom_form || null);
      }
    });

    if (newUnreadCount > 0) {
      state.unreadCount = (state.unreadCount || 0) + newUnreadCount;
      updateBadge();
      playNotificationSound();
    }
  }

  function safeJson(value) {
    if (!value) {
      return {};
    }
    if (typeof value === 'object') {
      return value;
    }
    try {
      return JSON.parse(value);
    } catch (error) {
      return {};
    }
  }

  function isFormAction(action) {
    return ['ask_contact', 'ask_lead', 'ask_order', 'ask_service', 'ask_booking', 'ask_accommodation', 'ask_finance', 'ask_support'].indexOf(action) !== -1 || String(action || '').indexOf('ask_custom_') === 0;
  }

  function formTypeFromAction(action) {
    const map = {
      ask_contact: 'lead',
      ask_lead: 'lead',
      ask_order: 'order',
      ask_service: 'service',
      ask_booking: 'booking',
      ask_accommodation: 'accommodation',
      ask_finance: 'finance',
      ask_support: 'support'
    };
    return map[action] || 'lead';
  }

  function isCompletedFormMessage(messageId) {
    if (!messageId) {
      return false;
    }
    const completed = (state.session.completed_form_messages || []).map(Number);
    return completed.indexOf(Number(messageId)) !== -1;
  }

  function markFormMessageCompleted(messageId) {
    if (!messageId) {
      return;
    }
    const completed = (state.session.completed_form_messages || []).map(Number);
    const numericId = Number(messageId);
    if (completed.indexOf(numericId) === -1) {
      completed.push(numericId);
    }
    state.session.completed_form_messages = completed.slice(-25);
    saveSession();
  }

  function showCustomLeadForm(customForm, triggerMessageId) {
    hideLeadForm();
    const wrap = document.createElement('div');
    wrap.className = 'wpsc-msg wpsc-msg-bot wpsc-lead-card';
    if (triggerMessageId) {
      wrap.dataset.triggerMessageId = String(triggerMessageId);
    }

    const form = document.createElement('form');
    form.className = 'wpsc-lead';
    form.dataset.formType = 'custom';
    form.dataset.serviceInterest = customForm.service_interest || customForm.name || 'Custom enquiry';

    const title = document.createElement('div');
    title.className = 'wpsc-form-title';
    title.textContent = customForm.name || 'Details';
    form.appendChild(title);

    (customForm.fields || []).forEach(function (field) {
      const key = field.key || field.label || '';
      if (!key) {
        return;
      }
      let control;
      if (field.type === 'textarea') {
        control = document.createElement('textarea');
      } else if (field.type === 'select') {
        control = document.createElement('select');
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = field.placeholder || field.label || 'Choose an option';
        control.appendChild(empty);
        (field.options || []).forEach(function (optionLabel) {
          const option = document.createElement('option');
          option.value = optionLabel;
          option.textContent = optionLabel;
          control.appendChild(option);
        });
      } else {
        control = document.createElement('input');
        control.type = ['email', 'tel', 'date', 'number'].indexOf(field.type) !== -1 ? field.type : 'text';
      }
      control.name = key;
      control.placeholder = field.placeholder || field.label || '';
      control.required = field.required === '1' || field.required === true;
      control.dataset.customFieldLabel = field.label || key;
      control.dataset.customFieldType = field.type || 'text';
      form.appendChild(control);
    });

    const button = document.createElement('button');
    button.type = 'submit';
    button.textContent = customForm.submit_label || 'Send details';
    form.appendChild(button);
    form.addEventListener('submit', submitLead);

    wrap.appendChild(form);
    root.querySelector('.wpsc-messages').appendChild(wrap);
    root.querySelector('.wpsc-messages').scrollTop = root.querySelector('.wpsc-messages').scrollHeight;
    const first = wrap.querySelector('input, select, textarea');
    if (first) {
      first.focus();
    }
  }

  function renderSlideshow(element, messageId) {
    if (!element || !element.slides || !element.slides.length) {
      return;
    }
    const messages = root.querySelector('.wpsc-messages');
    const key = messageId || ('carousel_' + Date.now());
    if (messages.querySelector('[data-carousel-id="' + key + '"]')) {
      return;
    }

    const card = document.createElement('article');
    card.className = 'wpsc-carousel';
    card.dataset.carouselId = key;
    card.dataset.index = '0';

    const media = document.createElement('div');
    media.className = 'wpsc-carousel-media';
    const img = document.createElement('img');
    img.src = element.slides[0].image_url;
    img.alt = element.slides[0].alt || element.title || '';
    media.appendChild(img);

    if (element.slides.length > 1) {
      const prev = document.createElement('button');
      prev.type = 'button';
      prev.className = 'wpsc-carousel-arrow wpsc-carousel-prev';
      prev.setAttribute('aria-label', 'Previous slide');
      prev.textContent = '‹';
      const next = document.createElement('button');
      next.type = 'button';
      next.className = 'wpsc-carousel-arrow wpsc-carousel-next';
      next.setAttribute('aria-label', 'Next slide');
      next.textContent = '›';
      media.appendChild(prev);
      media.appendChild(next);
      prev.addEventListener('click', function () {
        moveCarousel(card, element, -1);
      });
      next.addEventListener('click', function () {
        moveCarousel(card, element, 1);
      });
    }

    card.appendChild(media);

    if (element.slides.length > 1) {
      const dots = document.createElement('div');
      dots.className = 'wpsc-carousel-dots';
      element.slides.forEach(function (_slide, index) {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.setAttribute('aria-label', 'Show slide ' + (index + 1));
        dot.className = index === 0 ? 'is-active' : '';
        dot.addEventListener('click', function () {
          setCarouselIndex(card, element, index);
        });
        dots.appendChild(dot);
      });
      card.appendChild(dots);
    }

    const body = document.createElement('div');
    body.className = 'wpsc-carousel-body';
    if (element.title) {
      const title = document.createElement('h3');
      title.textContent = element.title;
      body.appendChild(title);
    }
    if (element.description) {
      const description = document.createElement('p');
      description.textContent = element.description;
      body.appendChild(description);
    }
    if (element.features && element.features.length) {
      const list = document.createElement('ul');
      element.features.forEach(function (feature) {
        const item = document.createElement('li');
        item.textContent = feature;
        list.appendChild(item);
      });
      body.appendChild(list);
    }
    if (element.button_text && element.button_url) {
      const link = document.createElement('a');
      link.className = 'wpsc-carousel-cta';
      link.href = element.button_url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = element.button_text;
      body.appendChild(link);
    }
    card.appendChild(body);
    messages.appendChild(card);
    messages.scrollTop = messages.scrollHeight;
  }

  function moveCarousel(card, element, direction) {
    const current = Number(card.dataset.index || 0);
    const next = (current + direction + element.slides.length) % element.slides.length;
    setCarouselIndex(card, element, next);
  }

  function setCarouselIndex(card, element, index) {
    card.dataset.index = String(index);
    const img = card.querySelector('.wpsc-carousel-media img');
    if (img && element.slides[index]) {
      img.src = element.slides[index].image_url;
      img.alt = element.slides[index].alt || element.title || '';
    }
    card.querySelectorAll('.wpsc-carousel-dots button').forEach(function (dot, dotIndex) {
      dot.classList.toggle('is-active', dotIndex === index);
    });
  }

  function showLeadForm(formType, triggerMessageId, customForm) {
    formType = ['lead', 'order', 'service', 'booking', 'accommodation', 'finance', 'support', 'custom'].indexOf(formType) !== -1 ? formType : 'lead';
    if (formType === 'custom' && customForm) {
      showCustomLeadForm(customForm, triggerMessageId);
      return;
    }
    const formConfig = {
      lead: {
        title: 'Leave your details',
        service: 'General lead capture',
        message: 'How can the team help?',
        extra: ''
      },
      order: {
        title: 'Order details',
        service: 'Order details',
        message: 'What do you need help with?',
        extra: '<input name="product" placeholder="Product"><input name="order_number" placeholder="Order number (if known)">'
      },
      service: {
        title: 'Service enquiry',
        service: 'Service enquiry',
        message: 'What service do you need?',
        extra: '<input name="service_required" placeholder="Service required"><input name="location" placeholder="Location or suburb">'
      },
      booking: {
        title: 'Booking details',
        service: 'Booking details',
        message: 'What would you like to book?',
        extra: '<input name="booking_number" placeholder="Booking number (if known)"><input name="date_range" placeholder="Date range"><input name="booking_type" placeholder="Booking or appointment type">'
      },
      accommodation: {
        title: 'Accommodation enquiry',
        service: 'Accommodation enquiry',
        message: 'What accommodation details should the team know?',
        extra: '<input name="property_or_room" placeholder="Property or room type"><input name="date_range" placeholder="Dates or date range"><input name="guests" placeholder="Number of guests">'
      },
      finance: {
        title: 'Finance enquiry',
        service: 'Finance enquiry',
        message: 'What finance option are you interested in?',
        extra: '<input name="product" placeholder="Product or service"><input name="finance_amount" placeholder="Approximate amount or budget">'
      },
      support: {
        title: 'Support ticket',
        service: 'Support ticket',
        message: 'What issue do you need help with?',
        extra: '<input name="support_topic" placeholder="Issue type"><input name="order_number" placeholder="Order or account number (optional)">'
      }
    }[formType];

    hideLeadForm();

    const wrap = document.createElement('div');
    wrap.className = 'wpsc-msg wpsc-msg-bot wpsc-lead-card';
    if (triggerMessageId) {
      wrap.dataset.triggerMessageId = String(triggerMessageId);
    }
    wrap.innerHTML = [
      '<form class="wpsc-lead" data-form-type="' + formType + '" data-service-interest="' + formConfig.service + '">',
      '<div class="wpsc-form-title">' + formConfig.title + '</div>',
      '<input name="name" placeholder="Name" required>',
      '<input name="email" placeholder="Email">',
      '<input name="phone" placeholder="Phone">',
      '<input name="company" placeholder="Business name (optional)">',
      formConfig.extra,
      '<textarea name="message" placeholder="' + formConfig.message + '"></textarea>',
      '<button type="submit">Send details</button>',
      '</form>'
    ].join('');

    wrap.querySelector('form').addEventListener('submit', submitLead);
    root.querySelector('.wpsc-messages').appendChild(wrap);
    root.querySelector('.wpsc-messages').scrollTop = root.querySelector('.wpsc-messages').scrollHeight;
    wrap.querySelector('input').focus();
  }

  function hideLeadForm() {
    const card = root.querySelector('.wpsc-lead-card');
    if (card) {
      card.remove();
    }
  }

  function submitLead(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    const card = form.closest('.wpsc-lead-card');
    const formType = form.dataset.formType || 'lead';
    const serviceInterest = form.dataset.serviceInterest || 'General lead capture';
    const detailLabels = {
      product: 'Product',
      order_number: 'Order number',
      service_required: 'Service',
      location: 'Location',
      booking_number: 'Booking number',
      date_range: 'Date range',
      booking_type: 'Booking type',
      property_or_room: 'Property or room',
      guests: 'Guests',
      preferred_date: 'Preferred date',
      preferred_time: 'Preferred time',
      finance_amount: 'Finance amount',
      support_topic: 'Support topic'
    };
    const detailLines = [];
    if (formType === 'custom') {
      form.querySelectorAll('[data-custom-field-label]').forEach(function (field) {
        const key = field.name;
        const value = String(data[key] || '').trim();
        const fieldType = String(field.dataset.customFieldType || '').toLowerCase();
        const fieldLabel = String(field.dataset.customFieldLabel || key).toLowerCase();
        const fieldKey = String(key || '').toLowerCase();

        if (value) {
          if (!data.email && (fieldType === 'email' || fieldKey.indexOf('email') !== -1 || fieldLabel.indexOf('email') !== -1)) {
            data.email = value;
          }
          if (!data.phone && (fieldType === 'tel' || fieldKey.indexOf('phone') !== -1 || fieldKey.indexOf('mobile') !== -1 || fieldKey.indexOf('telephone') !== -1 || fieldLabel.indexOf('phone') !== -1 || fieldLabel.indexOf('mobile') !== -1 || fieldLabel.indexOf('telephone') !== -1)) {
            data.phone = value;
          }
          if (!data.name && (fieldKey === 'full_name' || fieldLabel === 'name' || fieldLabel === 'full name')) {
            data.name = value;
          }
          if (!data.company && (fieldKey.indexOf('business') !== -1 || fieldKey.indexOf('company') !== -1 || fieldLabel.indexOf('business') !== -1 || fieldLabel.indexOf('company') !== -1)) {
            data.company = value;
          }
        }

        if (!value || ['name', 'email', 'phone', 'company', 'message'].indexOf(key) !== -1) {
          return;
        }
        detailLines.push(field.dataset.customFieldLabel + ': ' + value);
      });
    } else {
      Object.keys(detailLabels).forEach(function (key) {
        if (data[key]) {
          detailLines.push(detailLabels[key] + ': ' + data[key]);
        }
      });
    }

    if (formType === 'custom') {
      data.message = detailLines.concat(data.message ? ['Message: ' + data.message] : []).join('\n');
    } else if (formType !== 'lead' || detailLines.length) {
      data.message = detailLines.concat(data.message ? ['Message: ' + data.message] : []).join('\n');
    }

    data.service_interest = serviceInterest;

    ensureStarted().then(function () {
      Object.assign(data, sessionPayload({ conversation_id: state.conversationId }));

      api('/lead/capture', {
        method: 'POST',
        body: JSON.stringify(data)
      }).then(function () {
        clearHandoverFallback();
        if (card && card.dataset.triggerMessageId) {
          markFormMessageCompleted(card.dataset.triggerMessageId);
        }
        hideLeadForm();
        addMessage('bot', 'Thanks, your details have been sent to the team.');
      }).catch(function (error) {
        addMessage('bot', error.message || 'Please add an email or phone number.');
      });
    });
  }

  function handleTool(event) {
    const action = event.currentTarget.dataset.action;
    if (action === 'restart') {
      hideMenu();
      restartChat();
      return;
    }

    ensureStarted().then(function () {
      if (action === 'lead') {
        hideMenu();
        showLeadForm('lead');
      }
      if (action === 'handover') {
        hideMenu();
        requestHandover();
      }
      if (action === 'bug') {
        hideMenu();
        const comment = window.prompt('What went wrong?');
        if (comment) {
          api('/report/bug', {
            method: 'POST',
            body: JSON.stringify(sessionPayload({ conversation_id: state.conversationId, reason: 'user_report', comment: comment, current_url: window.location.href }))
          }).then(function () {
            addMessage('bot', 'Thanks, the report has been saved.');
          });
        }
      }
    });
  }

  function restartChat() {
    clearHandoverFallback();
    if (state.polling) {
      window.clearInterval(state.polling);
      state.polling = null;
    }
    state.session.session_id = uuid('sess');
    state.session.completed_form_messages = [];
    state.conversationId = null;
    state.lastMessageId = 0;
    state.started = false;
    state.startPromise = null;
    state.feedbackSubmitted = false;
    state.pollErrorShown = false;
    clearPendingUpload();
    saveSession();
    showChatView();
    hideLeadForm();
    hideEmojiPicker();
    hideMediaMenu();
    root.querySelector('.wpsc-messages').innerHTML = '';
    const input = root.querySelector('.wpsc-composer input[name="message"]');
    if (input) {
      input.value = '';
    }
    renderQuickReplies([]);
    if (state.config.welcomeScreenEnabled) {
      showWelcomeScreen();
      return;
    }
    ensureStarted();
  }

  function toggleMenu() {
    const menu = root.querySelector('.wpsc-tools');
    hideEmojiPicker();
    hideMediaMenu();
    menu.hidden = !menu.hidden;
  }

  function hideMenu() {
    const menu = root.querySelector('.wpsc-tools');
    if (menu) {
      menu.hidden = true;
    }
  }

  function renderEmojiPicker() {
    const picker = root.querySelector('.wpsc-emoji-picker');
    if (!picker) {
      return;
    }
    picker.innerHTML = '';
    safeEmojiOptions.forEach(function (emoji) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = emoji;
      button.setAttribute('aria-label', 'Insert emoji ' + emoji);
      button.addEventListener('click', function () {
        insertEmoji(emoji);
      });
      picker.appendChild(button);
    });
  }

  function toggleEmojiPicker() {
    const picker = root.querySelector('.wpsc-emoji-picker');
    if (!picker) {
      return;
    }
    hideMenu();
    hideMediaMenu();
    picker.hidden = !picker.hidden;
  }

  function hideEmojiPicker() {
    const picker = root.querySelector('.wpsc-emoji-picker');
    if (picker) {
      picker.hidden = true;
    }
  }

  function toggleMediaMenu() {
    const menu = root.querySelector('.wpsc-media-menu');
    if (!menu) {
      return;
    }
    hideMenu();
    hideEmojiPicker();
    menu.hidden = !menu.hidden;
  }

  function hideMediaMenu() {
    const menu = root.querySelector('.wpsc-media-menu');
    if (menu) {
      menu.hidden = true;
    }
  }

  function openImagePicker() {
    if (!isMediaUploadAvailable()) {
      return;
    }
    hideMenu();
    hideEmojiPicker();
    hideMediaMenu();
    const input = root.querySelector('.wpsc-image-input');
    if (input) {
      input.click();
    }
  }

  function requestSupportForm() {
    hideMenu();
    hideEmojiPicker();
    hideMediaMenu();
    ensureStarted().then(function () {
      addMessage('bot', 'Please submit your support request and the team can follow up.');
      showLeadForm('support');
      requestHandover(true);
    });
  }

  function uploadSelectedImage(event) {
    const input = event.currentTarget;
    const file = input.files && input.files[0];
    input.value = '';
    if (!file) {
      return;
    }
    if (!isAllowedUploadFile(file)) {
      addMessage('bot', 'Upload error: ' + mediaAllowedDescription());
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      addMessage('bot', 'Uploads need to be 5 MB or smaller.');
      return;
    }

    stagePendingUpload(file);
  }

  function stagePendingUpload(file) {
    clearPendingUpload();
    const isImage = /^image\//.test(file.type);
    const previewUrl = isImage ? URL.createObjectURL(file) : '';
    state.pendingUpload = {
      file: file,
      isImage: isImage,
      previewUrl: previewUrl,
      name: file.name
    };
    hideMediaMenu();
    renderPendingUpload();
  }

  function renderPendingUpload() {
    const wrap = root.querySelector('.wpsc-pending-upload');
    if (!wrap || !state.pendingUpload) {
      return;
    }
    wrap.innerHTML = '';
    wrap.hidden = false;

    const card = document.createElement('div');
    card.className = 'wpsc-pending-card';
    if (state.pendingUpload.isImage) {
      const image = document.createElement('img');
      image.src = state.pendingUpload.previewUrl;
      image.alt = state.pendingUpload.name || 'Selected image';
      card.appendChild(image);
    } else {
      const badge = document.createElement('span');
      badge.className = 'wpsc-file-badge';
      badge.textContent = 'PDF';
      card.appendChild(badge);
    }

    const text = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = state.pendingUpload.name || 'Selected file';
    const note = document.createElement('span');
    note.textContent = 'Ready to send. Press send to share this with the team.';
    text.appendChild(title);
    text.appendChild(note);
    card.appendChild(text);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'wpsc-pending-remove';
    remove.textContent = 'Remove';
    remove.addEventListener('click', clearPendingUpload);
    card.appendChild(remove);
    wrap.appendChild(card);
  }

  function clearPendingUpload() {
    if (state.pendingUpload && state.pendingUpload.previewUrl) {
      URL.revokeObjectURL(state.pendingUpload.previewUrl);
    }
    state.pendingUpload = null;
    const wrap = root.querySelector('.wpsc-pending-upload');
    if (wrap) {
      wrap.innerHTML = '';
      wrap.hidden = true;
    }
  }

  function confirmPendingUpload(caption) {
    const pending = state.pendingUpload;
    if (!pending) {
      return;
    }

    ensureStarted().then(function () {
      const formData = new FormData();
      formData.append('session_id', state.session.session_id);
      formData.append('visitor_uuid', state.session.visitor_uuid);
      formData.append('conversation_id', state.conversationId);
      formData.append('file', pending.file);

      fetch(WPSCWidget.restUrl + '/chat/image', {
        method: 'POST',
        body: formData
      }).then(function (response) {
        return response.json().then(function (json) {
          if (!response.ok) {
            throw new Error(json.message || 'Upload failed');
          }
          return json;
        });
      }).then(function (data) {
        addFileMessage('visitor', data.file_url || pending.previewUrl || '#', data.message_id || null, data.file_name || pending.name, data.attachment_type || (pending.isImage ? 'image' : 'pdf'));
        const input = root.querySelector('.wpsc-composer input[name="message"]');
        if (input) {
          input.value = '';
        }
        clearPendingUpload();
        if (caption) {
          deliverMessage(caption);
        } else {
          addMessage('bot', 'Thanks, the file has been sent to the team.');
        }
        requestHandover(true);
      }).catch(function (error) {
        addMessage('bot', error.message || 'Upload failed.');
      });
    });
  }

  function insertEmoji(emoji) {
    const input = root.querySelector('.wpsc-composer input[name="message"]');
    if (!input) {
      return;
    }
    const start = typeof input.selectionStart === 'number' ? input.selectionStart : input.value.length;
    const end = typeof input.selectionEnd === 'number' ? input.selectionEnd : input.value.length;
    input.value = input.value.slice(0, start) + emoji + input.value.slice(end);
    const nextPosition = start + emoji.length;
    input.focus();
    if (input.setSelectionRange) {
      input.setSelectionRange(nextPosition, nextPosition);
    }
  }

  function isFeedbackVisible() {
    const view = root.querySelector('.wpsc-feedback-view');
    return !!(view && !view.hidden);
  }

  function shouldShowFeedbackSurvey() {
    return state.config.feedbackEnabled !== false && state.started && state.conversationId && !state.feedbackSubmitted;
  }

  function showFeedbackSurvey() {
    hideMenu();
    hideEmojiPicker();
    hideMediaMenu();
    clearHandoverFallback();
    root.querySelector('.wpsc-welcome').hidden = true;
    root.querySelector('.wpsc-chat-view').hidden = true;
    root.querySelector('.wpsc-feedback-view').hidden = false;
    root.querySelector('.wpsc-bubble').hidden = true;
    root.querySelector('.wpsc-feedback-status').textContent = '';
    root.querySelector('.wpsc-feedback-submit').disabled = false;
    track('chat_closed_feedback_shown');
  }

  function submitFeedback(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const submit = form.querySelector('.wpsc-feedback-submit');
    const status = form.querySelector('.wpsc-feedback-status');
    const data = new FormData(form);
    submit.disabled = true;
    status.textContent = state.config.feedbackSavingMessage || 'Saving feedback...';

    api('/chat/feedback', {
      method: 'POST',
      body: JSON.stringify(sessionPayload({
        conversation_id: state.conversationId,
        first_time: data.get('first_time'),
        resolved: data.get('resolved'),
        rating: data.get('rating'),
        comment: data.get('comment') || '',
        current_url: window.location.href
      }))
    }).then(function () {
      state.feedbackSubmitted = true;
      status.textContent = state.config.feedbackSuccessMessage || 'Thanks, your feedback has been saved.';
      form.reset();
      window.setTimeout(finishClosePanel, 850);
    }).catch(function (error) {
      submit.disabled = false;
      status.textContent = error.message || state.config.feedbackErrorMessage || 'Please complete the required fields.';
    });
  }

  function skipFeedback() {
    state.feedbackSubmitted = true;
    track('chat_feedback_skipped');
    finishClosePanel();
  }

  function requestHandover(silent) {
    if (state.config.businessHoursEnabled && !state.config.isBusinessOnline) {
      if (!silent) {
        addMessage('bot', state.config.offlineGreeting);
        showLeadForm('lead');
      }
      return;
    }

    if (!silent) {
      addMessage('bot', state.config.handoverConnectingMessage || 'Trying to connect you to support...');
    }

    api('/handover/request', {
      method: 'POST',
      body: JSON.stringify(sessionPayload({ conversation_id: state.conversationId }))
    }).then(function () {
      scheduleHandoverFallback();
    }).catch(function (error) {
      if (!silent) {
        addMessage('bot', error.message || state.config.offlineGreeting);
      }
    });
  }

  function clearHandoverFallback() {
    if (state.handoverTimer) {
      window.clearTimeout(state.handoverTimer);
      state.handoverTimer = null;
    }
  }

  function scheduleHandoverFallback() {
    clearHandoverFallback();
    const seconds = Math.max(0, Number((state.config && state.config.handoverTimeout) || 0));
    if (!seconds) {
      return;
    }

    state.handoverTimer = window.setTimeout(function () {
      state.handoverTimer = null;
      if (root.querySelector('.wpsc-lead-card')) {
        return;
      }
      addMessage('bot', state.config.handoverUnavailableMessage || 'Unfortunately, we cannot connect you right now. Please leave your details so we can get back to you as soon as possible.');
      showLeadForm('lead');
    }, seconds * 1000);
  }

  function startPolling() {
    if (state.polling) {
      window.clearInterval(state.polling);
    }
    function pollMessages() {
      if (!state.conversationId) {
        return;
      }
      // On the very first fetch of an existing conversation, restore the visitor's
      // own message history too. Later polls skip visitor messages because they are
      // already echoed locally when sent.
      const isHistoryFetch = state.lastMessageId === 0 && !root.querySelector('.wpsc-messages .wpsc-msg-visitor');
      api('/chat/messages?' + sessionQuery({ conversation_id: state.conversationId, after: state.lastMessageId }), {
        method: 'GET'
      }).then(function (data) {
        updateLiveTyping(data.typing || { active: false });
        ingestMessages(data.messages || [], isHistoryFetch);
        if (data.last_message_id) {
          state.lastMessageId = Math.max(state.lastMessageId, Number(data.last_message_id));
        }
        state.pollErrorShown = false;
      }).catch(function (error) {
        console.warn('Q Digital Chatbot polling failed:', error);
        if (state.open && !state.pollErrorShown) {
          state.pollErrorShown = true;
          addMessage('bot', 'Live chat updates are having trouble refreshing. Your messages are still saved, but you may need to reload if replies do not appear.');
        }
      });
    }
    pollMessages();
    state.polling = window.setInterval(pollMessages, state.open ? 2500 : 6000);
  }

  function track(eventType, data) {
    if (!state.conversationId) {
      return;
    }
    api('/events/track', {
      method: 'POST',
      body: JSON.stringify(sessionPayload({ conversation_id: state.conversationId, event_type: eventType, event_data: data || {} }))
    }).catch(function (error) {
      console.warn('Q Digital Chatbot event tracking failed:', error);
    });
  }

  init();
})();
