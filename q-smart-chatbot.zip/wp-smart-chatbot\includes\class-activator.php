<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Activator {
    public static function activate() {
        WPSC_Schema::create_tables();
        WPSC_Settings_Service::ensure_defaults();
        WPSC_Schema::seed_defaults();
        update_option('wpsc_db_version', WPSC_VERSION);

        if (!wp_next_scheduled('wpsc_handover_timeout_check')) {
            wp_schedule_event(time() + MINUTE_IN_SECONDS, 'wpsc_five_minutes', 'wpsc_handover_timeout_check');
        }

        if (!wp_next_scheduled('wpsc_media_retention_cleanup')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'wpsc_media_retention_cleanup');
        }
    }
}
