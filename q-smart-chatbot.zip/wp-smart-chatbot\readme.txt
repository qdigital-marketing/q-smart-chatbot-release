=== Q Digital Smart Chatbot ===
Contributors: q-digital-marketing
Tags: chatbot, ai, openai, live chat, leads
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

AI chatbot, canned replies, lead capture, knowledgebase upload, live handover state and notifications for WordPress.

== Description ==
Q Digital Smart Chatbot is a standalone MVP chatbot plugin for service business websites. It stores conversations and leads in WordPress, provides a floating front-end widget, supports canned replies, and can call OpenAI server-side when configured.

== Installation ==
Upload the `wp-smart-chatbot` directory to `/wp-content/plugins/`, activate it, and open Q Digital Chatbot in the WordPress admin.

== Security ==
OpenAI keys are never exposed to front-end JavaScript. Prefer defining `WPSC_OPENAI_API_KEY` in `wp-config.php`.

== Changelog ==

= 1.0.0 =
* Release: first Q Digital Smart Chatbot production package.
* Rebrand: updated admin branding, logos, menu icon, and author details for Q Digital Marketing.
* Admin: added compact page headers and a compact in-plugin navigation menu.
* Knowledgebase: added source cards, improved document indexing status, retrieval testing, and gap-to-FAQ answer workflow.
* Updates: added GitHub release-based plugin update checks using q-smart-chatbot-release.

= 0.4.8 =
* Fix: the launcher's hover-wave dots no longer keep waving behind the forming line during the open/close morph (they are now hard-hidden while morphing).
* Polish: closing now collapses the arrow back to a line, then hands off to the message icon with a rock-back-and-forth settle animation, instead of reversing all the way to dots.

= 0.4.7 =
* Polish: the launcher morph now uses a chunky, solid filled arrow (thick rounded bar + filled triangle head) to match the intended design. The dots are fatter to match the bar weight, and the triangle arrowhead grows out of the line's end before the arrow rotates up.

= 0.4.6 =
* Polish: the launcher morph now draws the line from the left dot rightward (a growing stroke) instead of fading in, and the arrowhead's two arms draw outward from the tip so the head visibly forms, before the arrow rotates up.

= 0.4.5 =
* Polish: the launcher morph now lines up properly — the merged line matches the dots' length and thickness, and the arrow stroke is thickened to match the composer send-button arrow (~3px). The open/close of the chat window is slowed down so the expand/collapse feels less abrupt.

= 0.4.4 =
* Fix: minimising the chat no longer briefly flashes the launcher icon in the top-left corner; the launcher stays pinned to its corner throughout the close.
* Change: the widget animations (launcher morph, open/close, typing wave, badge pulse, message entrance) now always play rather than being disabled under prefers-reduced-motion, so they are consistently visible. This can be reverted to honour reduced motion if required.

= 0.4.3 =
* UI: the launcher now plays a morph when opening — the dot wave merges into a line, the line grows a left-pointing arrowhead, then the arrow rotates clockwise to point up (matching the send button) as the window expands from the corner. Closing reverses the sequence.
* Accessibility: the morph is movement-heavy, so under prefers-reduced-motion it is skipped in favour of the gentle open/close fade.

= 0.4.2 =
* UI: the chat window now opens by expanding out of the launcher's bottom corner (where the send button sits) while the launcher collapses into it, and reverses on close, for a subtle, intentional morph.
* Accessibility: under prefers-reduced-motion the open/close now degrades to a gentle opacity fade instead of no transition, and movement-based (scale/slide) transitions are dropped rather than all transitions.

= 0.4.1 =
* UI: the launcher message icon now has a subtle idle wiggle, the animated dot wave is used as the "typing" indicator for bot and quick-reply responses (and loops while waiting), and the unread-count badge pulses.
* UI: the browser tab now alternates between the unread-message count and the site name while the chat is closed and messages are waiting.
* Setting: the response typing-wave duration (Typing Delay) is now clearly labelled and documented on the Settings page, and clamped to 0-10000 ms, so replies can be slowed to feel more human.
* The small looping status animations (launcher hover wave, typing indicator, badge pulse) intentionally remain active under prefers-reduced-motion; larger entrance/pop/ping motions stay disabled.

= 0.4.0 =
* Security: visitor-supplied message metadata is now whitelisted server-side, and attachment links are validated client-side so only http/https URLs render.
* Security: the public event-tracking endpoint now sanitizes and caps stored event data.
* Fix: captions typed alongside a file upload are now sent instead of being discarded.
* Fix: the visitor's own messages are restored when a returning visitor reopens an existing conversation.
* Fix: unchecking every business day or every featured start button now saves correctly (previously the old selection silently persisted, and clearing days could accidentally select Sunday).
* Fix: the API rate limiter now uses a proper fixed window instead of resetting its window on every request.
* Fix: the welcome nudge stays dismissed across page views, and chat no longer breaks when localStorage is unavailable.
* Fix: short API keys are no longer partially revealed by the settings mask.
* UI: animated typing indicator, modern message bubbles with entrance animation, styled chat scrollbar, quick-reply hover states, and a subtle header gradient.
