<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Deactivator {
    public static function deactivate() {
        wp_clear_scheduled_hook('wpsc_handover_timeout_check');
        wp_clear_scheduled_hook('wpsc_media_retention_cleanup');
    }
}
