<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Schema {
    public static function create_tables() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $sql = [];

        $sql[] = "CREATE TABLE " . wpsc_table('conversations') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id VARCHAR(100) NOT NULL,
            visitor_uuid VARCHAR(100) NOT NULL,
            lead_id BIGINT UNSIGNED DEFAULT NULL,
            assigned_agent_id BIGINT UNSIGNED DEFAULT NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'bot',
            source_url TEXT NULL,
            current_url TEXT NULL,
            referrer TEXT NULL,
            user_ip_hash VARCHAR(100) NULL,
            user_agent TEXT NULL,
            priority VARCHAR(20) NOT NULL DEFAULT 'normal',
            last_message_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY visitor_uuid (visitor_uuid),
            KEY status (status),
            KEY last_message_at (last_message_at)
        ) $charset;";

        $sql[] = "CREATE TABLE " . wpsc_table('messages') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            sender_type VARCHAR(40) NOT NULL,
            sender_id BIGINT UNSIGNED DEFAULT NULL,
            message_type VARCHAR(40) NOT NULL DEFAULT 'text',
            body LONGTEXT NULL,
            metadata LONGTEXT NULL,
            ai_model VARCHAR(100) NULL,
            ai_tokens_input INT DEFAULT 0,
            ai_tokens_output INT DEFAULT 0,
            confidence_score FLOAT DEFAULT NULL,
            is_private_note TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_id (conversation_id),
            KEY sender_type (sender_type),
            KEY created_at (created_at)
        ) $charset;";

        $sql[] = "CREATE TABLE " . wpsc_table('leads') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NULL,
            email VARCHAR(190) NULL,
            phone VARCHAR(80) NULL,
            company VARCHAR(190) NULL,
            message LONGTEXT NULL,
            service_interest VARCHAR(190) NULL,
            location VARCHAR(190) NULL,
            preferred_contact_method VARCHAR(40) NULL,
            consent TINYINT(1) NOT NULL DEFAULT 0,
            conversation_id BIGINT UNSIGNED DEFAULT NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'new',
            lead_score INT DEFAULT 0,
            assigned_to BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY email (email),
            KEY conversation_id (conversation_id),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE " . wpsc_table('canned_responses') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(190) NOT NULL,
            trigger_label VARCHAR(190) NOT NULL,
            response_text LONGTEXT NOT NULL,
            action_type VARCHAR(60) NOT NULL DEFAULT 'send_message',
            action_payload LONGTEXT NULL,
            department_id BIGINT UNSIGNED DEFAULT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY trigger_label (trigger_label),
            KEY is_active (is_active),
            KEY sort_order (sort_order)
        ) $charset;";

        $sql[] = "CREATE TABLE " . wpsc_table('documents') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(190) NOT NULL,
            file_name VARCHAR(190) NOT NULL,
            file_path TEXT NULL,
            file_local_path TEXT NULL,
            mime_type VARCHAR(120) NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'uploaded',
            indexing_error TEXT NULL,
            openai_file_id VARCHAR(190) NULL,
            vector_store_id VARCHAR(190) NULL,
            visibility VARCHAR(60) NOT NULL DEFAULT 'global',
            created_by BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY vector_store_id (vector_store_id)
        ) $charset;";

        $sql[] = "CREATE TABLE " . wpsc_table('events') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED DEFAULT NULL,
            event_type VARCHAR(100) NOT NULL,
            event_data LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_id (conversation_id),
            KEY event_type (event_type),
            KEY created_at (created_at)
        ) $charset;";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }
    }

    public static function seed_defaults() {
        $repository = new WPSC_Repository();
        $existing = array_map(function ($item) {
            return $item['title'];
        }, $repository->list_canned_responses(false));

        $defaults = self::default_canned_flows();

        foreach ($defaults as $index => $item) {
            if (in_array($item['title'], $existing, true)) {
                continue;
            }

            $repository->save_canned_response([
                'title' => $item['title'],
                'trigger_label' => $item['trigger_label'],
                'response_text' => $item['response_text'],
                'action_type' => $item['action_type'],
                'action_payload' => $item['action_payload'],
                'sort_order' => $item['sort_order'],
                'is_active' => 1,
            ]);
        }
    }

    private static function default_canned_flows() {
        return [
            [
                'title' => 'FAQ: Business Information',
                'trigger_label' => 'Business information',
                'response_text' => 'I can help with contact details, opening hours, and store or office information.',
                'action_type' => 'send_message',
                'sort_order' => 1,
                'action_payload' => [
                    'choice_display' => 'cards',
                    'messages' => ['Choose what you need and I will point you in the right direction.'],
                    'options' => [
                        ['label' => 'Phone and email', 'action_type' => 'send_message', 'response_text' => "Phone: {business_phone}\nEmail: {business_email}"],
                        ['label' => 'Address', 'action_type' => 'send_message', 'response_text' => "Address / service area:\n{business_address}"],
                        ['label' => 'Trading hours', 'action_type' => 'send_message', 'response_text' => 'Trading hours: {business_hours}'],
                    ],
                ],
            ],
            [
                'title' => 'FAQ: Customer Support',
                'trigger_label' => 'Support',
                'response_text' => 'What sort of support do you need?',
                'action_type' => 'send_message',
                'sort_order' => 2,
                'action_payload' => [
                    'choice_display' => 'cards',
                    'messages' => ['For account, checkout, payment, delivery, tracking, or other support issues, I can collect your details so the team can follow up.'],
                    'options' => [
                        ['label' => 'Checkout or payment issue', 'action_type' => 'ask_contact', 'response_text' => 'Sorry that happened. Please leave your details and what went wrong at checkout so the team can follow up.'],
                        ['label' => 'Delivery or tracking', 'action_type' => 'ask_contact', 'response_text' => 'Please leave your details and order or tracking information if you have it, and the team will follow up manually.'],
                        ['label' => 'Other support issue', 'action_type' => 'ask_contact', 'response_text' => 'Please leave your details and a short description of the issue so the team can help.'],
                    ],
                ],
            ],
            [
                'title' => 'FAQ: Brand Recommendations',
                'trigger_label' => 'Brand recommendations',
                'response_text' => 'I can help narrow down suitable brands or product options.',
                'action_type' => 'send_message',
                'sort_order' => 3,
                'action_payload' => [
                    'choice_display' => 'bubbles',
                    'messages' => ['Tell us what you are trying to buy or solve, and the team can recommend the right option.'],
                    'options' => [
                        ['label' => 'Get a recommendation', 'action_type' => 'ask_contact', 'response_text' => 'Please leave your details and what you are looking for, and the team will recommend suitable options.'],
                        ['label' => 'Speak to someone', 'action_type' => 'handover', 'response_text' => 'I will pass this to the team. Please leave your details in case nobody is available immediately.'],
                    ],
                ],
            ],
            [
                'title' => 'FAQ: Finance Options',
                'trigger_label' => 'Finance options',
                'response_text' => 'Finance options can vary by business, product, and customer situation.',
                'action_type' => 'ask_contact',
                'sort_order' => 4,
                'action_payload' => [
                    'choice_display' => 'bubbles',
                    'messages' => ['Please leave your details and what you are interested in, and the team can follow up with the available finance options.'],
                ],
            ],
            [
                'title' => 'Accommodation Listings',
                'trigger_label' => 'Accommodation',
                'response_text' => 'Here is an accommodation option you may like.',
                'action_type' => 'send_message',
                'sort_order' => 5,
                'action_payload' => [
                    'choice_display' => 'bubbles',
                    'content_element' => [
                        'type' => 'slideshow',
                        'title' => 'Featured accommodation',
                        'description' => 'Add room details, guest capacity, destination notes, and images from the Canned Responses editor.',
                        'features' => ['Max guests', 'Bedrooms', 'Wi-Fi', 'Flexible enquiry'],
                        'button_text' => 'Check availability & rates',
                        'button_url' => home_url('/'),
                        'slides' => [],
                    ],
                    'options' => [
                        ['label' => 'Ask about this stay', 'action_type' => 'ask_accommodation', 'response_text' => 'Please leave your contact details, preferred dates, and accommodation requirements so the team can follow up.'],
                    ],
                ],
            ],
            [
                'title' => 'FAQ: Other Enquiry',
                'trigger_label' => 'Other',
                'response_text' => 'No problem. The best next step is to collect a few details and have the team follow up manually.',
                'action_type' => 'ask_contact',
                'sort_order' => 6,
                'action_payload' => [
                    'choice_display' => 'bubbles',
                    'messages' => ['Please include your name, email, phone, business name if relevant, and a short message.'],
                ],
            ],
        ];
    }
}
