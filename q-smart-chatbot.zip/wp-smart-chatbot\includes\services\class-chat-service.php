<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Chat_Service {
    private $settings;
    private $repository;
    private $notifications;

    public function __construct(WPSC_Settings_Service $settings, WPSC_Repository $repository) {
        $this->settings = $settings;
        $this->repository = $repository;
        $this->notifications = new WPSC_Notification_Service($settings);
    }

    public function start_session($data) {
        $session_id = !empty($data['session_id']) ? sanitize_text_field($data['session_id']) : 'sess_' . wp_generate_uuid4();
        $visitor_uuid = !empty($data['visitor_uuid']) ? sanitize_text_field($data['visitor_uuid']) : 'vis_' . wp_generate_uuid4();
        $conversation = $this->repository->get_or_create_conversation(
            $session_id,
            $visitor_uuid,
            $data['current_url'] ?? '',
            $data['referrer'] ?? ''
        );

        return [
            'session_id' => $session_id,
            'visitor_uuid' => $visitor_uuid,
            'conversation' => $conversation,
            'config' => $this->settings->public_config($this->repository),
        ];
    }

    public function receive_message($data) {
        $message = sanitize_textarea_field($data['message'] ?? '');
        if ($message === '') {
            return new WP_Error('wpsc_empty_message', __('Please enter a message.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $session = $this->start_session($data);
        $conversation = $session['conversation'];

        if (!empty($data['current_url'])) {
            $this->repository->update_conversation((int) $conversation['id'], ['current_url' => esc_url_raw($data['current_url'])]);
            $conversation = $this->repository->get_conversation((int) $conversation['id']);
        }

        $visitor_message = $this->repository->add_message((int) $conversation['id'], 'visitor', $message, [
            'metadata' => $this->sanitize_visitor_metadata($data['metadata'] ?? []),
        ]);

        $bot_messages = [];

        if (in_array($conversation['status'], ['human', 'waiting_human'], true)) {
            $this->repository->update_conversation((int) $conversation['id'], ['status' => 'waiting_human']);
            $this->repository->add_event('visitor_message_waiting_human', ['message_id' => $visitor_message['id']], (int) $conversation['id']);
            return $this->response_payload($this->repository->get_conversation((int) $conversation['id']), [$visitor_message], []);
        }

        $matched = $this->match_canned_by_message($message);
        if ($matched) {
            $handled = $this->handle_canned_response($conversation, $matched);
            $bot_messages = array_merge($bot_messages, $handled['messages']);
            return $this->response_payload($this->repository->get_conversation((int) $conversation['id']), array_merge([$visitor_message], $bot_messages), $handled['quick_replies']);
        } elseif ($this->settings->get('ai_enabled') === '1') {
            $ai = (new WPSC_AI_Service($this->settings))->answer($message, $conversation);
            if (is_wp_error($ai)) {
                $bot_messages[] = $this->repository->add_message((int) $conversation['id'], 'bot', $this->settings->get('fallback_message'), [
                    'metadata' => ['error' => $ai->get_error_message()],
                ]);
            } else {
                $usage = $ai['usage'];
                $bot_messages[] = $this->repository->add_message((int) $conversation['id'], 'bot', $ai['body'], [
                    'ai_model' => $ai['model'],
                    'ai_tokens_input' => isset($usage['input_tokens']) ? (int) $usage['input_tokens'] : 0,
                    'ai_tokens_output' => isset($usage['output_tokens']) ? (int) $usage['output_tokens'] : 0,
                ]);
            }
        } else {
            $bot_messages[] = $this->repository->add_message((int) $conversation['id'], 'bot', $this->settings->get('fallback_message'));
        }

        return $this->response_payload($this->repository->get_conversation((int) $conversation['id']), array_merge([$visitor_message], $bot_messages), $this->quick_replies());
    }

    public function quick_reply($data) {
        $inline = !empty($data['inline_response']) && is_array($data['inline_response']) ? $data['inline_response'] : null;
        $response = null;
        if (!empty($data['canned_response_id'])) {
            $response = $this->repository->get_canned_response((int) $data['canned_response_id']);
        }
        if (!$response && !empty($data['label'])) {
            $response = $this->repository->find_canned_response_by_label($data['label']);
        }
        if (!$response && $inline) {
            $response = $this->normalise_inline_response($inline, $data['label'] ?? '');
        }
        if (!$response) {
            return new WP_Error('wpsc_quick_reply_missing', __('Quick reply could not be found.', 'wp-smart-chatbot'), ['status' => 404]);
        }

        $session = $this->start_session($data);
        $conversation = $session['conversation'];
        $visitor_message = $this->repository->add_message((int) $conversation['id'], 'visitor', $response['trigger_label'], ['message_type' => 'quick_reply']);

        if (in_array($conversation['status'], ['human', 'waiting_human'], true)) {
            $this->repository->update_conversation((int) $conversation['id'], ['status' => 'waiting_human']);
            $this->repository->add_event('visitor_quick_reply_waiting_human', ['message_id' => $visitor_message['id']], (int) $conversation['id']);
            return $this->response_payload($this->repository->get_conversation((int) $conversation['id']), [$visitor_message], []);
        }

        $handled = $this->handle_canned_response($conversation, $response);

        return $this->response_payload($this->repository->get_conversation((int) $conversation['id']), $handled['messages'], $handled['quick_replies']);
    }

    public function capture_lead($data) {
        $lead = $this->repository->create_lead($data);
        $conversation = !empty($lead['conversation_id']) ? $this->repository->get_conversation((int) $lead['conversation_id']) : null;
        if ($conversation) {
            $this->repository->add_message((int) $conversation['id'], 'system', 'Lead captured.', ['message_type' => 'event']);
        }
        $notification = $this->notifications->send_lead_notification($lead, $conversation);
        if (empty($notification['email_sent']) || ($this->settings->get('notification_webhook_enabled', '0') === '1' && empty($notification['webhook_sent']))) {
            $this->repository->add_event('notification_delivery_issue', [
                'context' => 'lead_captured',
                'email_sent' => !empty($notification['email_sent']),
                'webhook_sent' => !empty($notification['webhook_sent']),
            ], $conversation ? (int) $conversation['id'] : null);
        }
        $this->repository->add_event('lead_captured', ['lead_id' => $lead['id']], $conversation ? (int) $conversation['id'] : null);
        return $lead;
    }

    public function request_handover($conversation_id) {
        $conversation = $this->repository->get_conversation((int) $conversation_id);
        if (!$conversation) {
            return new WP_Error('wpsc_conversation_missing', __('Conversation not found.', 'wp-smart-chatbot'), ['status' => 404]);
        }

        $this->repository->update_conversation((int) $conversation_id, ['status' => 'waiting_human']);
        $updated = $this->repository->get_conversation((int) $conversation_id);
        $this->repository->add_message((int) $conversation_id, 'system', 'Human handover requested.', ['message_type' => 'event']);
        $this->repository->add_event('handover_requested', [], (int) $conversation_id);
        $notification = $this->notifications->send_handover_notification($updated);
        if (empty($notification['email_sent']) || ($this->settings->get('notification_webhook_enabled', '0') === '1' && empty($notification['webhook_sent']))) {
            $this->repository->add_event('notification_delivery_issue', [
                'context' => 'handover_requested',
                'email_sent' => !empty($notification['email_sent']),
                'webhook_sent' => !empty($notification['webhook_sent']),
            ], (int) $conversation_id);
        }
        return $updated;
    }

    public function process_handover_timeouts() {
        $timeout = (int) $this->settings->get('handover_timeout', '900');
        if ($timeout < 1) {
            return 0;
        }

        $processed = 0;
        foreach ($this->repository->timed_out_handover_conversations($timeout, 50) as $conversation) {
            $conversation_id = (int) ($conversation['id'] ?? 0);
            if (!$conversation_id || $this->repository->has_event($conversation_id, 'handover_timeout_fallback_sent')) {
                continue;
            }

            $message = $this->settings->get('handover_unavailable_message');
            $created = $this->repository->add_message($conversation_id, 'bot', $message, [
                'metadata' => [
                    'action_type' => 'ask_contact',
                    'form_type' => 'lead',
                    'form_label' => __('Lead details form', 'wp-smart-chatbot'),
                    'source' => 'handover_timeout',
                ],
            ]);
            $this->repository->add_event('handover_timeout_fallback_sent', ['message_id' => (int) ($created['id'] ?? 0)], $conversation_id);
            $processed++;
        }

        return $processed;
    }

    public function response_payload($conversation, $messages, $quick_replies = []) {
        return [
            'conversation_id' => (int) $conversation['id'],
            'status' => $conversation['status'],
            'messages' => array_values(array_filter($messages)),
            'quick_replies' => $quick_replies,
        ];
    }

    private function sanitize_visitor_metadata($metadata) {
        if (!is_array($metadata)) {
            return [];
        }

        // Visitors may only attach a small set of harmless context values. Anything
        // else (file URLs, action types, agent names) must come from the server side.
        $allowed = ['timezone', 'screen_width', 'page_title'];
        $clean = [];
        foreach ($allowed as $key) {
            if (isset($metadata[$key]) && is_scalar($metadata[$key])) {
                $clean[$key] = sanitize_text_field(substr((string) $metadata[$key], 0, 190));
            }
        }

        return $clean;
    }

    private function match_canned_by_message($message) {
        if ($this->settings->get('canned_enabled') !== '1') {
            return null;
        }

        foreach ($this->repository->list_canned_responses(true) as $response) {
            if (strcasecmp(trim($message), trim($response['trigger_label'])) === 0) {
                return $response;
            }
        }

        return null;
    }

    private function handle_canned_response($conversation, $response) {
        $action = $response['action_type'];
        $payload = wpsc_json_decode($response['action_payload'] ?? '{}');
        $form = $this->form_for_action($action, $payload);
        $metadata_action = $form ? 'ask_contact' : $action;
        $base_metadata = [
            'canned_response_id' => (int) $response['id'],
            'action_type' => $metadata_action,
            'form_type' => $form ? $form['type'] : '',
            'form_label' => $form ? $form['label'] : '',
            'custom_form' => $form['custom_form'] ?? null,
            'content_element' => $this->normalise_content_element($payload['content_element'] ?? []),
            'action_payload' => $payload,
        ];
        if ($action === 'handover') {
            $this->repository->update_conversation((int) $conversation['id'], ['status' => 'waiting_human']);
            $notification = $this->notifications->send_handover_notification($conversation);
            if (empty($notification['email_sent']) || ($this->settings->get('notification_webhook_enabled', '0') === '1' && empty($notification['webhook_sent']))) {
                $this->repository->add_event('notification_delivery_issue', [
                    'context' => 'canned_handover',
                    'email_sent' => !empty($notification['email_sent']),
                    'webhook_sent' => !empty($notification['webhook_sent']),
                ], (int) $conversation['id']);
            }
        }

        $messages = [];
        $messages[] = $this->repository->add_message((int) $conversation['id'], 'bot', $this->settings->replace_placeholders($response['response_text']), [
            'metadata' => $base_metadata,
        ]);

        foreach (($payload['messages'] ?? []) as $extra_message) {
            $extra_message = sanitize_textarea_field($this->settings->replace_placeholders($extra_message));
            if ($extra_message !== '') {
                $messages[] = $this->repository->add_message((int) $conversation['id'], 'bot', $extra_message, [
                    'metadata' => [
                        'canned_response_id' => (int) $response['id'],
                        'action_type' => $metadata_action,
                        'form_type' => $form ? $form['type'] : '',
                        'form_label' => $form ? $form['label'] : '',
                        'custom_form' => $form['custom_form'] ?? null,
                    ],
                ]);
            }
        }

        $quick_replies = $this->quick_replies_for_payload($payload);

        return [
            'messages' => $messages,
            'quick_replies' => $quick_replies,
            'choice_display' => $payload['choice_display'] ?? 'bubbles',
            'card_image_url' => $payload['card_image_url'] ?? '',
        ];
    }

    private function quick_replies() {
        if ($this->settings->get('quick_replies_enabled') !== '1') {
            return [];
        }

        return array_map(function ($item) {
            $payload = wpsc_json_decode($item['action_payload'] ?? '{}');
            return [
                'id' => (int) $item['id'],
                'label' => $item['trigger_label'],
                'action' => $item['action_type'],
                'payload' => $payload,
            ];
        }, $this->settings->featured_canned_responses($this->repository));
    }

    private function normalise_options($options) {
        $clean = [];
        foreach ($options as $option) {
            if (!is_array($option) || empty($option['label'])) {
                continue;
            }
            $action = sanitize_key($option['action_type'] ?? 'send_message');
            if (!in_array($action, $this->allowed_actions(), true)) {
                $action = 'send_message';
            }
            $form = $this->form_for_action($action);
            $clean[] = [
                'id' => 0,
                'label' => sanitize_text_field($option['label']),
                'action' => $action,
                'payload' => [
                    'form_type' => $form ? $form['type'] : '',
                    'target_id' => isset($option['target_id']) ? (int) $option['target_id'] : 0,
                    'response_text' => $this->settings->replace_placeholders(sanitize_textarea_field($option['response_text'] ?? '')),
                    'messages' => !empty($option['messages']) && is_array($option['messages']) ? array_map([$this->settings, 'replace_placeholders'], array_map('sanitize_textarea_field', $option['messages'])) : [],
                    'options' => !empty($option['options']) && is_array($option['options']) ? $option['options'] : [],
                    'image_url' => esc_url_raw($option['image_url'] ?? ''),
                ],
            ];
        }
        return $clean;
    }

    private function quick_replies_for_payload($payload) {
        if (!empty($payload['fast_reply_ids']) && is_array($payload['fast_reply_ids'])) {
            $replies = [];
            foreach (array_slice($payload['fast_reply_ids'], 0, 5) as $id) {
                $response = $this->repository->get_canned_response((int) $id);
                if (!$response || empty($response['is_active'])) {
                    continue;
                }
                $response_payload = wpsc_json_decode($response['action_payload'] ?? '{}');
                $replies[] = [
                    'id' => (int) $response['id'],
                    'label' => $response['trigger_label'],
                    'action' => $response['action_type'],
                    'payload' => $response_payload,
                    'image' => esc_url_raw($response_payload['card_image_url'] ?? ''),
                ];
            }
            if ($replies) {
                return $this->decorate_quick_replies($replies, $payload);
            }
        }

        if (!empty($payload['options']) && is_array($payload['options'])) {
            return $this->decorate_quick_replies($this->normalise_options($payload['options']), $payload);
        }

        return $this->quick_replies();
    }

    private function decorate_quick_replies($replies, $payload) {
        $display = ($payload['choice_display'] ?? 'bubbles') === 'cards' ? 'cards' : 'bubbles';
        $limit = $display === 'cards' ? 4 : 5;
        $image = esc_url_raw($payload['card_image_url'] ?? '');
        $default_style = $this->settings->get('card_default_style', 'split');
        $style = in_array(($payload['card_style'] ?? $default_style), ['split', 'cover'], true) ? ($payload['card_style'] ?? $default_style) : 'split';
        $text_color = sanitize_hex_color($payload['card_text_color'] ?? '');
        if (!$text_color) {
            $text_color = sanitize_hex_color($this->settings->get('card_default_text_color', '#ffffff')) ?: '#ffffff';
        }
        $background_color = sanitize_hex_color($payload['card_label_background_color'] ?? '');
        if (!$background_color) {
            $background_color = sanitize_hex_color($this->settings->get('card_default_background_color', '#111827')) ?: '#111827';
        }
        $opacity = isset($payload['card_overlay_opacity']) ? min(100, max(0, (int) $payload['card_overlay_opacity'])) : min(100, max(0, (int) $this->settings->get('card_default_overlay_opacity', 88)));
        $default_position = $this->settings->get('card_default_text_position', 'bottom');
        $position = in_array(($payload['card_text_position'] ?? $default_position), ['bottom', 'center'], true) ? ($payload['card_text_position'] ?? $default_position) : 'bottom';
        $default_shape = $this->settings->get('card_default_image_shape', 'square');
        $shape = in_array(($payload['card_image_shape'] ?? $default_shape), ['landscape', 'square', 'portrait'], true) ? ($payload['card_image_shape'] ?? $default_shape) : 'square';

        return array_map(function ($reply) use ($display, $image, $style, $text_color, $background_color, $opacity, $position, $shape) {
            $reply['display'] = $display;
            if ($display === 'cards') {
                $reply['card_style'] = $style;
                $reply['card_text_color'] = $text_color;
                $reply['card_label_background_color'] = $background_color;
                $reply['card_overlay_opacity'] = $opacity;
                $reply['card_text_position'] = $position;
                $reply['card_image_shape'] = $shape;
                $reply_image = esc_url_raw($reply['payload']['image_url'] ?? $reply['image'] ?? '');
                if (!$reply_image && $image) {
                    $reply_image = $image;
                }
                if ($reply_image) {
                    $reply['image'] = $reply_image;
                }
            }
            return $reply;
        }, array_slice($replies, 0, $limit));
    }

    private function normalise_inline_response($inline, $label) {
        $payload = $inline['payload'] ?? [];
        if (!empty($payload['target_id'])) {
            $target = $this->repository->get_canned_response((int) $payload['target_id']);
            if ($target) {
                return $target;
            }
        }

        $response_text = $this->settings->replace_placeholders(sanitize_textarea_field($payload['response_text'] ?? $inline['response_text'] ?? $label));
        return [
            'id' => 0,
            'title' => sanitize_text_field($label),
            'trigger_label' => sanitize_text_field($label),
            'response_text' => $response_text,
            'action_type' => sanitize_key($inline['action'] ?? $inline['action_type'] ?? 'send_message'),
            'action_payload' => wpsc_json_encode([
                'messages' => !empty($payload['messages']) && is_array($payload['messages']) ? $payload['messages'] : [],
                'options' => !empty($payload['options']) && is_array($payload['options']) ? $payload['options'] : [],
                'card_image_url' => esc_url_raw($payload['card_image_url'] ?? ''),
            ]),
        ];
    }

    private function allowed_actions() {
        return array_merge(['send_message', 'open_url', 'ask_contact', 'handover', 'start_ai'], array_keys($this->form_action_map()));
    }

    private function form_action_map() {
        $map = [
            'ask_lead' => ['type' => 'lead', 'label' => __('Lead details form', 'wp-smart-chatbot')],
            'ask_order' => ['type' => 'order', 'label' => __('Order details form', 'wp-smart-chatbot')],
            'ask_service' => ['type' => 'service', 'label' => __('Service enquiry form', 'wp-smart-chatbot')],
            'ask_booking' => ['type' => 'booking', 'label' => __('Booking details form', 'wp-smart-chatbot')],
            'ask_accommodation' => ['type' => 'accommodation', 'label' => __('Accommodation enquiry form', 'wp-smart-chatbot')],
            'ask_finance' => ['type' => 'finance', 'label' => __('Finance enquiry form', 'wp-smart-chatbot')],
            'ask_support' => ['type' => 'support', 'label' => __('Support ticket form', 'wp-smart-chatbot')],
        ];
        foreach ($this->settings->custom_forms() as $form) {
            $map['ask_custom_' . $form['id']] = [
                'type' => 'custom',
                'label' => $form['name'],
                'custom_form' => $form,
            ];
        }
        return $map;
    }

    private function form_for_action($action, $payload = []) {
        $map = $this->form_action_map();
        if (isset($map[$action])) {
            return $map[$action];
        }

        if ($action === 'ask_contact') {
            $type = sanitize_key($payload['form_type'] ?? 'lead');
            foreach ($map as $form) {
                if ($form['type'] === $type) {
                    return $form;
                }
            }
            return ['type' => 'lead', 'label' => __('Lead details form', 'wp-smart-chatbot')];
        }

        return null;
    }

    private function normalise_content_element($element) {
        if (!is_array($element) || ($element['type'] ?? '') !== 'slideshow') {
            return null;
        }

        $slides = [];
        foreach (($element['slides'] ?? []) as $slide) {
            if (!is_array($slide) || empty($slide['image_url'])) {
                continue;
            }
            $slides[] = [
                'image_url' => esc_url_raw($slide['image_url']),
                'alt' => sanitize_text_field($slide['alt'] ?? ''),
            ];
        }

        if (!$slides) {
            return null;
        }

        $features = $element['features'] ?? [];
        if (!is_array($features)) {
            $features = preg_split('/\r\n|\r|\n/', (string) $features);
        }

        return [
            'type' => 'slideshow',
            'title' => sanitize_text_field($element['title'] ?? ''),
            'description' => sanitize_textarea_field($this->settings->replace_placeholders($element['description'] ?? '')),
            'features' => array_values(array_filter(array_map('sanitize_text_field', $features))),
            'button_text' => sanitize_text_field($element['button_text'] ?? ''),
            'button_url' => esc_url_raw($element['button_url'] ?? ''),
            'slides' => array_slice($slides, 0, 12),
        ];
    }
}
