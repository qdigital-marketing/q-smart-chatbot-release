<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_OpenAI_Client {
    private $api_key;

    public function __construct($api_key) {
        $this->api_key = $api_key;
    }

    public function has_key() {
        return !empty($this->api_key);
    }

    public function response($payload) {
        if (!$this->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        return $this->request('https://api.openai.com/v1/responses', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
            'timeout' => 45,
        ]);
    }

    public function upload_file($path, $filename) {
        if (!$this->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        if (!file_exists($path)) {
            return new WP_Error('wpsc_file_missing', __('Uploaded file could not be found.', 'wp-smart-chatbot'));
        }

        if (function_exists('curl_init') && function_exists('curl_file_create')) {
            return $this->upload_file_with_curl($path, $filename);
        }

        $contents = file_get_contents($path);
        if ($contents === false) {
            return new WP_Error('wpsc_file_read_failed', __('Uploaded file could not be read.', 'wp-smart-chatbot'));
        }

        $boundary = wp_generate_password(24, false);
        $body = "--$boundary\r\n";
        $body .= "Content-Disposition: form-data; name=\"purpose\"\r\n\r\nassistants\r\n";
        $body .= "--$boundary\r\n";
        $body .= 'Content-Disposition: form-data; name="file"; filename="' . sanitize_file_name($filename) . "\"\r\n";
        $body .= "Content-Type: application/octet-stream\r\n\r\n";
        $body .= $contents . "\r\n";
        $body .= "--$boundary--\r\n";

        return $this->request('https://api.openai.com/v1/files', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
            ],
            'body' => $body,
            'timeout' => 60,
        ]);
    }

    private function upload_file_with_curl($path, $filename) {
        $ch = curl_init('https://api.openai.com/v1/files');
        if (!$ch) {
            return new WP_Error('wpsc_curl_unavailable', __('Could not initialise the file upload request.', 'wp-smart-chatbot'));
        }

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->api_key,
            ],
            CURLOPT_POSTFIELDS => [
                'purpose' => 'assistants',
                'file' => curl_file_create($path, 'application/octet-stream', sanitize_file_name($filename)),
            ],
        ]);

        $raw = curl_exec($ch);
        $error = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($raw === false) {
            return new WP_Error('wpsc_openai_upload_failed', $error ?: __('OpenAI upload failed.', 'wp-smart-chatbot'));
        }

        $body = json_decode($raw, true);
        if ($code < 200 || $code >= 300) {
            $message = isset($body['error']['message']) ? $body['error']['message'] : __('OpenAI request failed.', 'wp-smart-chatbot');
            return new WP_Error('wpsc_openai_error', $message, ['status' => $code, 'body' => $body]);
        }

        return is_array($body) ? $body : [];
    }

    public function create_vector_store($name) {
        return $this->request('https://api.openai.com/v1/vector_stores', [
            'headers' => $this->json_headers(),
            'body' => wp_json_encode(['name' => $name]),
            'timeout' => 30,
        ]);
    }

    public function attach_file_to_vector_store($vector_store_id, $file_id) {
        return $this->request('https://api.openai.com/v1/vector_stores/' . rawurlencode($vector_store_id) . '/files', [
            'headers' => $this->json_headers(),
            'body' => wp_json_encode(['file_id' => $file_id]),
            'timeout' => 30,
        ]);
    }

    public function get_vector_store_file($vector_store_id, $file_id) {
        if (!$this->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        $response = wp_remote_get('https://api.openai.com/v1/vector_stores/' . rawurlencode($vector_store_id) . '/files/' . rawurlencode($file_id), [
            'headers' => $this->json_headers(),
            'timeout' => 30,
        ]);
        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            $message = isset($body['error']['message']) ? $body['error']['message'] : __('OpenAI request failed.', 'wp-smart-chatbot');
            return new WP_Error('wpsc_openai_error', $message, ['status' => $code, 'body' => $body]);
        }

        return is_array($body) ? $body : [];
    }

    public function search_vector_store($vector_store_id, $query, $max_results = 5) {
        if (!$this->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        if (!$vector_store_id) {
            return new WP_Error('wpsc_openai_missing_vector_store', __('Vector store is not configured.', 'wp-smart-chatbot'));
        }

        return $this->request('https://api.openai.com/v1/vector_stores/' . rawurlencode($vector_store_id) . '/search', [
            'headers' => $this->json_headers(),
            'body' => wp_json_encode([
                'query' => sanitize_text_field($query),
                'max_num_results' => min(50, max(1, (int) $max_results)),
                'rewrite_query' => true,
                'ranking_options' => [
                    'ranker' => 'auto',
                ],
            ]),
            'timeout' => 30,
        ]);
    }

    private function json_headers() {
        return [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json',
        ];
    }

    private function request($url, $args) {
        $response = wp_remote_post($url, $args);
        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code < 200 || $code >= 300) {
            $message = isset($body['error']['message']) ? $body['error']['message'] : __('OpenAI request failed.', 'wp-smart-chatbot');
            return new WP_Error('wpsc_openai_error', $message, ['status' => $code, 'body' => $body]);
        }

        return is_array($body) ? $body : [];
    }
}
