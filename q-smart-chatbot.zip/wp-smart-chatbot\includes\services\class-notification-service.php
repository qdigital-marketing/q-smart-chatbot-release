<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Notification_Service {
    private $settings;

    public function __construct(WPSC_Settings_Service $settings) {
        $this->settings = $settings;
    }

    public function send_lead_notification($lead, $conversation = null) {
        $to = $this->settings->get('lead_email', get_option('admin_email'));
        $sent = false;
        if ($to) {
            $subject = sprintf(__('New Chatbot Lead from %s', 'wp-smart-chatbot'), get_bloginfo('name'));
            $body = "New lead captured from the website chatbot.\n\n";
            $body .= "Name: " . ($lead['name'] ?? '') . "\n";
            $body .= "Email: " . ($lead['email'] ?? '') . "\n";
            $body .= "Phone: " . ($lead['phone'] ?? '') . "\n";
            $body .= "Location: " . ($lead['location'] ?? '') . "\n";
            $body .= "Service: " . ($lead['service_interest'] ?? '') . "\n";
            $body .= "Message: " . ($lead['message'] ?? '') . "\n";

            if ($conversation) {
                $body .= "Page: " . ($conversation['current_url'] ?? '') . "\n";
                $body .= "Conversation ID: " . ($conversation['id'] ?? '') . "\n";
            }

            $sent = wp_mail($to, $subject, $body);
        }

        $webhook_sent = $this->send_webhook('lead_captured', [
            'title' => __('New chatbot lead', 'wp-smart-chatbot'),
            'message' => trim(sprintf('%s %s %s', $lead['name'] ?? '', $lead['phone'] ?? '', $lead['email'] ?? '')),
            'lead' => $lead,
            'conversation' => $conversation,
        ]);

        return [
            'email_sent' => (bool) $sent,
            'webhook_sent' => (bool) $webhook_sent,
        ];
    }

    public function send_handover_notification($conversation) {
        $to = $this->settings->get('support_email', get_option('admin_email'));
        $sent = false;
        if ($to) {
            $subject = sprintf(__('Chatbot handover requested on %s', 'wp-smart-chatbot'), get_bloginfo('name'));
            $body = "A visitor requested a human handover.\n\nConversation ID: " . ($conversation['id'] ?? '') . "\nCurrent page: " . ($conversation['current_url'] ?? '');
            $sent = wp_mail($to, $subject, $body);
        }

        $webhook_sent = $this->send_webhook('handover_requested', [
            'title' => __('Chatbot handover requested', 'wp-smart-chatbot'),
            'message' => sprintf(__('Conversation #%s is waiting for a reply.', 'wp-smart-chatbot'), $conversation['id'] ?? ''),
            'conversation' => $conversation,
        ]);

        return [
            'email_sent' => (bool) $sent,
            'webhook_sent' => (bool) $webhook_sent,
        ];
    }

    private function send_webhook($event, $payload) {
        if ($this->settings->get('notification_webhook_enabled', '0') !== '1') {
            return false;
        }

        $url = esc_url_raw($this->settings->get('notification_webhook_url', ''));
        if (!$url) {
            return false;
        }

        $conversation = $payload['conversation'] ?? null;
        $payload = array_merge([
            'event' => $event,
            'site_name' => get_bloginfo('name'),
            'site_url' => home_url('/'),
            'admin_conversation_url' => $conversation && !empty($conversation['id'])
                ? admin_url('admin.php?page=wpsc-conversations&conversation_id=' . absint($conversation['id']))
                : admin_url('admin.php?page=wpsc-conversations'),
            'created_at' => current_time('mysql'),
        ], $payload);

        $response = wp_remote_post($url, [
            'timeout' => 8,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]);

        return !is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) < 400;
    }
}
