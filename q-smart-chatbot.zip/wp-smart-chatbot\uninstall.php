<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

$settings = get_option('wpsc_settings', []);
$delete_data = get_option('wpsc_delete_data_on_uninstall', is_array($settings) ? ($settings['delete_data_on_uninstall'] ?? '0') : '0');

if ($delete_data === '1') {
    global $wpdb;

    foreach (['conversations', 'messages', 'leads', 'canned_responses', 'documents', 'events'] as $table) {
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}wpsc_{$table}");
    }

    delete_option('wpsc_settings');
    delete_option('wpsc_db_version');
    delete_option('wpsc_delete_data_on_uninstall');

    $uploads = wp_upload_dir();
    $media_dir = trailingslashit($uploads['basedir']) . 'wpsc-chatbot-media';
    if (is_dir($media_dir)) {
        $base_dir = realpath($media_dir);
        if ($base_dir) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($iterator as $item) {
                $real_path = realpath($item->getPathname());
                if (!$real_path || ($real_path !== $base_dir && strpos($real_path, $base_dir . DIRECTORY_SEPARATOR) !== 0)) {
                    continue;
                }
                if ($item->isFile()) {
                    wp_delete_file($real_path);
                } elseif ($item->isDir()) {
                    @rmdir($real_path);
                }
            }
            @rmdir($base_dir);
        }
    }
}
