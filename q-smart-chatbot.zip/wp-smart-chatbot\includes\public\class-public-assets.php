<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Public_Assets {
    private $settings;

    public function __construct(WPSC_Settings_Service $settings) {
        $this->settings = $settings;
    }

    public function register() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
        add_action('wp_footer', [$this, 'render_widget']);
    }

    public function enqueue() {
        if ($this->settings->get('enabled') !== '1') {
            return;
        }

        wp_enqueue_style('wpsc-widget', WPSC_PLUGIN_URL . 'assets/public/css/chatbot-widget.css', [], WPSC_VERSION);
        wp_enqueue_script('wpsc-widget', WPSC_PLUGIN_URL . 'assets/public/js/chatbot-widget.js', [], WPSC_VERSION, true);
        wp_localize_script('wpsc-widget', 'WPSCWidget', [
            'restUrl' => esc_url_raw(rest_url(WPSC_REST_NAMESPACE)),
            'siteUrl' => home_url('/'),
        ]);
    }

    public function render_widget() {
        if ($this->settings->get('enabled') !== '1') {
            return;
        }

        echo '<div id="wpsc-chatbot-root" class="wpsc-chatbot-root" aria-live="polite"></div>';
    }
}
