<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Admin_Menu {
    private $settings;
    private $repository;

    public function __construct(WPSC_Settings_Service $settings, WPSC_Repository $repository) {
        $this->settings = $settings;
        $this->repository = $repository;
    }

    public function register() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_bar_menu', [$this, 'admin_bar_badge'], 80);
        add_action('admin_head', [$this, 'admin_bar_styles']);
        add_action('admin_notices', [$this, 'pending_response_notice']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_init', [$this, 'handle_actions']);
    }

    public function add_menu() {
        $pending = $this->repository->pending_response_count();
        $badge = $pending ? ' <span class="awaiting-mod">' . esc_html($pending) . '</span>' : '';
        add_menu_page(__('Q Digital Chatbot', 'wp-smart-chatbot'), __('Q Digital Chatbot', 'wp-smart-chatbot') . $badge, 'manage_options', 'wpsc-dashboard', [$this, 'dashboard_page'], WPSC_PLUGIN_URL . 'assets/admin/images/Q-logo.png', 58);
        add_submenu_page('wpsc-dashboard', __('Dashboard', 'wp-smart-chatbot'), __('Dashboard', 'wp-smart-chatbot'), 'manage_options', 'wpsc-dashboard', [$this, 'dashboard_page']);
        add_submenu_page('wpsc-dashboard', __('Conversations', 'wp-smart-chatbot'), __('Conversations', 'wp-smart-chatbot') . $badge, 'manage_options', 'wpsc-conversations', [$this, 'conversations_page']);
        add_submenu_page('wpsc-dashboard', __('Leads', 'wp-smart-chatbot'), __('Leads', 'wp-smart-chatbot'), 'manage_options', 'wpsc-leads', [$this, 'leads_page']);
        add_submenu_page('wpsc-dashboard', __('Feedback Scores', 'wp-smart-chatbot'), __('Feedback Scores', 'wp-smart-chatbot'), 'manage_options', 'wpsc-feedback', [$this, 'feedback_page']);
        add_submenu_page('wpsc-dashboard', __('Reported Bugs', 'wp-smart-chatbot'), __('Reported Bugs', 'wp-smart-chatbot'), 'manage_options', 'wpsc-reported-bugs', [$this, 'reported_bugs_page']);
        add_submenu_page('wpsc-dashboard', __('Forms', 'wp-smart-chatbot'), __('Forms', 'wp-smart-chatbot'), 'manage_options', 'wpsc-forms', [$this, 'forms_page']);
        add_submenu_page('wpsc-dashboard', __('Knowledgebase', 'wp-smart-chatbot'), __('Knowledgebase', 'wp-smart-chatbot'), 'manage_options', 'wpsc-knowledgebase', [$this, 'knowledgebase_page']);
        add_submenu_page('wpsc-dashboard', __('Chat Media', 'wp-smart-chatbot'), __('Chat Media', 'wp-smart-chatbot'), 'manage_options', 'wpsc-chat-media', [$this, 'chat_media_page']);
        add_submenu_page('wpsc-dashboard', __('Canned Responses', 'wp-smart-chatbot'), __('Canned Responses', 'wp-smart-chatbot'), 'manage_options', 'wpsc-canned-responses', [$this, 'canned_page']);
        add_submenu_page('wpsc-dashboard', __('Flow Builder', 'wp-smart-chatbot'), __('Flow Builder', 'wp-smart-chatbot'), 'manage_options', 'wpsc-flow-builder', [$this, 'flow_builder_page']);
        add_submenu_page('wpsc-dashboard', __('Branding', 'wp-smart-chatbot'), __('Branding', 'wp-smart-chatbot'), 'manage_options', 'wpsc-branding', [$this, 'branding_page']);
        add_submenu_page('wpsc-dashboard', __('AI Settings', 'wp-smart-chatbot'), __('AI Settings', 'wp-smart-chatbot'), 'manage_options', 'wpsc-ai-settings', [$this, 'ai_page']);
        add_submenu_page('wpsc-dashboard', __('Notifications', 'wp-smart-chatbot'), __('Notifications', 'wp-smart-chatbot'), 'manage_options', 'wpsc-notifications', [$this, 'notifications_page']);
        add_submenu_page('wpsc-dashboard', __('Settings', 'wp-smart-chatbot'), __('Settings', 'wp-smart-chatbot'), 'manage_options', 'wpsc-settings', [$this, 'settings_page']);
        add_submenu_page('wpsc-dashboard', __('Import / Export', 'wp-smart-chatbot'), __('Import / Export', 'wp-smart-chatbot'), 'manage_options', 'wpsc-import-export', [$this, 'import_export_page']);
        add_submenu_page('wpsc-dashboard', __('Documentation', 'wp-smart-chatbot'), __('Documentation', 'wp-smart-chatbot'), 'manage_options', 'wpsc-documentation', [$this, 'documentation_page']);
    }

    public function admin_bar_badge($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }

        $pending = $this->repository->pending_response_count();
        $wp_admin_bar->add_node([
            'id' => 'wpsc-pending-replies',
            'title' => $pending ? sprintf(__('Q Digital Chatbot: %d waiting for reply', 'wp-smart-chatbot'), $pending) : __('Q Digital Chatbot', 'wp-smart-chatbot'),
            'href' => admin_url('admin.php?page=wpsc-conversations&status=waiting_human'),
            'meta' => ['class' => $pending ? 'wpsc-admin-bar-alert' : ''],
        ]);
    }

    public function pending_response_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || strpos($screen->id, 'wpsc') === false) {
            return;
        }

        $pending = $this->repository->pending_response_count();
        if (!$pending) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>Q Digital Chatbot:</strong> ' . esc_html(sprintf(_n('%d visitor is waiting for a reply.', '%d visitors are waiting for a reply.', $pending, 'wp-smart-chatbot'), $pending)) . ' <a href="' . esc_url(admin_url('admin.php?page=wpsc-conversations&status=waiting_human')) . '">View conversations</a></p></div>';
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'wpsc-') === false) {
            return;
        }

        wp_enqueue_style('wpsc-admin', WPSC_PLUGIN_URL . 'assets/admin/css/admin.css', [], WPSC_VERSION);
        wp_enqueue_script('wpsc-admin', WPSC_PLUGIN_URL . 'assets/admin/js/admin.js', ['jquery'], WPSC_VERSION, true);
        wp_enqueue_media();
        wp_localize_script('wpsc-admin', 'WPSCAdmin', [
            'restUrl' => esc_url_raw(rest_url(WPSC_REST_NAMESPACE)),
            'nonce' => wp_create_nonce('wp_rest'),
            'conversationPollMs' => 3000,
            'notificationPollMs' => 5000,
            'conversationsUrl' => admin_url('admin.php?page=wpsc-conversations&status=waiting_human'),
        ]);
    }

    public function admin_bar_styles() {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<style>
            #adminmenu #toplevel_page_wpsc-dashboard .wp-menu-image{display:flex;align-items:center;justify-content:center;}
            #adminmenu #toplevel_page_wpsc-dashboard .wp-menu-image img{width:18px!important;height:18px!important;max-width:18px!important;max-height:18px!important;object-fit:contain;padding:0!important;opacity:1;}
            #wpadminbar .wpsc-admin-bar-alert > .ab-item{background:#b32d2e!important;color:#fff!important;}
        </style>';
    }

    public function handle_actions() {
        if (!current_user_can('manage_options') || empty($_POST['wpsc_action'])) {
            return;
        }

        $action = sanitize_key(wp_unslash($_POST['wpsc_action']));

        if ($action === 'save_settings') {
            check_admin_referer('wpsc_save_settings');
            $this->settings->update(wp_unslash($_POST['wpsc'] ?? []));
            $this->update_business_info_flow();
            $this->redirect_with_notice('settings_saved');
        }

        if ($action === 'save_canned') {
            check_admin_referer('wpsc_save_canned');
            $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
            $this->repository->save_canned_response($this->prepare_canned_form_data(wp_unslash($_POST['canned'] ?? [])), $id);
            $this->redirect_with_notice('canned_saved');
        }

        if ($action === 'delete_canned') {
            check_admin_referer('wpsc_delete_canned');
            $this->repository->delete_canned_response((int) ($_POST['id'] ?? 0));
            $this->redirect_with_notice('canned_deleted');
        }

        if ($action === 'save_flow_builder') {
            check_admin_referer('wpsc_save_flow_builder');
            $this->save_flow_builder(wp_unslash($_POST['flow'] ?? []));
            $this->redirect_to_page('wpsc-flow-builder', 'flow_saved');
        }

        if ($action === 'conversation_reply') {
            check_admin_referer('wpsc_conversation_reply');
            $conversation_id = (int) ($_POST['conversation_id'] ?? 0);
            $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
            if ($conversation_id && $message) {
                $agent_name = sanitize_text_field(wp_unslash($_POST['agent_name'] ?? ''));
                if (!$agent_name) {
                    $agent_name = $this->default_agent_reply_name();
                }
                $this->repository->update_conversation($conversation_id, ['status' => 'human']);
                $this->repository->add_message($conversation_id, 'agent', $message, [
                    'sender_id' => get_current_user_id(),
                    'metadata' => [
                        'agent_name' => $agent_name,
                        'agent_name_mode' => $this->settings->get('agent_name_mode', 'team'),
                    ],
                ]);
                delete_transient('wpsc_typing_' . $conversation_id);
            }
            $this->redirect_with_notice('reply_sent');
        }

        if ($action === 'conversation_lead_request') {
            check_admin_referer('wpsc_conversation_lead_request');
            $conversation_id = (int) ($_POST['conversation_id'] ?? 0);
            if ($conversation_id) {
                $form_type = sanitize_key($_POST['form_type'] ?? 'lead');
                $forms = $this->admin_form_request_types();
                if (empty($forms[$form_type])) {
                    $form_type = 'lead';
                }
                $this->repository->update_conversation($conversation_id, ['status' => 'human']);
                $message = $forms[$form_type]['message'];
                $created = $this->repository->add_message($conversation_id, 'bot', $message, [
                    'sender_id' => get_current_user_id(),
                    'metadata' => [
                        'action_type' => 'ask_contact',
                        'form_type' => $forms[$form_type]['form_type'] ?? $form_type,
                        'form_label' => $forms[$form_type]['label'],
                        'custom_form' => $forms[$form_type]['custom_form'] ?? null,
                        'source' => 'agent_form_request',
                    ],
                ]);
                $this->repository->add_event('agent_requested_' . $form_type . '_details', ['message_id' => $created['id']], $conversation_id);
            }
            $this->redirect_with_notice('lead_request_sent');
        }

        if ($action === 'delete_conversation') {
            check_admin_referer('wpsc_delete_conversation');
            $this->repository->delete_conversation((int) ($_POST['conversation_id'] ?? 0));
            $this->redirect_to_page('wpsc-conversations', 'conversation_deleted');
        }

        if ($action === 'update_conversation_status') {
            check_admin_referer('wpsc_conversation_status');
            $this->repository->update_conversation((int) ($_POST['conversation_id'] ?? 0), ['status' => sanitize_key($_POST['status'] ?? 'bot')]);
            $this->redirect_with_notice('status_updated');
        }

        if ($action === 'update_lead_followup') {
            check_admin_referer('wpsc_update_lead_followup');
            $status = !empty($_POST['followed_up']) ? 'contacted' : 'new';
            $this->repository->update_lead((int) ($_POST['lead_id'] ?? 0), ['status' => $status]);
            $this->redirect_to_page('wpsc-leads', 'lead_updated');
        }

        if ($action === 'delete_lead') {
            check_admin_referer('wpsc_delete_lead');
            $this->repository->delete_lead((int) ($_POST['lead_id'] ?? 0));
            $this->redirect_to_page('wpsc-leads', 'lead_deleted');
        }

        if ($action === 'save_custom_form') {
            check_admin_referer('wpsc_save_custom_form');
            $this->settings->save_custom_form(wp_unslash($_POST['custom_form'] ?? []));
            $this->redirect_to_page('wpsc-forms', 'form_saved');
        }

        if ($action === 'delete_custom_form') {
            check_admin_referer('wpsc_delete_custom_form');
            $this->settings->delete_custom_form(wp_unslash($_POST['form_id'] ?? ''));
            $this->redirect_to_page('wpsc-forms', 'form_deleted');
        }

        if ($action === 'duplicate_custom_form') {
            check_admin_referer('wpsc_duplicate_custom_form');
            $source_id = sanitize_key(wp_unslash($_POST['form_id'] ?? ''));
            foreach ($this->settings->custom_forms() as $form) {
                if ($form['id'] === $source_id) {
                    $form['id'] = '';
                    $form['name'] = $form['name'] . ' copy';
                    $this->settings->save_custom_form($form);
                    break;
                }
            }
            $this->redirect_to_page('wpsc-forms', 'form_duplicated');
        }

        if ($action === 'export_leads') {
            check_admin_referer('wpsc_export_leads');
            $this->export_leads_csv();
        }

        if ($action === 'upload_document') {
            check_admin_referer('wpsc_upload_document');
            $uploaded = $this->handle_document_upload();
            $this->redirect_to_page('wpsc-knowledgebase', $uploaded ? 'document_uploaded' : 'document_upload_failed');
        }

        if ($action === 'save_kb_source') {
            check_admin_referer('wpsc_save_kb_source');
            $saved = $this->handle_knowledge_source();
            $this->redirect_to_page('wpsc-knowledgebase', $saved ? 'knowledge_source_saved' : 'knowledge_source_failed');
        }

        if ($action === 'test_retrieval') {
            check_admin_referer('wpsc_test_retrieval');
            $this->handle_retrieval_test();
            $this->redirect_to_page('wpsc-knowledgebase', 'retrieval_test_complete');
        }

        if ($action === 'retry_document_index') {
            check_admin_referer('wpsc_retry_document_index');
            $indexed = $this->retry_document_index((int) ($_POST['document_id'] ?? 0));
            $this->redirect_to_page('wpsc-knowledgebase', $indexed ? 'document_indexed' : 'document_index_failed');
        }

        if ($action === 'delete_document') {
            check_admin_referer('wpsc_delete_document');
            $this->repository->delete_document((int) ($_POST['document_id'] ?? 0), true);
            $this->redirect_to_page('wpsc-knowledgebase', 'document_deleted');
        }

        if ($action === 'clear_chat_media') {
            check_admin_referer('wpsc_clear_chat_media');
            $deleted = wpsc_clear_chat_media();
            $this->set_admin_notice(sprintf('Cleared %d chatbot media files.', $deleted), 'success');
            $this->redirect_to_page('wpsc-chat-media', 'chat_media_cleared');
        }

        if ($action === 'clear_old_chat_media') {
            check_admin_referer('wpsc_clear_old_chat_media');
            $days = (int) $this->settings->get('media_retention_days', '30');
            $deleted = wpsc_clear_old_chat_media($days);
            $this->set_admin_notice(sprintf('Cleared %d chatbot media files older than %d days.', $deleted, $days), 'success');
            $this->redirect_to_page('wpsc-chat-media', 'chat_media_old_cleared');
        }

        if ($action === 'export_settings') {
            check_admin_referer('wpsc_export_settings');
            $this->export_settings();
        }

        if ($action === 'import_settings') {
            check_admin_referer('wpsc_import_settings');
            $imported = $this->import_settings();
            $this->redirect_with_notice($imported ? 'import_complete' : 'import_failed');
        }

        if ($action === 'ai_generate_canned') {
            check_admin_referer('wpsc_ai_generate_canned');
            $created = $this->ai_generate_canned();
            $this->redirect_with_notice($created ? 'ai_responses_created' : 'ai_generation_failed');
        }
    }

    private function admin_page_header($title, $description = '', $cta_url = '', $cta_label = '', $variant = 'compact') {
        $header_class = $variant === 'hero' ? 'wpsc-dashboard-hero' : 'wpsc-admin-page-header';
        $logo = '<img class="wpsc-dashboard-logo" src="' . esc_url(WPSC_PLUGIN_URL . 'assets/admin/images/q-digital-logo.svg') . '" alt="Q Digital Marketing">';
        echo '<div class="' . esc_attr($header_class) . '"><div class="wpsc-admin-page-title">';
        if ($variant === 'hero') {
            echo $logo;
        }
        echo '<h1>' . esc_html($title) . '</h1>';
        if ($description !== '') {
            echo '<p>' . esc_html($description) . '</p>';
        }
        echo '</div>';
        if (($cta_url && $cta_label) || $variant !== 'hero') {
            echo '<div class="wpsc-admin-page-actions">';
            if ($cta_url && $cta_label) {
                echo '<a class="button button-primary wpsc-dashboard-cta" href="' . esc_url($cta_url) . '">' . esc_html($cta_label) . '</a>';
            }
            if ($variant !== 'hero') {
                echo $logo;
            }
            echo '</div>';
        }
        echo '</div>';
        $this->admin_subpage_nav();
    }

    private function admin_subpage_nav() {
        $current_page = sanitize_key(wp_unslash($_GET['page'] ?? 'wpsc-dashboard'));
        $items = [
            'wpsc-dashboard' => __('Dashboard', 'wp-smart-chatbot'),
            'wpsc-conversations' => __('Chats', 'wp-smart-chatbot'),
            'wpsc-leads' => __('Leads', 'wp-smart-chatbot'),
            'wpsc-feedback' => __('Feedback', 'wp-smart-chatbot'),
            'wpsc-reported-bugs' => __('Bugs', 'wp-smart-chatbot'),
            'wpsc-forms' => __('Forms', 'wp-smart-chatbot'),
            'wpsc-knowledgebase' => __('Knowledgebase', 'wp-smart-chatbot'),
            'wpsc-chat-media' => __('Media', 'wp-smart-chatbot'),
            'wpsc-canned-responses' => __('Canned', 'wp-smart-chatbot'),
            'wpsc-flow-builder' => __('Flows', 'wp-smart-chatbot'),
            'wpsc-branding' => __('Branding', 'wp-smart-chatbot'),
            'wpsc-ai-settings' => __('AI', 'wp-smart-chatbot'),
            'wpsc-notifications' => __('Notifications', 'wp-smart-chatbot'),
            'wpsc-settings' => __('Settings', 'wp-smart-chatbot'),
            'wpsc-import-export' => __('Import/Export', 'wp-smart-chatbot'),
            'wpsc-documentation' => __('Docs', 'wp-smart-chatbot'),
        ];

        echo '<nav class="wpsc-admin-subnav" aria-label="' . esc_attr__('Q Digital Chatbot sections', 'wp-smart-chatbot') . '">';
        foreach ($items as $page => $label) {
            $is_active = $current_page === $page;
            echo '<a' . ($is_active ? ' class="is-active" aria-current="page"' : '') . ' href="' . esc_url(admin_url('admin.php?page=' . $page)) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav>';
    }

    public function dashboard_page() {
        $counts = $this->repository->dashboard_counts();
        $feedback = $this->repository->feedback_counts();
        $filter = sanitize_key($_GET['wpsc_filter'] ?? 'active_chats');
        $valid_filters = ['active_chats', 'waiting_human', 'new_chats', 'new_leads', 'recent'];
        if (!in_array($filter, $valid_filters, true)) {
            $filter = 'active_chats';
        }
        $date_from = $this->sanitize_date_param($_GET['lead_from'] ?? '');
        $date_to = $this->sanitize_date_param($_GET['lead_to'] ?? '');

        echo '<div class="wrap wpsc-admin wpsc-dashboard">';
        $this->admin_page_header('Q Digital Chatbot', 'Monitor conversations, leads, feedback, and handovers from one operational dashboard.', admin_url('admin.php?page=wpsc-conversations&status=waiting_human'), 'Open inbox', 'hero');
        $this->notice();
        echo '<div class="wpsc-metrics wpsc-filter-metrics">';
        $metric_filters = [
            'active_chats' => ['label' => __('Active Chats', 'wp-smart-chatbot'), 'value' => $counts['active_chats'] ?? 0, 'status' => 'progress'],
            'waiting_human' => ['label' => __('Chats Waiting', 'wp-smart-chatbot'), 'value' => $counts['waiting_human'] ?? 0, 'status' => 'warning'],
            'new_chats' => ['label' => __('New Chats', 'wp-smart-chatbot'), 'value' => $counts['new_chats'] ?? 0, 'status' => 'info'],
            'new_leads' => ['label' => __('New Leads', 'wp-smart-chatbot'), 'value' => $counts['new_leads'] ?? 0, 'status' => 'success'],
        ];
        foreach ($metric_filters as $key => $metric) {
            $url = add_query_arg(['page' => 'wpsc-dashboard', 'wpsc_filter' => $key], admin_url('admin.php'));
            echo '<a class="wpsc-metric wpsc-filter-card ' . esc_attr($filter === $key ? 'is-active' : '') . '" href="' . esc_url($url) . '"><span class="wpsc-status-badge wpsc-status-' . esc_attr($metric['status']) . '">' . esc_html($metric['label']) . '</span><strong>' . esc_html(number_format_i18n($metric['value'])) . '</strong><span>View filtered records</span></a>';
        }
        echo '<div class="wpsc-metric"><span class="wpsc-status-badge wpsc-status-success">Positive Ratings</span><strong>' . esc_html(number_format_i18n($feedback['positive'])) . '</strong><span>Recent feedback score</span></div>';
        echo '<div class="wpsc-metric"><span class="wpsc-status-badge wpsc-status-danger">Negative Ratings</span><strong>' . esc_html(number_format_i18n($feedback['negative'])) . '</strong><span>Needs review</span></div>';
        echo '<a class="wpsc-metric wpsc-filter-card" href="' . esc_url(admin_url('admin.php?page=wpsc-reported-bugs')) . '"><span class="wpsc-status-badge wpsc-status-warning">Reported Bugs</span><strong>' . esc_html(number_format_i18n($counts['reported_bugs'] ?? 0)) . '</strong><span>Open issue log</span></a>';
        echo '</div>';

        echo '<form method="get" class="wpsc-dashboard-filters">';
        echo '<input type="hidden" name="page" value="wpsc-dashboard">';
        echo '<input type="hidden" name="wpsc_filter" value="' . esc_attr($filter) . '">';
        echo '<label>Lead date from <input type="date" name="lead_from" value="' . esc_attr($date_from) . '"></label>';
        echo '<label>to <input type="date" name="lead_to" value="' . esc_attr($date_to) . '"></label>';
        submit_button(__('Apply date range', 'wp-smart-chatbot'), 'secondary', 'submit', false);
        echo '</form>';

        if ($filter === 'new_leads') {
            echo '<h2 class="wpsc-section-title">New Leads</h2>';
            $this->lead_snapshot_table($this->repository->list_leads(100, [
                'status' => 'new',
                'date_from' => $date_from,
                'date_to' => $date_to,
            ]));
        } else {
            $conversation_args = ['limit' => 25];
            if ($filter === 'active_chats') {
                $conversation_args['statuses'] = ['bot', 'human', 'waiting_human'];
            } elseif ($filter === 'waiting_human') {
                $conversation_args['status'] = 'waiting_human';
            } elseif ($filter === 'new_chats') {
                $conversation_args['status'] = 'bot';
            }
            $title = [
                'active_chats' => __('Active Chats', 'wp-smart-chatbot'),
                'waiting_human' => __('Chats Waiting for Reply', 'wp-smart-chatbot'),
                'new_chats' => __('New Chats', 'wp-smart-chatbot'),
                'recent' => __('Recent Conversations', 'wp-smart-chatbot'),
            ][$filter] ?? __('Recent Conversations', 'wp-smart-chatbot');
            echo '<h2 class="wpsc-section-title">' . esc_html($title) . '</h2>';
            $this->conversation_table($this->repository->list_conversations($conversation_args), true);
        }

        echo '<h2 class="wpsc-section-title">Recent Feedback</h2>';
        $this->feedback_table($this->repository->list_feedback_events(5));
        echo '<h2 class="wpsc-section-title">Recent Bug Reports</h2>';
        $this->bug_reports_table($this->repository->list_bug_report_events(5));
        echo '</div>';
    }

    public function feedback_page() {
        $counts = $this->repository->feedback_counts();
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Feedback Scores');
        $this->notice();
        echo '<div class="wpsc-metrics">';
        foreach ($counts as $label => $value) {
            echo '<div class="wpsc-metric"><strong>' . esc_html(number_format_i18n($value)) . '</strong><span>' . esc_html(ucwords(str_replace('_', ' ', $label))) . '</span></div>';
        }
        echo '</div>';
        $this->feedback_table($this->repository->list_feedback_events(100));
        echo '</div>';
    }

    public function reported_bugs_page() {
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Reported Bugs');
        $this->notice();
        echo '<p>Bug reports submitted from the chat widget are stored here. Open the linked conversation to see what the visitor was doing around the report.</p>';
        $this->bug_reports_table($this->repository->list_bug_report_events(200));
        echo '</div>';
    }

    public function conversations_page() {
        $selected = isset($_GET['conversation_id']) ? (int) $_GET['conversation_id'] : 0;
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Conversations');
        $this->notice();
        echo '<div class="wpsc-inbox">';
        echo '<div class="wpsc-conversation-list">';
        $this->conversation_table($this->repository->list_conversations(['limit' => 50]), true);
        echo '</div><div class="wpsc-panel">';
        if ($selected) {
            $conversation = $this->repository->get_conversation($selected);
            $messages = $this->repository->list_messages($selected, 0);
            echo '<h2>Conversation #' . esc_html($selected) . '</h2>';
            if ($conversation) {
                $last_message_id = 0;
                foreach ($messages as $message) {
                    $last_message_id = max($last_message_id, (int) $message['id']);
                }
                echo '<p>Status: <strong class="wpsc-conversation-status">' . esc_html($conversation['status']) . '</strong></p>';
                echo '<p>Current page: ' . esc_html($conversation['current_url']) . '</p>';
                echo '<div class="wpsc-conversation-lead-summary">';
                echo $this->conversation_lead_summary_html($conversation);
                echo '</div>';
                echo '<div class="wpsc-transcript" data-conversation-id="' . esc_attr($selected) . '" data-last-message-id="' . esc_attr($last_message_id) . '">';
                foreach ($messages as $message) {
                    echo $this->conversation_message_html($message);
                }
                echo '</div>';
                $this->conversation_reply_form($selected);
                $this->conversation_lead_request_form($selected);
                $this->conversation_status_form($selected, $conversation['status']);
                $this->conversation_delete_form($selected);
            }
        } else {
            echo '<p>Select a conversation to view the transcript and reply.</p>';
        }
        echo '</div></div></div>';
    }

    public function leads_page() {
        $settings = $this->settings->all();
        $enabled_types = array_filter($this->admin_form_request_types(), function ($form, $type) use ($settings) {
            return ($settings['admin_quick_' . $type . '_enabled'] ?? '1') === '1';
        }, ARRAY_FILTER_USE_BOTH);
        if (!$enabled_types) {
            $enabled_types = ['lead' => $this->admin_form_request_types()['lead']];
        }
        $selected_type = sanitize_key($_GET['lead_type'] ?? array_key_first($enabled_types));
        if (empty($enabled_types[$selected_type])) {
            $selected_type = array_key_first($enabled_types);
        }
        $date_from = $this->sanitize_date_param($_GET['lead_from'] ?? '');
        $date_to = $this->sanitize_date_param($_GET['lead_to'] ?? '');

        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Leads');
        $this->notice();
        echo '<nav class="nav-tab-wrapper wpsc-lead-tabs">';
        foreach ($enabled_types as $type => $form) {
            $url = admin_url('admin.php?page=wpsc-leads&lead_type=' . $type);
            echo '<a class="nav-tab ' . esc_attr($selected_type === $type ? 'nav-tab-active' : '') . '" href="' . esc_url($url) . '">' . esc_html($form['tab']) . '</a>';
        }
        echo '</nav>';
        echo '<form method="get" class="wpsc-dashboard-filters">';
        echo '<input type="hidden" name="page" value="wpsc-leads">';
        echo '<input type="hidden" name="lead_type" value="' . esc_attr($selected_type) . '">';
        echo '<label>Lead date from <input type="date" name="lead_from" value="' . esc_attr($date_from) . '"></label>';
        echo '<label>to <input type="date" name="lead_to" value="' . esc_attr($date_to) . '"></label>';
        submit_button(__('Apply date range', 'wp-smart-chatbot'), 'secondary', 'submit', false);
        echo '</form>';
        echo '<form method="post" class="wpsc-toolbar">';
        wp_nonce_field('wpsc_export_leads');
        echo '<input type="hidden" name="wpsc_action" value="export_leads"><input type="hidden" name="lead_type" value="' . esc_attr($selected_type) . '"><input type="hidden" name="lead_from" value="' . esc_attr($date_from) . '"><input type="hidden" name="lead_to" value="' . esc_attr($date_to) . '">';
        submit_button(__('Export leads CSV', 'wp-smart-chatbot'), 'secondary', 'submit', false);
        echo '</form>';
        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Business</th><th>' . esc_html($enabled_types[$selected_type]['detail_label']) . '</th><th>Details</th><th>Status</th><th>Followed up</th><th>Created</th><th></th></tr></thead><tbody>';
        $shown = 0;
        foreach ($this->repository->list_leads(500, ['date_from' => $date_from, 'date_to' => $date_to]) as $lead) {
            if ($this->lead_type_for_lead($lead) !== $selected_type) {
                continue;
            }
            $shown++;
            $details = $this->lead_details_for_display($lead);
            echo '<tr><td>' . esc_html($lead['name']) . '</td><td>' . esc_html($lead['email']) . '</td><td>' . esc_html($lead['phone']) . '</td><td>' . esc_html($lead['company']) . '</td><td>' . esc_html($details['primary']) . '</td><td>' . esc_html($details['summary']) . '</td><td>' . esc_html($lead['status']) . '</td><td>';
            echo '<form method="post" class="wpsc-inline-form">';
            wp_nonce_field('wpsc_update_lead_followup');
            echo '<input type="hidden" name="wpsc_action" value="update_lead_followup"><input type="hidden" name="lead_id" value="' . esc_attr($lead['id']) . '">';
            echo '<label><input type="checkbox" name="followed_up" value="1" ' . checked($lead['status'] !== 'new', true, false) . ' onchange="this.form.submit()"> Followed up</label>';
            echo '</form></td><td>' . esc_html(wpsc_format_datetime($lead['created_at'])) . '</td><td>';
            echo '<form method="post" class="wpsc-inline-form">';
            wp_nonce_field('wpsc_delete_lead');
            echo '<input type="hidden" name="wpsc_action" value="delete_lead"><input type="hidden" name="lead_id" value="' . esc_attr($lead['id']) . '"><button class="button-link-delete" type="submit" onclick="return confirm(\'Delete this lead?\')">Delete</button></form>';
            echo '</td></tr>';
        }
        if (!$shown) {
            echo '<tr><td colspan="10">No ' . esc_html(strtolower($enabled_types[$selected_type]['tab'])) . ' yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private function knowledge_source_cards() {
        $sources = [
            'web' => ['icon' => 'dashicons-admin-site-alt3', 'title' => 'Web crawler', 'description' => 'Import public pages from your website'],
            'faq' => ['icon' => 'dashicons-editor-help', 'title' => 'FAQ', 'description' => 'Add question and answer pairs'],
            'rich' => ['icon' => 'dashicons-editor-paragraph', 'title' => 'Rich text', 'description' => 'Write instructions and policies'],
            'table' => ['icon' => 'dashicons-editor-table', 'title' => 'Tables', 'description' => 'Capture structured business data'],
            'file' => ['icon' => 'dashicons-upload', 'title' => 'File upload', 'description' => 'Upload supported documents'],
        ];

        echo '<div class="wpsc-kb-source-grid">';
        foreach ($sources as $key => $source) {
            echo '<button type="button" class="wpsc-kb-source-card" data-kb-source="' . esc_attr($key) . '"><span class="wpsc-kb-source-icon dashicons ' . esc_attr($source['icon']) . '" aria-hidden="true"></span><strong>' . esc_html($source['title']) . '</strong><span>' . esc_html($source['description']) . '</span><i aria-hidden="true">+</i></button>';
        }
        echo '</div>';

        echo '<div class="wpsc-kb-source-panels">';
        $this->knowledge_file_upload_panel();
        $this->knowledge_web_panel();
        $this->knowledge_faq_panel();
        $this->knowledge_rich_text_panel();
        $this->knowledge_table_panel();
        echo '</div>';
    }

    private function knowledge_file_upload_panel() {
        echo '<form method="post" enctype="multipart/form-data" class="wpsc-card wpsc-kb-source-panel" data-kb-panel="file">';
        wp_nonce_field('wpsc_upload_document');
        echo '<input type="hidden" name="wpsc_action" value="upload_document">';
        echo '<h2>Upload a document</h2><p class="description">PDF, DOC, DOCX, TXT, MD, HTML, CSV, and JSON files are supported.</p>';
        echo '<p><label>Title<br><input type="text" name="title" class="regular-text"></label></p>';
        echo '<p><input type="file" name="file" accept=".pdf,.doc,.docx,.txt,.md,.html,.htm,.csv,.json" required></p>';
        submit_button(__('Upload and index document', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function knowledge_web_panel() {
        echo '<form method="post" class="wpsc-card wpsc-kb-source-panel" data-kb-panel="web" hidden>';
        wp_nonce_field('wpsc_save_kb_source');
        echo '<input type="hidden" name="wpsc_action" value="save_kb_source"><input type="hidden" name="source_type" value="web">';
        echo '<h2>Import a public web page</h2><p class="description">Fetches readable page text, strips markup, saves it as a knowledge document, and indexes it.</p>';
        echo '<p><label>Page URL<br><input type="url" name="source_url" class="large-text" placeholder="https://example.com/services" required></label></p>';
        echo '<p><label>Title<br><input type="text" name="title" class="regular-text" placeholder="Optional"></label></p>';
        submit_button(__('Import and index page', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function knowledge_faq_panel() {
        echo '<form method="post" class="wpsc-card wpsc-kb-source-panel" data-kb-panel="faq" hidden>';
        wp_nonce_field('wpsc_save_kb_source');
        echo '<input type="hidden" name="wpsc_action" value="save_kb_source"><input type="hidden" name="source_type" value="faq">';
        echo '<h2>Add FAQ pairs</h2><p class="description">Great for common visitor questions that need precise answers.</p>';
        echo '<p><label>Title<br><input type="text" name="title" class="regular-text" placeholder="FAQ set"></label></p>';
        echo '<div class="wpsc-faq-pairs">';
        for ($i = 0; $i < 3; $i++) {
            echo '<div class="wpsc-faq-pair"><input type="text" name="faq_question[]" placeholder="Question"><textarea name="faq_answer[]" rows="3" placeholder="Answer"></textarea></div>';
        }
        echo '</div><button type="button" class="button wpsc-add-faq-pair">Add another pair</button>';
        submit_button(__('Save and index FAQ', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function knowledge_rich_text_panel() {
        echo '<form method="post" class="wpsc-card wpsc-kb-source-panel" data-kb-panel="rich" hidden>';
        wp_nonce_field('wpsc_save_kb_source');
        echo '<input type="hidden" name="wpsc_action" value="save_kb_source"><input type="hidden" name="source_type" value="rich">';
        echo '<h2>Write rich text</h2><p class="description">Use this for policies, service rules, tone notes, or special instructions.</p>';
        echo '<p><label>Title<br><input type="text" name="title" class="regular-text" required></label></p>';
        echo '<p><label>Content<br><textarea name="content" rows="8" class="large-text" required></textarea></label></p>';
        submit_button(__('Save and index text', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function knowledge_table_panel() {
        echo '<form method="post" class="wpsc-card wpsc-kb-source-panel" data-kb-panel="table" hidden>';
        wp_nonce_field('wpsc_save_kb_source');
        echo '<input type="hidden" name="wpsc_action" value="save_kb_source"><input type="hidden" name="source_type" value="table">';
        echo '<h2>Add table data</h2><p class="description">Paste CSV-style rows such as product, price, availability, suburb, or opening hour data.</p>';
        echo '<p><label>Title<br><input type="text" name="title" class="regular-text" required></label></p>';
        echo '<p><label>Rows<br><textarea name="content" rows="8" class="large-text" placeholder="Service, Area, Notes" required></textarea></label></p>';
        submit_button(__('Save and index table', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function retrieval_lab($retrieval) {
        $query = is_array($retrieval) ? ($retrieval['query'] ?? '') : '';
        $max = is_array($retrieval) ? (int) ($retrieval['max_results'] ?? 5) : 5;
        echo '<section class="wpsc-card wpsc-retrieval-lab"><span class="wpsc-dashboard-kicker">Retrieval Lab</span><h2>Test retrieval</h2><p class="description">Inspect the exact chunks selected before an answer is generated.</p>';
        echo '<form method="post" class="wpsc-retrieval-form">';
        wp_nonce_field('wpsc_test_retrieval');
        echo '<input type="hidden" name="wpsc_action" value="test_retrieval">';
        echo '<input type="text" name="retrieval_query" value="' . esc_attr($query) . '" placeholder="Ask a question your visitors might ask" required>';
        echo '<input type="number" name="max_results" min="1" max="50" value="' . esc_attr($max ?: 5) . '" aria-label="Number of chunks">';
        submit_button(__('Test', 'wp-smart-chatbot'), 'primary', 'submit', false);
        echo '</form>';
        $this->render_retrieval_result($retrieval);
        echo '</section>';
    }

    private function render_retrieval_result($retrieval) {
        if (!is_array($retrieval)) {
            echo '<p class="wpsc-muted">No retrieval test run yet.</p>';
            return;
        }

        if (!empty($retrieval['error'])) {
            echo '<p class="wpsc-retrieval-error">' . esc_html($retrieval['error']) . '</p>';
            return;
        }

        $results = !empty($retrieval['results']['data']) && is_array($retrieval['results']['data']) ? $retrieval['results']['data'] : [];
        if (!$results) {
            echo '<p class="wpsc-muted">No matching chunks were returned.</p>';
            return;
        }

        echo '<div class="wpsc-retrieval-results">';
        foreach ($results as $index => $result) {
            $chunks = [];
            foreach (($result['content'] ?? []) as $content) {
                if (!empty($content['text'])) {
                    $chunks[] = $content['text'];
                }
            }
            echo '<article class="wpsc-retrieval-result"><div><strong>Chunk ' . esc_html($index + 1) . '</strong><span>' . esc_html($result['filename'] ?? 'Knowledge document') . '</span></div>';
            echo '<span class="wpsc-status-badge wpsc-status-progress">Score ' . esc_html(isset($result['score']) ? number_format_i18n((float) $result['score'], 3) : 'n/a') . '</span>';
            echo '<p>' . esc_html(wp_trim_words(implode("\n\n", $chunks), 90)) . '</p></article>';
        }
        echo '</div>';
    }

    private function knowledge_gap_inbox() {
        $gaps = $this->knowledge_gap_candidates();
        echo '<section class="wpsc-card wpsc-knowledge-gaps"><div class="wpsc-section-heading"><div><span class="wpsc-dashboard-kicker">Improvement Inbox</span><h2>Knowledge gaps</h2><p class="description">Weak retrieval and negative visitor feedback are clustered into actionable topics.</p></div><a class="button" href="' . esc_url(admin_url('admin.php?page=wpsc-knowledgebase')) . '">Refresh</a></div>';
        if (!$gaps) {
            echo '<p class="wpsc-muted">No knowledge gaps yet. Negative feedback and bug reports will appear here as candidate topics.</p></section>';
            return;
        }

        foreach ($gaps as $gap) {
            echo '<div class="wpsc-gap-row"><div><strong>' . esc_html($gap['title']) . '</strong><span>' . esc_html($gap['summary']) . '</span></div><div><button type="button" class="button wpsc-kb-source-trigger" data-kb-source="faq" data-gap-question="' . esc_attr($gap['title']) . '">Add answer</button><a class="button" href="' . esc_url($gap['url']) . '">Review</a></div></div>';
        }
        echo '</section>';
    }

    private function knowledge_documents_panel() {
        $documents = $this->repository->list_documents();
        echo '<section class="wpsc-card wpsc-documents-panel"><div class="wpsc-section-heading"><div><span class="wpsc-dashboard-kicker">Indexed Content</span><h2>Documents</h2><p class="description">Track uploaded files and generated sources from ingestion through vector indexing.</p></div></div>';

        if (!$documents) {
            echo '<div class="wpsc-empty-state"><strong>No documents yet.</strong><span>Add a source above to create the first knowledge document.</span></div></section>';
            return;
        }

        echo '<div class="wpsc-document-list">';
        foreach ($documents as $document) {
            $status = sanitize_key($document['status'] ?? 'uploaded');
            $file_url = esc_url($document['file_path'] ?? '');
            $file_name = $document['file_name'] ?: __('Knowledge document', 'wp-smart-chatbot');
            $file_size = $this->document_file_size($document);

            echo '<article class="wpsc-document-row">';
            echo '<div class="wpsc-document-main">';
            echo '<span class="wpsc-status-badge wpsc-status-' . esc_attr($this->document_status_class($status)) . '">' . esc_html($this->document_status_label($status)) . '</span>';
            echo '<h3>' . esc_html($document['title']) . '</h3>';
            echo '<div class="wpsc-document-meta">';
            echo $file_url ? '<a href="' . $file_url . '">' . esc_html($file_name) . '</a>' : '<span>' . esc_html($file_name) . '</span>';
            if (!empty($document['mime_type'])) {
                echo '<span>' . esc_html($document['mime_type']) . '</span>';
            }
            if ($file_size) {
                echo '<span>' . esc_html($file_size) . '</span>';
            }
            echo '<span>Added ' . esc_html(wpsc_format_datetime($document['created_at'])) . '</span>';
            echo '<span>Updated ' . esc_html(wpsc_format_datetime($document['updated_at'])) . '</span>';
            echo '</div>';
            if (!empty($document['indexing_error'])) {
                echo '<p class="wpsc-document-message">' . esc_html($document['indexing_error']) . '</p>';
            }
            echo '</div>';

            echo '<dl class="wpsc-document-ids">';
            $vector_store_id = $document['vector_store_id'] ?: ($this->settings->get('openai_vector_store_id') ?: 'Not configured');
            echo '<div><dt>OpenAI File</dt><dd>' . esc_html($document['openai_file_id'] ?: 'Not created') . '</dd></div>';
            echo '<div><dt>Vector Store</dt><dd>' . esc_html($vector_store_id) . '</dd></div>';
            echo '</dl>';

            echo '<div class="wpsc-document-actions">';
            if ($status !== 'indexed') {
                echo '<form method="post" class="wpsc-inline-form">';
                wp_nonce_field('wpsc_retry_document_index');
                echo '<input type="hidden" name="wpsc_action" value="retry_document_index"><input type="hidden" name="document_id" value="' . esc_attr($document['id']) . '">';
                submit_button(__('Retry indexing', 'wp-smart-chatbot'), 'secondary small', 'submit', false);
                echo '</form>';
            }
            echo '<form method="post" class="wpsc-inline-form">';
            wp_nonce_field('wpsc_delete_document');
            echo '<input type="hidden" name="wpsc_action" value="delete_document"><input type="hidden" name="document_id" value="' . esc_attr($document['id']) . '">';
            echo '<button type="submit" class="button-link-delete" onclick="return confirm(\'Delete this document from the knowledgebase?\')">Delete</button>';
            echo '</form>';
            echo '</div></article>';
        }
        echo '</div></section>';
    }

    private function document_file_size($document) {
        $path = $document['file_local_path'] ?? '';
        if (!$path || !file_exists($path)) {
            return '';
        }

        return size_format((int) filesize($path));
    }

    private function document_status_class($status) {
        if ($status === 'indexed') {
            return 'success';
        }

        if ($status === 'failed') {
            return 'danger';
        }

        if ($status === 'processing') {
            return 'warning';
        }

        return 'progress';
    }

    private function document_status_label($status) {
        $labels = [
            'indexed' => __('Indexed', 'wp-smart-chatbot'),
            'processing' => __('Indexing', 'wp-smart-chatbot'),
            'failed' => __('Failed', 'wp-smart-chatbot'),
            'uploaded' => __('Saved locally', 'wp-smart-chatbot'),
        ];

        return $labels[$status] ?? ucwords(str_replace('_', ' ', $status));
    }

    public function forms_page() {
        $forms = $this->settings->custom_forms();
        $edit_id = sanitize_key($_GET['edit'] ?? '');
        $edit = null;
        foreach ($forms as $form) {
            if ($form['id'] === $edit_id) {
                $edit = $form;
                break;
            }
        }

        if (!$edit) {
            $edit = [
                'id' => '',
                'name' => '',
                'service_interest' => '',
                'submit_label' => __('Send details', 'wp-smart-chatbot'),
                'fields' => [
                    ['key' => 'name', 'label' => 'Name', 'type' => 'text', 'placeholder' => 'Name', 'required' => '1', 'options' => []],
                    ['key' => 'email', 'label' => 'Email', 'type' => 'email', 'placeholder' => 'Email', 'required' => '0', 'options' => []],
                    ['key' => 'phone', 'label' => 'Phone', 'type' => 'tel', 'placeholder' => 'Phone', 'required' => '0', 'options' => []],
                    ['key' => 'message', 'label' => 'Message', 'type' => 'textarea', 'placeholder' => 'How can the team help?', 'required' => '0', 'options' => []],
                ],
            ];
        }

        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Forms');
        $this->notice();
        echo '<p>Create reusable forms that can be sent from canned responses, Flow Builder options, and admin chat form requests. Use the field key dropdowns to map values into Leads consistently. See the Documentation page for field and action references.</p>';
        echo '<div class="wpsc-two-column">';
        echo '<form method="post" class="wpsc-card wpsc-custom-form-editor">';
        wp_nonce_field('wpsc_save_custom_form');
        echo '<input type="hidden" name="wpsc_action" value="save_custom_form"><input type="hidden" name="custom_form[id]" value="' . esc_attr($edit['id']) . '">';
        $this->input('custom_form[name]', 'Form name', $edit['name'] ?? '');
        $this->input('custom_form[service_interest]', 'Lead category / service label', $edit['service_interest'] ?? '');
        $this->input('custom_form[submit_label]', 'Submit button text', $edit['submit_label'] ?? 'Send details');
        echo '<h2>Fields</h2><div class="wpsc-custom-form-fields">';
        foreach (($edit['fields'] ?? []) as $index => $field) {
            $this->custom_form_field_card($index, $field);
        }
        echo '</div><p><button type="button" class="button wpsc-add-custom-form-field">Add field</button></p>';
        echo '<template id="wpsc-custom-form-field-template">';
        $this->custom_form_field_card('__INDEX__', ['key' => '', 'label' => '', 'type' => 'text', 'placeholder' => '', 'required' => '0', 'options' => []]);
        echo '</template>';
        submit_button($edit['id'] ? __('Update form', 'wp-smart-chatbot') : __('Create form', 'wp-smart-chatbot'));
        echo '</form>';

        echo '<section class="wpsc-card"><h2>Saved forms</h2>';
        if (!$forms) {
            echo '<p>No custom forms yet.</p>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Fields</th><th></th></tr></thead><tbody>';
            foreach ($forms as $form) {
                echo '<tr><td>' . esc_html($form['name']) . '</td><td>' . esc_html(count($form['fields'] ?? [])) . '</td><td>';
                echo '<a href="' . esc_url(admin_url('admin.php?page=wpsc-forms&edit=' . rawurlencode($form['id']))) . '">Edit</a> ';
                echo '<form method="post" class="wpsc-inline-form">';
                wp_nonce_field('wpsc_duplicate_custom_form');
                echo '<input type="hidden" name="wpsc_action" value="duplicate_custom_form"><input type="hidden" name="form_id" value="' . esc_attr($form['id']) . '"><button type="submit" class="button-link">Duplicate</button></form> ';
                echo '<form method="post" class="wpsc-inline-form">';
                wp_nonce_field('wpsc_delete_custom_form');
                echo '<input type="hidden" name="wpsc_action" value="delete_custom_form"><input type="hidden" name="form_id" value="' . esc_attr($form['id']) . '"><button type="submit" class="button-link-delete" onclick="return confirm(\'Delete this form?\')">Delete</button></form>';
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</section></div></div>';
    }

    public function knowledgebase_page() {
        $retrieval = get_transient('wpsc_retrieval_test_' . get_current_user_id());
        echo '<div class="wrap wpsc-admin wpsc-knowledgebase">';
        $this->admin_page_header('Knowledgebase', 'Add the source material the chatbot should retrieve from, then test the exact chunks before visitors see answers.');
        $this->notice();
        $this->refresh_processing_documents();
        $this->knowledge_source_cards();
        $this->retrieval_lab($retrieval);
        $this->knowledge_gap_inbox();
        $this->knowledge_documents_panel();
        echo '</div>';
    }

    public function chat_media_page() {
        $files = wpsc_chat_media_files();
        $retention_days = (int) $this->settings->get('media_retention_days', '30');
        $total_size = array_sum(array_map(function ($file) {
            return (int) ($file['size'] ?? 0);
        }, $files));

        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Chat Media');
        $this->notice();
        echo '<p>Visitor uploads are stored separately from the WordPress Media Library in <code>uploads/wpsc-chatbot-media</code>. Accepted public upload types are JPG, PNG, and PDF.</p>';
        echo '<p>Current retention: <strong>' . esc_html($retention_days ? $retention_days . ' days' : 'manual cleanup only') . '</strong>. Change this on the Settings page.</p>';
        echo '<div class="wpsc-metrics">';
        echo '<div class="wpsc-metric"><strong>' . esc_html(number_format_i18n(count($files))) . '</strong><span>Files</span></div>';
        echo '<div class="wpsc-metric"><strong>' . esc_html(size_format($total_size)) . '</strong><span>Storage Used</span></div>';
        echo '</div>';

        echo '<form method="post" class="wpsc-card">';
        wp_nonce_field('wpsc_clear_chat_media');
        echo '<input type="hidden" name="wpsc_action" value="clear_chat_media">';
        echo '<p><strong>Clear chatbot uploads</strong></p>';
        echo '<p>This removes files from the dedicated chatbot media folder only. It does not delete WordPress Media Library items or knowledgebase documents.</p>';
        submit_button(__('Clear chatbot media', 'wp-smart-chatbot'), 'delete', 'submit', false, ['onclick' => "return confirm('Delete all chatbot media uploads? Conversation links to these files may stop working.')"]);
        echo '</form>';

        if ($retention_days > 0) {
            echo '<form method="post" class="wpsc-card">';
            wp_nonce_field('wpsc_clear_old_chat_media');
            echo '<input type="hidden" name="wpsc_action" value="clear_old_chat_media">';
            echo '<p><strong>Clear old chatbot uploads</strong></p>';
            echo '<p>This removes only files older than the configured retention period.</p>';
            submit_button(sprintf(__('Clear files older than %d days', 'wp-smart-chatbot'), $retention_days), 'secondary', 'submit', false, ['onclick' => "return confirm('Delete old chatbot media uploads? Conversation links to these files may stop working.')"]);
            echo '</form>';
        }

        echo '<h2>Uploaded files</h2>';
        echo '<table class="widefat striped"><thead><tr><th>File</th><th>Size</th><th>Uploaded / Modified</th></tr></thead><tbody>';
        if (!$files) {
            echo '<tr><td colspan="3">No chatbot media files found.</td></tr>';
        }
        foreach ($files as $file) {
            echo '<tr>';
            echo '<td><a href="' . esc_url($file['url']) . '" target="_blank" rel="noopener">' . esc_html($file['relative']) . '</a></td>';
            echo '<td>' . esc_html(size_format((int) $file['size'])) . '</td>';
            echo '<td>' . esc_html(wpsc_format_datetime(gmdate('Y-m-d H:i:s', (int) $file['modified']))) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    public function documentation_page() {
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Q Digital Chatbot Documentation');
        echo '<section class="wpsc-card"><h2>Custom Form Fields</h2>';
        echo '<p>Use semantic field keys so submitted values can be grouped and displayed correctly in Leads and Conversations.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Field key</th><th>Recommended type</th><th>Purpose</th></tr></thead><tbody>';
        foreach ($this->custom_form_field_key_options() as $key => $item) {
            echo '<tr><td><code>' . esc_html($key) . '</code></td><td>' . esc_html($item['type']) . '</td><td>' . esc_html($item['description']) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p>Available field types: Text, Email, Phone, Long text, Dropdown, Date, and Number. Dropdown fields use one option per line.</p>';
        echo '</section>';

        echo '<section class="wpsc-card"><h2>Canned Response Actions</h2>';
        echo '<p>Canned responses and Flow Builder buttons can send a message, open a URL, request handover, start AI, or send any enabled form.</p>';
        echo '<ul>';
        foreach ($this->canned_action_options() as $action => $label) {
            echo '<li><code>' . esc_html($action) . '</code> - ' . esc_html($label) . '</li>';
        }
        echo '</ul></section>';

        echo '<section class="wpsc-card"><h2>Production Notes</h2>';
        echo '<ul>';
        echo '<li>Visitor uploads are stored outside the WordPress Media Library in <code>uploads/wpsc-chatbot-media</code>. Configure accepted file types and retention on Settings.</li>';
        echo '<li>Human handover uses admin polling and server-side timeout fallback. Keep WP-Cron working on production hosting.</li>';
        echo '<li>Mobile notifications can be connected through the Notifications webhook using tools such as Make, Zapier, Slack, Pushover, or SMS gateways.</li>';
        echo '<li>OpenAI API keys should preferably be defined with <code>WPSC_OPENAI_API_KEY</code> in <code>wp-config.php</code>.</li>';
        echo '</ul></section>';
        echo '</div>';
    }

    public function canned_page() {
        $edit_id = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
        $edit = $edit_id ? $this->repository->get_canned_response($edit_id) : null;
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Canned Responses');
        $this->notice();
        echo '<form method="post" class="wpsc-card">';
        wp_nonce_field('wpsc_ai_generate_canned');
        echo '<input type="hidden" name="wpsc_action" value="ai_generate_canned">';
        echo '<h2>AI response generator</h2>';
        echo '<p>Describe the business, services, tone, and buttons you want. The AI will create draft canned responses and add them to the list below.</p>';
        echo '<p><label>Prompt<br><textarea name="ai_prompt" rows="5" class="large-text" placeholder="Example: Create five friendly canned replies for a local mould removal business. Include quote, service area, emergency help, pricing question and speak to someone." required></textarea></label></p>';
        echo '<p><label>Number of responses<br><input type="number" name="ai_count" min="1" max="10" value="5" class="small-text"></label></p>';
        submit_button(__('Generate canned responses', 'wp-smart-chatbot'), 'secondary');
        echo '</form>';
        echo '<form method="post" class="wpsc-card">';
        wp_nonce_field('wpsc_save_canned');
        echo '<input type="hidden" name="wpsc_action" value="save_canned"><input type="hidden" name="id" value="' . esc_attr($edit_id) . '">';
        $payload = wpsc_json_decode($edit['action_payload'] ?? '{}');
        $this->input('canned[title]', 'Title', $edit['title'] ?? '');
        $this->input('canned[trigger_label]', 'Button label / trigger', $edit['trigger_label'] ?? '');
        $this->textarea('canned[response_text]', 'Response text', $edit['response_text'] ?? '');
        $this->textarea('canned[messages_text]', 'Extra bot messages, one per line', implode("\n", $payload['messages'] ?? []));
        echo '<p class="description">Use extra messages when one canned response should send several chat bubbles.</p>';
        echo '<p><label>Choice Display<br><select name="canned[choice_display]">';
        foreach (['bubbles' => 'Scrollable bubbles', 'cards' => 'Image/card options'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($payload['choice_display'] ?? 'bubbles', $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        $this->media_image_input('canned[card_image_url]', 'Fallback Card Image', $payload['card_image_url'] ?? '');
        $this->canned_card_design_controls($payload);
        $this->canned_slideshow_controls($payload['content_element'] ?? []);
        $this->canned_option_editor($payload['options'] ?? [], $edit['id'] ?? 0);
        $this->canned_fast_reply_picker($edit['id'] ?? 0, $payload['fast_reply_ids'] ?? []);
        echo '<p><label>Action<br><select name="canned[action_type]">';
        foreach ($this->canned_action_options() as $action => $label) {
            echo '<option value="' . esc_attr($action) . '"' . selected($edit['action_type'] ?? 'send_message', $action, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        $this->input('canned[sort_order]', 'Sort order', $edit['sort_order'] ?? '0', 'number');
        echo '<p><label><input type="checkbox" name="canned[is_active]" value="1" ' . checked($edit['is_active'] ?? '1', '1', false) . '> Active</label></p>';
        submit_button($edit ? __('Update response', 'wp-smart-chatbot') : __('Add response', 'wp-smart-chatbot'));
        echo '</form><h2>Responses</h2><table class="widefat striped"><thead><tr><th>Title</th><th>Trigger</th><th>Action</th><th>Active</th><th></th></tr></thead><tbody>';
        foreach ($this->repository->list_canned_responses() as $item) {
            $edit_url = admin_url('admin.php?page=wpsc-canned-responses&edit=' . (int) $item['id']);
            echo '<tr><td>' . esc_html($item['title']) . '</td><td>' . esc_html($item['trigger_label']) . '</td><td>' . esc_html($item['action_type']) . '</td><td>' . esc_html($item['is_active'] ? 'Yes' : 'No') . '</td><td><a href="' . esc_url($edit_url) . '">Edit</a> ';
            echo '<form method="post" class="wpsc-inline-form">';
            wp_nonce_field('wpsc_delete_canned');
            echo '<input type="hidden" name="wpsc_action" value="delete_canned"><input type="hidden" name="id" value="' . esc_attr($item['id']) . '"><button class="button-link-delete" type="submit">Delete</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function flow_builder_page() {
        $responses = $this->repository->list_canned_responses(false);
        $selected_id = isset($_GET['flow_id']) ? (int) $_GET['flow_id'] : 0;
        if (!$selected_id && $responses) {
            $selected_id = (int) $responses[0]['id'];
        }
        $visible_ids = $this->flow_visible_ids($selected_id, $responses);
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Flow Builder');
        $this->notice();
        echo '<p>Choose one flow to edit, then drag message cards to organise that journey. The regular Canned Responses page still works for non-drag editing.</p>';
        echo '<form method="get" class="wpsc-toolbar"><input type="hidden" name="page" value="wpsc-flow-builder"><label>Flow <select name="flow_id">';
        foreach ($responses as $response) {
            echo '<option value="' . esc_attr($response['id']) . '"' . selected($selected_id, (int) $response['id'], false) . '>' . esc_html($response['title']) . '</option>';
        }
        echo '</select></label> ';
        submit_button(__('Edit selected flow', 'wp-smart-chatbot'), 'secondary', 'submit', false);
        echo '</form>';
        echo '<form method="post" id="wpsc-flow-form">';
        wp_nonce_field('wpsc_save_flow_builder');
        echo '<input type="hidden" name="wpsc_action" value="save_flow_builder">';
        submit_button(__('Save flow', 'wp-smart-chatbot'), 'primary', 'submit', false);
        echo '<div class="wpsc-flow-canvas" id="wpsc-flow-canvas"><svg class="wpsc-flow-lines" id="wpsc-flow-lines"></svg>';
        foreach ($responses as $index => $response) {
            if (!in_array((int) $response['id'], $visible_ids, true)) {
                continue;
            }
            $payload = wpsc_json_decode($response['action_payload'] ?? '{}');
            $position = $payload['position'] ?? ['x' => 40 + ($index % 3) * 310, 'y' => 40 + floor($index / 3) * 280];
            $options = $payload['options'] ?? [];
            echo '<section class="wpsc-flow-node" data-id="' . esc_attr($response['id']) . '" style="left:' . esc_attr((int) $position['x']) . 'px;top:' . esc_attr((int) $position['y']) . 'px">';
            echo '<input type="hidden" class="wpsc-node-x" name="flow[' . esc_attr($response['id']) . '][x]" value="' . esc_attr((int) $position['x']) . '">';
            echo '<input type="hidden" class="wpsc-node-y" name="flow[' . esc_attr($response['id']) . '][y]" value="' . esc_attr((int) $position['y']) . '">';
            echo '<h2>' . esc_html($response['title']) . '</h2><p><strong>' . esc_html($response['trigger_label']) . '</strong></p><p>' . esc_html(wp_trim_words($response['response_text'], 22)) . '</p>';
            echo '<div class="wpsc-flow-options">';
            foreach ($options as $option_index => $option) {
                $this->flow_option_row($responses, $response['id'], $option_index, $option);
            }
            if (!$options) {
                $this->flow_option_row($responses, $response['id'], 0, ['label' => '', 'action_type' => 'send_message', 'response_text' => '', 'target_id' => 0]);
            }
            echo '</div><a href="' . esc_url(admin_url('admin.php?page=wpsc-canned-responses&edit=' . (int) $response['id'])) . '">Edit message</a></section>';
        }
        echo '</div></form></div>';
    }

    private function flow_visible_ids($start_id, $responses) {
        $map = [];
        foreach ($responses as $response) {
            $map[(int) $response['id']] = $response;
        }

        if (!$start_id || empty($map[$start_id])) {
            return array_slice(array_keys($map), 0, 1);
        }

        $visible = [];
        $queue = [$start_id];
        while ($queue) {
            $id = array_shift($queue);
            if (in_array($id, $visible, true) || empty($map[$id])) {
                continue;
            }

            $visible[] = $id;
            $payload = wpsc_json_decode($map[$id]['action_payload'] ?? '{}');
            foreach (($payload['options'] ?? []) as $option) {
                $target = (int) ($option['target_id'] ?? 0);
                if ($target && !in_array($target, $visible, true)) {
                    $queue[] = $target;
                }
            }
            foreach (($payload['fast_reply_ids'] ?? []) as $target) {
                $target = (int) $target;
                if ($target && !in_array($target, $visible, true)) {
                    $queue[] = $target;
                }
            }
        }

        return $visible;
    }

    public function branding_page() {
        $this->settings_form('Branding', ['bot_name', 'agent_name_mode', 'agent_display_name', 'header_logo_url', 'chat_header_style', 'chat_header_logo_shape', 'chat_header_logo_size', 'chat_header_logo_fit', 'chat_header_show_name', 'chat_header_show_status', 'launcher_icon_style', 'launcher_color', 'welcome_nudge_enabled', 'welcome_nudge_delay', 'welcome_nudge_text', 'welcome_screen_enabled', 'welcome_screen_title', 'welcome_screen_subtitle', 'welcome_screen_card_title', 'welcome_screen_message', 'welcome_screen_button_text', 'feedback_enabled', 'feedback_confirm_close_enabled', 'feedback_confirm_title', 'feedback_confirm_button_label', 'feedback_closed_note', 'feedback_first_question', 'feedback_resolved_question', 'feedback_rating_question', 'feedback_comment_label', 'feedback_yes_label', 'feedback_no_label', 'feedback_positive_label', 'feedback_negative_label', 'feedback_submit_label', 'feedback_skip_label', 'feedback_saving_message', 'feedback_success_message', 'feedback_error_message', 'primary_color', 'secondary_color', 'text_color', 'background_color', 'position', 'card_defaults', 'carousel_button_bg_color', 'carousel_button_text_color', 'carousel_button_radius']);
    }

    public function ai_page() {
        $settings = $this->settings->all();
        $settings['openai_api_key'] = $this->settings->masked_openai_key();
        $this->settings_form('AI Settings', ['ai_enabled', 'openai_api_key', 'openai_model', 'openai_temperature', 'openai_max_tokens', 'openai_vector_store_id', 'custom_instructions', 'knowledgebase_strict'], $settings);
    }

    public function notifications_page() {
        $this->settings_form('Notifications', ['lead_email', 'support_email', 'notification_webhook_enabled', 'notification_webhook_url']);
    }

    public function settings_page() {
        $this->settings_form('Settings', ['enabled', 'business_name', 'business_phone', 'business_email', 'business_address', 'greeting', 'offline_greeting', 'business_hours_enabled', 'offline_auto_form_enabled', 'business_timezone', 'business_days', 'business_open_time', 'business_close_time', 'date_format', 'fallback_message', 'handover_connecting_message', 'handover_requested_message', 'handover_unavailable_message', 'auto_open_delay', 'typing_delay', 'handover_timeout', 'quick_replies_enabled', 'media_uploads_enabled', 'media_upload_images_enabled', 'media_upload_pdfs_enabled', 'media_retention_days', 'featured_canned_response_ids', 'canned_enabled', 'admin_quick_actions', 'delete_data_on_uninstall']);
    }

    public function import_export_page() {
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header('Import / Export');
        $this->notice();
        echo '<div class="wpsc-two-column">';
        echo '<form method="post" class="wpsc-card">';
        wp_nonce_field('wpsc_export_settings');
        echo '<input type="hidden" name="wpsc_action" value="export_settings">';
        echo '<h2>Export</h2>';
        echo '<p>Download chatbot settings and canned responses as a JSON file for reuse on another site. API keys are not exported.</p>';
        echo '<p><label><input type="checkbox" name="include_canned" value="1" checked> Include canned responses</label></p>';
        submit_button(__('Download export file', 'wp-smart-chatbot'));
        echo '</form>';
        echo '<form method="post" enctype="multipart/form-data" class="wpsc-card">';
        wp_nonce_field('wpsc_import_settings');
        echo '<input type="hidden" name="wpsc_action" value="import_settings">';
        echo '<h2>Import</h2>';
        echo '<p>Upload a JSON export file. Settings will be merged with existing defaults. Canned responses can be appended or replaced.</p>';
        echo '<p><input type="file" name="import_file" accept=".json,application/json" required></p>';
        echo '<p><label><input type="checkbox" name="import_canned" value="1" checked> Import canned responses</label></p>';
        echo '<p><label><input type="checkbox" name="replace_canned" value="1"> Replace existing canned responses before import</label></p>';
        submit_button(__('Import file', 'wp-smart-chatbot'));
        echo '</form>';
        echo '</div></div>';
    }

    private function settings_form($title, $fields, $settings = null) {
        $settings = $settings ?: $this->settings->all();
        echo '<div class="wrap wpsc-admin">';
        $this->admin_page_header($title);
        $this->notice();
        echo '<form method="post" class="wpsc-card">';
        wp_nonce_field('wpsc_save_settings');
        echo '<input type="hidden" name="wpsc_action" value="save_settings">';
        foreach ($fields as $field) {
            if (in_array($field, ['enabled', 'ai_enabled', 'knowledgebase_strict', 'quick_replies_enabled', 'media_uploads_enabled', 'media_upload_images_enabled', 'media_upload_pdfs_enabled', 'canned_enabled', 'business_hours_enabled', 'offline_auto_form_enabled', 'notification_webhook_enabled', 'welcome_nudge_enabled', 'welcome_screen_enabled', 'feedback_enabled', 'feedback_confirm_close_enabled', 'chat_header_show_name', 'chat_header_show_status', 'delete_data_on_uninstall'], true)) {
                echo '<p><label><input type="hidden" name="wpsc[' . esc_attr($field) . ']" value="0"><input type="checkbox" name="wpsc[' . esc_attr($field) . ']" value="1" ' . checked($settings[$field] ?? '0', '1', false) . '> ' . esc_html(ucwords(str_replace('_', ' ', $field))) . '</label></p>';
                if ($field === 'offline_auto_form_enabled') {
                    echo '<p class="description">When the chatbot is opened outside trading hours, show the lead form immediately after the offline greeting.</p>';
                } elseif ($field === 'notification_webhook_enabled') {
                    echo '<p class="description">Sends lead and handover events to the webhook URL below for mobile push/SMS workflows through services such as Make, Zapier, Slack, or Pushover.</p>';
                } elseif ($field === 'media_uploads_enabled') {
                    echo '<p class="description">Master switch for visitor file uploads. Use the image/PDF toggles below to choose allowed file types.</p>';
                } elseif ($field === 'media_upload_pdfs_enabled') {
                    echo '<p class="description">If image uploads and PDF uploads are both disabled, the upload option is hidden and uploads are rejected.</p>';
                } elseif ($field === 'chat_header_show_status') {
                    echo '<p class="description">The status line uses the business hours and timezone from Settings, for example online until the configured close time.</p>';
                } elseif ($field === 'delete_data_on_uninstall') {
                    echo '<p class="description">When enabled, uninstalling the plugin removes chatbot tables, settings, leads, conversations, documents, events, and the dedicated chatbot media folder. Leave disabled for production unless you are intentionally removing all chatbot data.</p>';
                }
            } elseif ($field === 'chat_header_style') {
                echo '<p><label>Chat Header Style<br><select name="wpsc[chat_header_style]">';
                foreach (['brand_bar' => 'Full brand bar', 'floating_pill' => 'Floating logo pill', 'compact_center' => 'Compact centred logo'] as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . selected($settings[$field] ?? wpsc_default_settings()['chat_header_style'], $value, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">Choose how the top controls, logo, name, and status are arranged in the chat window.</p>';
            } elseif ($field === 'agent_name_mode') {
                echo '<p><label>Agent Name Display<br><select name="wpsc[agent_name_mode]">';
                foreach (['team' => 'Use team/display name', 'user' => 'Use replying WordPress user name', 'hidden' => 'Hide agent names'] as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . selected($settings[$field] ?? 'team', $value, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">Admins can still override the display name for a specific reply from the conversation screen.</p>';
            } elseif ($field === 'chat_header_logo_shape') {
                echo '<p><label>Chat Header Logo Shape<br><select name="wpsc[chat_header_logo_shape]">';
                foreach (['rounded_square' => 'Rounded square', 'circle' => 'Circle', 'square' => 'Square', 'rectangle' => 'Rectangle'] as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . selected($settings[$field] ?? 'rounded_square', $value, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">Rectangle uses a full-cover logo treatment in the pill. Turn off Chat Header Show Name for a logo-only pill.</p>';
            } elseif ($field === 'chat_header_logo_fit') {
                echo '<p><label>Logo Image Fit<br><select name="wpsc[chat_header_logo_fit]">';
                foreach (['contain' => 'Fit inside logo area', 'cover' => 'Fill/crop logo area'] as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . selected($settings[$field] ?? 'contain', $value, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">Use Fill/crop for favicon-style artwork. Use Fit inside for full wordmarks that should not be cropped.</p>';
            } elseif ($field === 'launcher_icon_style') {
                echo '<p><label>Launcher Icon Style<br><select name="wpsc[launcher_icon_style]">';
                foreach (['message' => 'Message bubble', 'dots' => 'Chat dots', 'logo' => 'Header logo'] as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"' . selected($settings[$field] ?? 'message', $value, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">The launcher still shows animated typing dots on hover.</p>';
            } elseif ($field === 'admin_quick_actions') {
                echo '<fieldset class="wpsc-fieldset"><legend>Admin Chat Quick Actions</legend>';
                echo '<p class="description">Choose which business modules are enabled. Enabled modules show as admin chat form buttons and Leads tabs.</p>';
                foreach ($this->admin_form_request_types() as $type => $form) {
                    if (strpos($type, 'custom_') === 0) {
                        continue;
                    }
                    $setting_key = 'admin_quick_' . $type . '_enabled';
                    echo '<label><input type="hidden" name="wpsc[' . esc_attr($setting_key) . ']" value="0"><input type="checkbox" name="wpsc[' . esc_attr($setting_key) . ']" value="1" ' . checked($settings[$setting_key] ?? '1', '1', false) . '> ' . esc_html($form['button']) . '</label> ';
                }
                echo '</fieldset>';
            } elseif ($field === 'business_timezone') {
                echo '<p><label>Business Timezone<br><select name="wpsc[business_timezone]">';
                foreach (timezone_identifiers_list() as $timezone) {
                    echo '<option value="' . esc_attr($timezone) . '"' . selected($settings[$field] ?? '', $timezone, false) . '>' . esc_html($timezone) . '</option>';
                }
                echo '</select></label></p>';
            } elseif ($field === 'business_days') {
                $selected_days = array_map('intval', explode(',', (string) ($settings[$field] ?? '')));
                $labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                echo '<fieldset class="wpsc-fieldset"><legend>Days People Are Online</legend>';
                echo '<input type="hidden" name="wpsc[business_days]" value="">';
                foreach ($labels as $index => $label) {
                    echo '<label><input type="checkbox" name="wpsc[business_days][]" value="' . esc_attr($index) . '" ' . checked(in_array($index, $selected_days, true), true, false) . '> ' . esc_html($label) . '</label> ';
                }
                echo '</fieldset>';
            } elseif ($field === 'date_format') {
                echo '<p><label>Date Display Format<br><select name="wpsc[date_format]">';
                foreach (wpsc_datetime_format_options() as $format => $example) {
                    echo '<option value="' . esc_attr($format) . '"' . selected($settings[$field] ?? wpsc_datetime_format(), $format, false) . '>' . esc_html($example) . '</option>';
                }
                echo '</select></label></p>';
                echo '<p class="description">Controls how plugin dates display in Leads, Conversations, exports, and real-time admin updates.</p>';
            } elseif ($field === 'featured_canned_response_ids') {
                $selected_ids = array_filter(array_map('absint', explode(',', (string) ($settings[$field] ?? ''))));
                echo '<fieldset class="wpsc-fieldset"><legend>Featured Start Buttons</legend>';
                echo '<p class="description">Choose 2-3 main paths to show at the start/restart of the chat. Other canned responses are still available through flows and the menu.</p>';
                echo '<input type="hidden" name="wpsc[featured_canned_response_ids]" value="">';
                foreach ($this->repository->list_canned_responses(true) as $response) {
                    echo '<label><input type="checkbox" name="wpsc[featured_canned_response_ids][]" value="' . esc_attr($response['id']) . '" ' . checked(in_array((int) $response['id'], $selected_ids, true), true, false) . '> ' . esc_html($response['trigger_label']) . '</label> ';
                }
                echo '</fieldset>';
            } elseif ($field === 'card_defaults') {
                $this->card_default_settings_controls($settings);
            } elseif ($field === 'header_logo_url') {
                $this->media_image_input('wpsc[header_logo_url]', 'Header Logo', $settings[$field] ?? '');
            } elseif (in_array($field, ['business_open_time', 'business_close_time'], true)) {
                $this->input('wpsc[' . $field . ']', ucwords(str_replace('_', ' ', $field)), $settings[$field] ?? '', 'time');
            } elseif ($field === 'chat_header_logo_size') {
                $this->input('wpsc[chat_header_logo_size]', 'Chat Header Logo Size', $settings[$field] ?? '38', 'number');
                echo '<p class="description">Logo size in pixels. Recommended: 32-44 for circles/squares, 44-64 for rectangle/logo-only layouts.</p>';
            } elseif ($field === 'media_retention_days') {
                $this->input('wpsc[media_retention_days]', 'Chat Media Retention Days', $settings[$field] ?? '30', 'number');
                echo '<p class="description">Set to 0 to keep chatbot uploads until manually cleared. Otherwise, files older than this are removed by the daily cleanup job.</p>';
            } elseif ($field === 'typing_delay') {
                $this->input('wpsc[typing_delay]', 'Response Typing Wave Duration (ms)', $settings[$field] ?? '650', 'number');
                echo '<p class="description">How long the animated typing dots (the "…" wave) show before a bot or quick-reply response appears, in milliseconds. Raise it (e.g. 900-1500) so replies feel more human and less instant. Range 0-10000.</p>';
            } elseif ($field === 'business_address') {
                $this->textarea('wpsc[' . $field . ']', 'Business Address', $settings[$field] ?? '');
            } elseif ($field === 'custom_instructions') {
                $this->textarea('wpsc[' . $field . ']', 'Custom Instructions', $settings[$field] ?? '');
                echo '<p class="description">The plugin also applies built-in visitor-facing rules: brief complete replies, no uploaded document names, no file citations, and human handover when uncertain.</p>';
            } elseif (in_array($field, ['greeting', 'offline_greeting', 'fallback_message', 'handover_connecting_message', 'handover_requested_message', 'handover_unavailable_message', 'welcome_nudge_text', 'welcome_screen_message', 'feedback_confirm_title', 'feedback_closed_note', 'feedback_first_question', 'feedback_resolved_question', 'feedback_rating_question', 'feedback_comment_label', 'feedback_saving_message', 'feedback_success_message', 'feedback_error_message'], true)) {
                $this->textarea('wpsc[' . $field . ']', ucwords(str_replace('_', ' ', $field)), $settings[$field] ?? '');
            } elseif (strpos($field, 'color') !== false) {
                $this->input('wpsc[' . $field . ']', ucwords(str_replace('_', ' ', $field)), $settings[$field] ?? '', 'color');
            } else {
                $type = in_array($field, ['auto_open_delay', 'typing_delay', 'handover_timeout', 'openai_max_tokens', 'carousel_button_radius', 'welcome_nudge_delay', 'media_retention_days', 'chat_header_logo_size'], true) ? 'number' : 'text';
                $this->input('wpsc[' . $field . ']', ucwords(str_replace('_', ' ', $field)), $settings[$field] ?? '', $type);
            }
        }
        submit_button(__('Save settings', 'wp-smart-chatbot'));
        echo '</form></div>';
    }

    private function card_default_settings_controls($settings) {
        $style = in_array(($settings['card_default_style'] ?? 'split'), ['split', 'cover'], true) ? $settings['card_default_style'] : 'split';
        $position = in_array(($settings['card_default_text_position'] ?? 'bottom'), ['bottom', 'center'], true) ? $settings['card_default_text_position'] : 'bottom';
        $shape = in_array(($settings['card_default_image_shape'] ?? 'square'), ['landscape', 'square', 'portrait'], true) ? $settings['card_default_image_shape'] : 'square';
        $opacity = min(100, max(0, (int) ($settings['card_default_overlay_opacity'] ?? 88)));
        $text_color = sanitize_hex_color($settings['card_default_text_color'] ?? '') ?: '#ffffff';
        $background_color = sanitize_hex_color($settings['card_default_background_color'] ?? '') ?: '#111827';

        echo '<fieldset class="wpsc-fieldset wpsc-card-design"><legend>Default Card Design</legend>';
        echo '<p class="description">These defaults apply to image/card options unless an individual canned response overrides them.</p>';
        echo '<div class="wpsc-card-design-grid">';
        echo '<p><label>Card style<br><select name="wpsc[card_default_style]">';
        foreach (['split' => 'Image top, text below', 'cover' => 'Full-cover image with text overlay'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($style, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Image shape<br><select name="wpsc[card_default_image_shape]">';
        foreach (['landscape' => 'Landscape', 'square' => 'Square', 'portrait' => 'Portrait'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($shape, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Text colour<br><input type="color" name="wpsc[card_default_text_color]" value="' . esc_attr($text_color) . '"></label></p>';
        echo '<p><label>Text background colour<br><input type="color" name="wpsc[card_default_background_color]" value="' . esc_attr($background_color) . '"></label></p>';
        echo '<p><label>Text background opacity<br><input type="range" min="0" max="100" name="wpsc[card_default_overlay_opacity]" value="' . esc_attr($opacity) . '" class="wpsc-range-with-output"> <span class="wpsc-range-output">' . esc_html($opacity) . '%</span></label></p>';
        echo '<p><label>Text position<br><select name="wpsc[card_default_text_position]">';
        foreach (['bottom' => 'Bottom', 'center' => 'Centre'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($position, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '</div></fieldset>';
    }

    private function conversation_table($conversations, $link = false) {
        $conversation_ids = array_map(function ($conversation) {
            return (int) ($conversation['id'] ?? 0);
        }, (array) $conversations);
        $feedback_by_conversation = $this->repository->latest_feedback_by_conversation_ids($conversation_ids);

        echo '<table class="widefat striped wpsc-conversations-table"><thead><tr><th>ID</th><th>Status</th><th>Lead</th><th>Experience</th><th>Page</th><th>Last Message</th></tr></thead><tbody>';
        if (!$conversations) {
            echo '<tr><td colspan="6">No conversations found for this filter.</td></tr>';
            echo '</tbody></table>';
            return;
        }
        foreach ($conversations as $conversation) {
            $id = (int) $conversation['id'];
            $conversation_url = $link ? admin_url('admin.php?page=wpsc-conversations&conversation_id=' . $id) : '';
            $label = $link ? '<a href="' . esc_url($conversation_url) . '">#' . esc_html($id) . '</a>' : '#' . esc_html($id);
            $lead = !empty($conversation['lead_id']) ? $this->repository->get_lead((int) $conversation['lead_id']) : null;
            $selected = isset($_GET['conversation_id']) && (int) $_GET['conversation_id'] === $id;
            $row_class = $link ? 'wpsc-clickable-conversation' . ($selected ? ' is-selected' : '') : '';
            $row_attributes = $link
                ? ' class="' . esc_attr($row_class) . '" data-conversation-url="' . esc_url($conversation_url) . '" tabindex="0" role="link" aria-label="' . esc_attr(sprintf(__('Open conversation %d', 'wp-smart-chatbot'), $id)) . '"'
                : '';
            echo '<tr data-conversation-id="' . esc_attr($id) . '"' . $row_attributes . '>';
            echo '<td>' . $label . '</td>';
            echo '<td class="wpsc-row-status">' . esc_html($conversation['status']) . '</td>';
            echo '<td>' . $this->lead_snapshot_html($lead) . '</td>';
            echo '<td>' . $this->feedback_rating_html($feedback_by_conversation[$id] ?? null) . '</td>';
            echo '<td>' . esc_html($conversation['current_url']) . '</td>';
            echo '<td class="wpsc-row-last-message">' . esc_html(wpsc_format_datetime($conversation['last_message_at'])) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private function lead_snapshot_table($leads) {
        $conversation_ids = array_map(function ($lead) {
            return (int) ($lead['conversation_id'] ?? 0);
        }, (array) $leads);
        $feedback_by_conversation = $this->repository->latest_feedback_by_conversation_ids($conversation_ids);

        echo '<table class="widefat striped wpsc-lead-snapshot-table"><thead><tr><th>Lead</th><th>Contact</th><th>Interest</th><th>Experience</th><th>Created</th><th>Conversation</th></tr></thead><tbody>';
        if (!$leads) {
            echo '<tr><td colspan="6">No new leads found for this date range.</td></tr>';
            echo '</tbody></table>';
            return;
        }

        foreach ($leads as $lead) {
            $conversation_id = (int) ($lead['conversation_id'] ?? 0);
            $details = $this->lead_details_for_display($lead);
            $conversation_link = $conversation_id
                ? '<a href="' . esc_url(admin_url('admin.php?page=wpsc-conversations&conversation_id=' . $conversation_id)) . '">#' . esc_html($conversation_id) . '</a>'
                : '';
            echo '<tr>';
            echo '<td>' . $this->lead_snapshot_html($lead) . '</td>';
            echo '<td>' . esc_html(trim(($lead['email'] ?? '') . ' ' . ($lead['phone'] ?? ''))) . '</td>';
            echo '<td>' . esc_html($details['primary'] ?: $lead['service_interest']) . '</td>';
            echo '<td>' . $this->feedback_rating_html($feedback_by_conversation[$conversation_id] ?? null) . '</td>';
            echo '<td>' . esc_html(wpsc_format_datetime($lead['created_at'])) . '</td>';
            echo '<td>' . $conversation_link . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private function lead_snapshot_html($lead) {
        if (!$lead) {
            return '';
        }

        $name = trim((string) ($lead['name'] ?? ''));
        $company = trim((string) ($lead['company'] ?? ''));
        $email = trim((string) ($lead['email'] ?? ''));
        $phone = trim((string) ($lead['phone'] ?? ''));
        $html = '<div class="wpsc-lead-snapshot">';
        $html .= '<strong>' . esc_html($name ?: __('Unnamed lead', 'wp-smart-chatbot')) . '</strong>';
        if ($company) {
            $html .= '<span>' . esc_html($company) . '</span>';
        }
        if ($email || $phone) {
            $html .= '<small>' . esc_html(trim($email . ' ' . $phone)) . '</small>';
        }
        $html .= '</div>';
        return $html;
    }

    private function feedback_rating_html($event) {
        if (!$event) {
            return '';
        }
        $data = wpsc_json_decode($event['event_data'] ?? '{}');
        $rating = $data['rating'] ?? '';
        if ($rating !== 'positive' && $rating !== 'negative') {
            return '';
        }
        $label = $rating === 'positive' ? __('Positive', 'wp-smart-chatbot') : __('Negative', 'wp-smart-chatbot');
        $icon = $rating === 'positive' ? '&#128077;' : '&#128078;';
        $class = $rating === 'positive' ? 'wpsc-rating-positive' : 'wpsc-rating-negative';
        $resolved = isset($data['resolved']) ? ucfirst((string) $data['resolved']) : '';
        return '<span class="wpsc-rating-pill ' . esc_attr($class) . '"><span aria-hidden="true">' . $icon . '</span> ' . esc_html($label) . '</span>' . ($resolved ? '<small class="wpsc-rating-resolution">Resolved: ' . esc_html($resolved) . '</small>' : '');
    }

    private function sanitize_date_param($value) {
        $value = sanitize_text_field((string) $value);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : '';
    }

    private function feedback_table($events) {
        echo '<table class="widefat striped wpsc-feedback-table"><thead><tr><th>Conversation</th><th>Rating</th><th>Resolved</th><th>First Time</th><th>Comment</th><th>Submitted</th></tr></thead><tbody>';
        if (!$events) {
            echo '<tr><td colspan="6">No feedback submitted yet.</td></tr>';
            echo '</tbody></table>';
            return;
        }

        foreach ($events as $event) {
            $data = wpsc_json_decode($event['event_data'] ?? '{}');
            $conversation_id = (int) ($event['conversation_id'] ?? 0);
            $conversation_link = $conversation_id
                ? '<a href="' . esc_url(admin_url('admin.php?page=wpsc-conversations&conversation_id=' . $conversation_id)) . '">#' . esc_html($conversation_id) . '</a>'
                : '&mdash;';
            $rating = ($data['rating'] ?? '') === 'positive' ? 'Positive' : (($data['rating'] ?? '') === 'negative' ? 'Negative' : '');
            $rating_class = ($data['rating'] ?? '') === 'positive' ? 'wpsc-rating-positive' : 'wpsc-rating-negative';
            echo '<tr>';
            echo '<td>' . $conversation_link . '</td>';
            echo '<td><span class="wpsc-rating-pill ' . esc_attr($rating_class) . '">' . esc_html($rating ?: '-') . '</span></td>';
            echo '<td>' . esc_html(ucfirst((string) ($data['resolved'] ?? '-'))) . '</td>';
            echo '<td>' . esc_html(ucfirst((string) ($data['first_time'] ?? '-'))) . '</td>';
            echo '<td>' . esc_html($data['comment'] ?? '') . '</td>';
            echo '<td>' . esc_html(wpsc_format_datetime($event['created_at'])) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private function bug_reports_table($events) {
        echo '<table class="widefat striped wpsc-bug-reports-table"><thead><tr><th>Conversation</th><th>Reason</th><th>Comment</th><th>Page</th><th>Submitted</th></tr></thead><tbody>';
        if (!$events) {
            echo '<tr><td colspan="5">No bug reports submitted yet.</td></tr>';
            echo '</tbody></table>';
            return;
        }

        foreach ($events as $event) {
            $data = wpsc_json_decode($event['event_data'] ?? '{}');
            $conversation_id = (int) ($event['conversation_id'] ?? 0);
            $conversation_link = $conversation_id
                ? '<a href="' . esc_url(admin_url('admin.php?page=wpsc-conversations&conversation_id=' . $conversation_id)) . '">#' . esc_html($conversation_id) . '</a>'
                : '&mdash;';
            $page_url = $event['current_url'] ?: ($data['current_url'] ?? '');
            $page = $page_url
                ? '<a href="' . esc_url($page_url) . '" target="_blank" rel="noopener">' . esc_html($page_url) . '</a>'
                : '&mdash;';

            echo '<tr>';
            echo '<td>' . $conversation_link . '</td>';
            echo '<td>' . esc_html($data['reason'] ?? '-') . '</td>';
            echo '<td>' . esc_html($data['comment'] ?? '') . '</td>';
            echo '<td class="wpsc-bug-page">' . $page . '</td>';
            echo '<td>' . esc_html(wpsc_format_datetime($event['created_at'])) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private function conversation_message_html($message) {
        $id = isset($message['id']) ? (int) $message['id'] : 0;
        $metadata = wpsc_json_decode($message['metadata'] ?? '{}');
        $sender_label = $message['sender_type'];
        if (($message['sender_type'] ?? '') === 'agent' && !empty($metadata['agent_name'])) {
            $sender_label = 'agent: ' . $metadata['agent_name'];
        }
        $notice = '';
        if (($metadata['action_type'] ?? '') === 'ask_contact') {
            $label = !empty($metadata['form_label']) ? $metadata['form_label'] : __('Lead capture form', 'wp-smart-chatbot');
            $notice = '<div class="wpsc-message-marker">' . esc_html($label) . ' shown to visitor</div>';
        }
        $attachment = $this->conversation_attachment_html($message, $metadata);
        $body = $attachment ?: '<p>' . wp_kses_post($message['body']) . '</p>';
        return '<div class="wpsc-message wpsc-' . esc_attr($message['sender_type']) . '" data-message-id="' . esc_attr($id) . '"><strong>' . esc_html($sender_label) . '</strong>' . $body . $notice . '<small>' . esc_html(wpsc_format_datetime($message['created_at'])) . '</small></div>';
    }

    private function conversation_attachment_html($message, $metadata) {
        $url = '';
        if (!empty($metadata['file_url'])) {
            $url = esc_url_raw($metadata['file_url']);
        } elseif (!empty($metadata['image_url'])) {
            $url = esc_url_raw($metadata['image_url']);
        } elseif (!empty($message['body']) && preg_match('/href=[\'"]([^\'"]+)[\'"]/i', (string) $message['body'], $matches)) {
            $url = esc_url_raw($matches[1]);
        }

        if (!$url) {
            return '';
        }

        $file_name = !empty($metadata['file_name']) ? sanitize_file_name($metadata['file_name']) : basename((string) wp_parse_url($url, PHP_URL_PATH));
        $type = sanitize_key($metadata['attachment_type'] ?? $message['message_type'] ?? '');
        $extension = strtolower(pathinfo($file_name ?: (string) wp_parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
        $is_image = $type === 'image' || in_array($extension, ['jpg', 'jpeg', 'png'], true);

        if ($is_image) {
            return '<div class="wpsc-message-attachment wpsc-message-attachment-image"><a href="' . esc_url($url) . '" target="_blank" rel="noopener"><img src="' . esc_url($url) . '" alt="' . esc_attr($file_name ?: __('Image attachment', 'wp-smart-chatbot')) . '"></a></div>';
        }

        return '<div class="wpsc-message-attachment wpsc-message-attachment-file"><a href="' . esc_url($url) . '" target="_blank" rel="noopener"><span class="wpsc-file-badge">PDF</span><span>' . esc_html($file_name ?: __('PDF attachment', 'wp-smart-chatbot')) . '</span></a></div>';
    }

    private function conversation_lead_summary_html($conversation) {
        if (empty($conversation['lead_id'])) {
            return '';
        }

        $lead = $this->repository->get_lead((int) $conversation['lead_id']);
        if (!$lead) {
            return '';
        }

        $type = $this->lead_type_for_lead($lead);
        $forms = $this->admin_form_request_types();
        $title = $forms[$type]['tab'] ?? __('Lead details', 'wp-smart-chatbot');
        $details = $this->lead_message_detail_rows($lead);

        // Extract initials for the avatar badge
        $parts = preg_split('/\s+/', trim((string) $lead['name']));
        $initials = '';
        if (count($parts) > 0 && !empty($parts[0])) {
            $initials .= strtoupper(substr($parts[0], 0, 1));
            if (count($parts) > 1 && !empty($parts[count($parts) - 1])) {
                $initials .= strtoupper(substr($parts[count($parts) - 1], 0, 1));
            }
        }
        if (!$initials) {
            $initials = 'U';
        }

        $html = '<section class="wpsc-lead-summary">';
        $html .= '<div class="wpsc-lead-contact-profile">';
        $html .= '<div class="wpsc-lead-avatar">' . esc_html($initials) . '</div>';
        $html .= '<div class="wpsc-lead-main-info">';
        $html .= '<div class="wpsc-lead-name-row">';
        $html .= '<span class="wpsc-lead-name">' . esc_html($lead['name']) . '</span>';
        $html .= '<span class="wpsc-lead-badge-status wpsc-badge-' . esc_attr($type) . '">' . esc_html($title) . ' (' . esc_html($lead['status']) . ')</span>';
        $html .= '</div>'; // wpsc-lead-name-row

        $html .= '<div class="wpsc-lead-meta-row">';
        if (!empty($lead['email'])) {
            $html .= '<span class="wpsc-lead-meta-item wpsc-meta-email" title="' . esc_attr__('Email', 'wp-smart-chatbot') . '"><span class="dashicons dashicons-email"></span> ' . esc_html($lead['email']) . '</span>';
        }
        if (!empty($lead['phone'])) {
            $html .= '<span class="wpsc-lead-meta-item wpsc-meta-phone" title="' . esc_attr__('Phone', 'wp-smart-chatbot') . '"><span class="dashicons dashicons-phone"></span> ' . esc_html($lead['phone']) . '</span>';
        }
        if (!empty($lead['company'])) {
            $html .= '<span class="wpsc-lead-meta-item wpsc-meta-company" title="' . esc_attr__('Business', 'wp-smart-chatbot') . '"><span class="dashicons dashicons-store"></span> ' . esc_html($lead['company']) . '</span>';
        }
        $html .= '<span class="wpsc-lead-meta-item wpsc-meta-captured" title="' . esc_attr__('Captured At', 'wp-smart-chatbot') . '"><span class="dashicons dashicons-clock"></span> ' . esc_html(wpsc_format_datetime($lead['created_at'])) . '</span>';
        $html .= '</div>'; // wpsc-lead-meta-row
        $html .= '</div>'; // wpsc-lead-main-info
        $html .= '</div>'; // wpsc-lead-contact-profile

        // Extra details (custom form fields/questions)
        if (!empty($details) || !empty($lead['service_interest'])) {
            $html .= '<div class="wpsc-lead-extra-details">';
            if (!empty($lead['service_interest'])) {
                $html .= '<div class="wpsc-lead-extra-item"><strong>' . esc_html($forms[$type]['detail_label'] ?? __('Type', 'wp-smart-chatbot')) . ':</strong> ' . esc_html($lead['service_interest']) . '</div>';
            }
            foreach ($details as $label => $value) {
                if (trim($value) !== '') {
                    $html .= '<div class="wpsc-lead-extra-item"><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</div>';
                }
            }
            $html .= '</div>'; // wpsc-lead-extra-details
        }

        $html .= '</section>';

        return $html;
    }

    private function lead_message_detail_rows($lead) {
        $rows = [];
        foreach (preg_split('/\r\n|\r|\n/', (string) ($lead['message'] ?? '')) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (strpos($line, ':') !== false) {
                [$label, $value] = array_map('trim', explode(':', $line, 2));
                if ($label !== '' && $value !== '') {
                    $rows[$label] = wpsc_format_date_value($value);
                    continue;
                }
            }
            $line = wpsc_format_date_value($line);
            $rows['Message'] = isset($rows['Message']) ? $rows['Message'] . "\n" . $line : $line;
        }

        return $rows;
    }

    private function conversation_reply_form($conversation_id) {
        $settings = $this->settings->all();
        $default_name = $this->default_agent_reply_name($settings);
        echo '<form method="post" class="wpsc-card wpsc-reply-form" data-conversation-id="' . esc_attr($conversation_id) . '">';
        wp_nonce_field('wpsc_conversation_reply');
        echo '<input type="hidden" name="wpsc_action" value="conversation_reply"><input type="hidden" name="conversation_id" value="' . esc_attr($conversation_id) . '">';
        echo '<p><label>Display as<br><input type="text" name="agent_name" class="regular-text" value="' . esc_attr($default_name) . '" placeholder="' . esc_attr__('Customer Support Team', 'wp-smart-chatbot') . '"></label></p>';
        echo '<p class="description">Use a team name, department, or person for this reply. Leave blank to use the Branding default. Agent names can also be hidden globally in Branding.</p>';
        echo '<p><label>Reply<br><textarea name="message" rows="4" class="large-text" required></textarea></label></p>';
        submit_button(__('Send agent reply', 'wp-smart-chatbot'));
        echo '</form>';
    }

    private function default_agent_reply_name($settings = null) {
        $settings = $settings ?: $this->settings->all();
        if (($settings['agent_name_mode'] ?? 'team') === 'hidden') {
            return '';
        }
        if (($settings['agent_name_mode'] ?? 'team') === 'user') {
            $user = wp_get_current_user();
            if ($user && $user->exists()) {
                return sanitize_text_field($user->display_name ?: $user->user_login);
            }
        }

        return sanitize_text_field($settings['agent_display_name'] ?? '') ?: wpsc_default_settings()['agent_display_name'];
    }

    private function conversation_lead_request_form($conversation_id) {
        $settings = $this->settings->all();
        $enabled = array_filter($this->admin_form_request_types(), function ($form, $type) use ($settings) {
            return ($settings['admin_quick_' . $type . '_enabled'] ?? '1') === '1';
        }, ARRAY_FILTER_USE_BOTH);

        if (!$enabled) {
            return;
        }

        echo '<form method="post" class="wpsc-card wpsc-lead-request-form" data-conversation-id="' . esc_attr($conversation_id) . '">';
        wp_nonce_field('wpsc_conversation_lead_request');
        echo '<input type="hidden" name="wpsc_action" value="conversation_lead_request"><input type="hidden" name="conversation_id" value="' . esc_attr($conversation_id) . '"><input type="hidden" name="form_type" value="lead">';
        echo '<p><strong>Request details</strong></p>';
        echo '<p class="description">Send the visitor a form inside the chat. Submitted details will appear in Leads.</p>';
        echo '<div class="wpsc-admin-quick-actions">';
        foreach ($enabled as $type => $form) {
            echo '<button type="submit" name="form_type" value="' . esc_attr($type) . '" class="button button-secondary wpsc-form-request-button" data-form-type="' . esc_attr($type) . '">' . esc_html($form['button']) . '</button> ';
        }
        echo '</div>';
        echo '</form>';
    }

    private function admin_form_request_types() {
        $forms = [
            'lead' => [
                'label' => __('Lead details form', 'wp-smart-chatbot'),
                'button' => __('Send Lead Details Form', 'wp-smart-chatbot'),
                'tab' => __('General Leads', 'wp-smart-chatbot'),
                'service_interest' => 'General lead capture',
                'detail_label' => __('Enquiry', 'wp-smart-chatbot'),
                'message' => __('Please leave your name, email, phone number, and a short message so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'order' => [
                'label' => __('Order details form', 'wp-smart-chatbot'),
                'button' => __('Send Order Details Form', 'wp-smart-chatbot'),
                'tab' => __('Orders', 'wp-smart-chatbot'),
                'service_interest' => 'Order details',
                'detail_label' => __('Product / Order', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details and order information so the team can check it manually.', 'wp-smart-chatbot'),
            ],
            'service' => [
                'label' => __('Service enquiry form', 'wp-smart-chatbot'),
                'button' => __('Send Service Enquiry Form', 'wp-smart-chatbot'),
                'tab' => __('Services', 'wp-smart-chatbot'),
                'service_interest' => 'Service enquiry',
                'detail_label' => __('Service', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details and the service you need so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'booking' => [
                'label' => __('Booking details form', 'wp-smart-chatbot'),
                'button' => __('Send Booking Details Form', 'wp-smart-chatbot'),
                'tab' => __('Bookings', 'wp-smart-chatbot'),
                'service_interest' => 'Booking details',
                'detail_label' => __('Booking / Dates', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details and preferred booking information so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'accommodation' => [
                'label' => __('Accommodation enquiry form', 'wp-smart-chatbot'),
                'button' => __('Send Accommodation Enquiry Form', 'wp-smart-chatbot'),
                'tab' => __('Accommodation', 'wp-smart-chatbot'),
                'service_interest' => 'Accommodation enquiry',
                'detail_label' => __('Room / Dates', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details, preferred dates, and accommodation requirements so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'finance' => [
                'label' => __('Finance enquiry form', 'wp-smart-chatbot'),
                'button' => __('Send Finance Enquiry Form', 'wp-smart-chatbot'),
                'tab' => __('Finance Enquiries', 'wp-smart-chatbot'),
                'service_interest' => 'Finance enquiry',
                'detail_label' => __('Product / Amount', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details and finance enquiry so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'support' => [
                'label' => __('Support ticket form', 'wp-smart-chatbot'),
                'button' => __('Send Support Ticket Form', 'wp-smart-chatbot'),
                'tab' => __('Support Tickets', 'wp-smart-chatbot'),
                'service_interest' => 'Support ticket',
                'detail_label' => __('Issue', 'wp-smart-chatbot'),
                'message' => __('Please leave your contact details and support issue so the team can investigate.', 'wp-smart-chatbot'),
            ],
        ];

        foreach ($this->settings->custom_forms() as $form) {
            $key = 'custom_' . $form['id'];
            $forms[$key] = [
                'label' => $form['name'],
                'button' => sprintf(__('Send %s Form', 'wp-smart-chatbot'), $form['name']),
                'tab' => $form['name'],
                'service_interest' => $form['service_interest'] ?: $form['name'],
                'detail_label' => __('Details', 'wp-smart-chatbot'),
                'message' => sprintf(__('Please complete the %s form so the team can follow up.', 'wp-smart-chatbot'), $form['name']),
                'form_type' => 'custom',
                'custom_form' => $form,
            ];
        }

        return $forms;
    }

    private function canned_action_options() {
        $actions = [
            'send_message' => __('Send message', 'wp-smart-chatbot'),
            'open_url' => __('Open URL', 'wp-smart-chatbot'),
            'handover' => __('Human handover', 'wp-smart-chatbot'),
            'start_ai' => __('Start AI response', 'wp-smart-chatbot'),
        ];

        foreach ($this->admin_form_request_types() as $type => $form) {
            $actions['ask_' . $type] = sprintf(__('Send %s', 'wp-smart-chatbot'), $form['label']);
        }

        $actions['ask_contact'] = __('Send general contact form', 'wp-smart-chatbot');
        return $actions;
    }

    private function lead_type_for_lead($lead) {
        $service = strtolower(trim((string) ($lead['service_interest'] ?? '')));
        $map = [];
        foreach ($this->admin_form_request_types() as $type => $form) {
            $map[strtolower($form['service_interest'])] = $type;
            $map[strtolower($form['label'])] = $type;
        }
        $map['lead details'] = 'lead';
        $map['order details'] = 'order';
        $map['booking details'] = 'booking';
        $map['accommodation enquiry'] = 'accommodation';
        $map['finance enquiry'] = 'finance';
        $map['support ticket'] = 'support';
        $map['service enquiry'] = 'service';

        return $map[$service] ?? 'lead';
    }

    private function lead_details_for_display($lead) {
        $message = trim((string) ($lead['message'] ?? ''));
        $primary = $lead['service_interest'] ?: __('General enquiry', 'wp-smart-chatbot');
        $summary = wpsc_format_date_values_in_text($message);

        foreach (preg_split('/\r\n|\r|\n/', $message) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(Product|Product or item|Order number|Booking number|Date range|Preferred date|Property or room|Guests|Service|Support topic|Finance amount|Budget):\s*(.+)$/i', $line, $matches)) {
                $primary = wpsc_format_date_value($matches[2]);
                break;
            }
        }

        return [
            'primary' => $primary,
            'summary' => wp_trim_words($summary, 18),
        ];
    }

    private function conversation_status_form($conversation_id, $status) {
        echo '<form method="post" class="wpsc-inline-controls">';
        wp_nonce_field('wpsc_conversation_status');
        echo '<input type="hidden" name="wpsc_action" value="update_conversation_status"><input type="hidden" name="conversation_id" value="' . esc_attr($conversation_id) . '">';
        echo '<select name="status">';
        foreach (['bot', 'waiting_human', 'human', 'offline', 'closed'] as $item) {
            echo '<option value="' . esc_attr($item) . '"' . selected($status, $item, false) . '>' . esc_html($item) . '</option>';
        }
        echo '</select> ';
        submit_button(__('Update status', 'wp-smart-chatbot'), 'secondary', 'submit', false);
        echo '</form>';
    }

    private function conversation_delete_form($conversation_id) {
        echo '<form method="post" class="wpsc-inline-controls">';
        wp_nonce_field('wpsc_delete_conversation');
        echo '<input type="hidden" name="wpsc_action" value="delete_conversation"><input type="hidden" name="conversation_id" value="' . esc_attr($conversation_id) . '">';
        echo '<button type="submit" class="button-link-delete" onclick="return confirm(\'Delete this conversation and its messages?\')">Delete conversation</button>';
        echo '</form>';
    }

    private function flow_option_row($responses, $response_id, $index, $option) {
        $prefix = 'flow[' . (int) $response_id . '][options][' . (int) $index . ']';
        echo '<div class="wpsc-flow-option">';
        echo '<input type="text" name="' . esc_attr($prefix) . '[label]" value="' . esc_attr($option['label'] ?? '') . '" placeholder="Button label">';
        echo '<select name="' . esc_attr($prefix) . '[action_type]">';
        foreach ($this->canned_action_options() as $action => $label) {
            echo '<option value="' . esc_attr($action) . '"' . selected($option['action_type'] ?? 'send_message', $action, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<select class="wpsc-flow-target" name="' . esc_attr($prefix) . '[target_id]">';
        echo '<option value="0">No next step</option>';
        foreach ($responses as $target) {
            if ((int) $target['id'] === (int) $response_id) {
                continue;
            }
            echo '<option value="' . esc_attr($target['id']) . '"' . selected((int) ($option['target_id'] ?? 0), (int) $target['id'], false) . '>' . esc_html($target['title']) . '</option>';
        }
        echo '</select>';
        echo '<textarea name="' . esc_attr($prefix) . '[response_text]" placeholder="Optional immediate reply">' . esc_textarea($option['response_text'] ?? '') . '</textarea>';
        echo '<div class="wpsc-media-field wpsc-flow-image-field">';
        echo '<input type="hidden" class="wpsc-media-url" name="' . esc_attr($prefix) . '[image_url]" value="' . esc_attr($option['image_url'] ?? '') . '">';
        echo '<div class="wpsc-logo-preview">';
        if (!empty($option['image_url'])) {
            echo '<img src="' . esc_url($option['image_url']) . '" alt="">';
        }
        echo '</div>';
        echo '<p><button type="button" class="button button-small wpsc-media-pick">Choose image</button> <button type="button" class="button button-small wpsc-media-clear">Remove</button></p>';
        echo '</div>';
        echo '</div>';
    }

    private function canned_option_editor($options, $current_id = 0) {
        $options = is_array($options) ? array_values($options) : [];
        if (!$options) {
            $options = [
                ['label' => '', 'action_type' => 'send_message', 'response_text' => '', 'target_id' => 0, 'image_url' => ''],
            ];
        }

        echo '<section class="wpsc-option-editor">';
        echo '<div class="wpsc-option-editor-header"><div><h2>Follow-up options</h2><p class="description">Create the buttons or cards visitors can choose next. Each card can have its own image.</p></div><button type="button" class="button wpsc-add-canned-option">Add option</button></div>';
        echo '<div class="wpsc-canned-options">';
        foreach ($options as $index => $option) {
            $this->canned_option_card($index, $option, $current_id);
        }
        echo '</div>';
        echo '<template id="wpsc-canned-option-template">';
        $this->canned_option_card('__INDEX__', ['label' => '', 'action_type' => 'send_message', 'response_text' => '', 'target_id' => 0, 'image_url' => ''], $current_id);
        echo '</template>';
        echo '</section>';
    }

    private function canned_card_design_controls($payload) {
        $default_style = $this->settings->get('card_default_style', 'split');
        $style = in_array(($payload['card_style'] ?? $default_style), ['split', 'cover'], true) ? ($payload['card_style'] ?? $default_style) : 'split';
        $text_color = sanitize_hex_color($payload['card_text_color'] ?? '');
        if (!$text_color) {
            $text_color = $this->settings->get('card_default_text_color', '#ffffff');
        }
        $background_color = sanitize_hex_color($payload['card_label_background_color'] ?? '') ?: $this->settings->get('card_default_background_color', '#111827');
        $opacity = isset($payload['card_overlay_opacity']) ? min(100, max(0, (int) $payload['card_overlay_opacity'])) : min(100, max(0, (int) $this->settings->get('card_default_overlay_opacity', 88)));
        $default_position = $this->settings->get('card_default_text_position', 'bottom');
        $position = in_array(($payload['card_text_position'] ?? $default_position), ['bottom', 'center'], true) ? ($payload['card_text_position'] ?? $default_position) : 'bottom';
        $default_shape = $this->settings->get('card_default_image_shape', 'square');
        $shape = in_array(($payload['card_image_shape'] ?? $default_shape), ['landscape', 'square', 'portrait'], true) ? ($payload['card_image_shape'] ?? $default_shape) : 'square';

        echo '<fieldset class="wpsc-fieldset wpsc-card-design"><legend>Card design</legend>';
        echo '<p class="description">These settings apply when Choice Display is set to image/card options.</p>';
        echo '<div class="wpsc-card-design-grid">';
        echo '<p><label>Card style<br><select name="canned[card_style]">';
        foreach (['split' => 'Image top, text below', 'cover' => 'Full-cover image with text overlay'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($style, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Image shape<br><select name="canned[card_image_shape]">';
        foreach (['landscape' => 'Landscape', 'square' => 'Square', 'portrait' => 'Portrait'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($shape, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Text colour<br><input type="color" name="canned[card_text_color]" value="' . esc_attr($text_color) . '"></label></p>';
        echo '<p><label>Text background colour<br><input type="color" name="canned[card_label_background_color]" value="' . esc_attr($background_color) . '"></label></p>';
        echo '<p><label>Text background opacity<br><input type="range" min="0" max="100" name="canned[card_overlay_opacity]" value="' . esc_attr($opacity) . '" class="wpsc-range-with-output"> <span class="wpsc-range-output">' . esc_html($opacity) . '%</span></label></p>';
        echo '<p><label>Text position<br><select name="canned[card_text_position]">';
        foreach (['bottom' => 'Bottom', 'center' => 'Centre'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($position, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '</div></fieldset>';
    }

    private function canned_slideshow_controls($element) {
        $element = is_array($element) ? $element : [];
        $enabled = ($element['type'] ?? '') === 'slideshow';
        $features = $element['features'] ?? [];
        if (is_array($features)) {
            $features = implode("\n", $features);
        }
        $slides = is_array($element['slides'] ?? null) ? array_values($element['slides']) : [];
        if (!$slides) {
            $slides = [['image_url' => '', 'alt' => '']];
        }

        echo '<fieldset class="wpsc-fieldset wpsc-slideshow-editor"><legend>Reusable slideshow element</legend>';
        echo '<p><label><input type="checkbox" name="canned[content_element][enabled]" value="1" ' . checked($enabled, true, false) . '> Add slideshow / listing carousel after this message</label></p>';
        echo '<div class="wpsc-card-design-grid">';
        echo '<p><label>Listing title<br><input type="text" name="canned[content_element][title]" value="' . esc_attr($element['title'] ?? '') . '"></label></p>';
        echo '<p><label>Button text<br><input type="text" name="canned[content_element][button_text]" value="' . esc_attr($element['button_text'] ?? '') . '" placeholder="Check availability & rates"></label></p>';
        echo '<p><label>Button destination URL<br><input type="url" name="canned[content_element][button_url]" value="' . esc_attr($element['button_url'] ?? '') . '" class="regular-text"></label></p>';
        echo '</div>';
        echo '<p><label>Description<br><textarea name="canned[content_element][description]" rows="4" class="large-text">' . esc_textarea($element['description'] ?? '') . '</textarea></label></p>';
        echo '<p><label>Features, one per line<br><textarea name="canned[content_element][features]" rows="4" class="large-text" placeholder="Sleeps 6&#10;Wi-Fi&#10;Pet friendly">' . esc_textarea($features) . '</textarea></label></p>';
        echo '<h3>Slides</h3><div class="wpsc-slideshow-slides">';
        foreach ($slides as $index => $slide) {
            $this->slideshow_slide_card($index, $slide);
        }
        echo '</div><p><button type="button" class="button wpsc-add-slideshow-slide">Add slide</button></p>';
        echo '<template id="wpsc-slideshow-slide-template">';
        $this->slideshow_slide_card('__INDEX__', ['image_url' => '', 'alt' => '']);
        echo '</template></fieldset>';
    }

    private function slideshow_slide_card($index, $slide) {
        $prefix = 'canned[content_element][slides][' . $index . ']';
        echo '<article class="wpsc-slideshow-slide wpsc-media-field">';
        echo '<div class="wpsc-option-card-top"><strong>Slide</strong><button type="button" class="button-link-delete wpsc-remove-slideshow-slide">Remove</button></div>';
        echo '<input type="hidden" class="wpsc-media-url" name="' . esc_attr($prefix) . '[image_url]" value="' . esc_attr($slide['image_url'] ?? '') . '">';
        echo '<div class="wpsc-logo-preview">';
        if (!empty($slide['image_url'])) {
            echo '<img src="' . esc_url($slide['image_url']) . '" alt="">';
        }
        echo '</div>';
        echo '<p><button type="button" class="button wpsc-media-pick">Choose image</button> <button type="button" class="button wpsc-media-clear">Remove</button></p>';
        echo '<p><label>Alt text<br><input type="text" name="' . esc_attr($prefix) . '[alt]" value="' . esc_attr($slide['alt'] ?? '') . '" class="regular-text"></label></p>';
        echo '</article>';
    }

    private function canned_option_card($index, $option, $current_id = 0) {
        $prefix = 'canned[options][' . $index . ']';
        echo '<article class="wpsc-canned-option-card">';
        echo '<div class="wpsc-option-card-top"><strong>Option</strong><button type="button" class="button-link-delete wpsc-remove-canned-option">Remove</button></div>';
        echo '<div class="wpsc-option-fields">';
        echo '<p><label>Button label<br><input type="text" name="' . esc_attr($prefix) . '[label]" value="' . esc_attr($option['label'] ?? '') . '" class="regular-text" placeholder="Phone and email"></label></p>';
        echo '<p><label>Action<br><select name="' . esc_attr($prefix) . '[action_type]">';
        foreach ($this->canned_action_options() as $action => $label) {
            echo '<option value="' . esc_attr($action) . '"' . selected($option['action_type'] ?? 'send_message', $action, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Next canned response<br><select name="' . esc_attr($prefix) . '[target_id]">';
        echo '<option value="0">No next step</option>';
        foreach ($this->repository->list_canned_responses(false) as $response) {
            if ((int) $response['id'] === (int) $current_id) {
                continue;
            }
            echo '<option value="' . esc_attr($response['id']) . '"' . selected((int) ($option['target_id'] ?? 0), (int) $response['id'], false) . '>' . esc_html($response['title']) . '</option>';
        }
        echo '</select></label></p>';
        echo '</div>';
        echo '<p><label>Immediate reply<br><textarea name="' . esc_attr($prefix) . '[response_text]" rows="3" class="large-text" placeholder="Optional message before the next step">' . esc_textarea($option['response_text'] ?? '') . '</textarea></label></p>';
        echo '<div class="wpsc-media-field wpsc-canned-option-image">';
        echo '<label>Card image</label>';
        echo '<div class="wpsc-logo-preview">';
        if (!empty($option['image_url'])) {
            echo '<img src="' . esc_url($option['image_url']) . '" alt="">';
        }
        echo '</div>';
        echo '<input type="hidden" class="wpsc-media-url" name="' . esc_attr($prefix) . '[image_url]" value="' . esc_attr($option['image_url'] ?? '') . '">';
        echo '<p><button type="button" class="button wpsc-media-pick">Choose image</button> <button type="button" class="button wpsc-media-clear">Remove image</button></p>';
        echo '</div>';
        echo '</article>';
    }

    private function custom_form_field_card($index, $field) {
        $prefix = 'custom_form[fields][' . $index . ']';
        $options = $field['options'] ?? [];
        if (is_array($options)) {
            $options = implode("\n", $options);
        }
        $field_key = sanitize_key($field['key'] ?? '');
        $key_options = $this->custom_form_field_key_options();
        if ($field_key && !isset($key_options[$field_key])) {
            $key_options[$field_key] = [
                'label' => $field_key,
                'type' => $field['type'] ?? 'text',
                'description' => __('Imported/custom field key.', 'wp-smart-chatbot'),
            ];
        }

        echo '<article class="wpsc-custom-field-card">';
        echo '<div class="wpsc-option-card-top"><strong>Field</strong><button type="button" class="button-link-delete wpsc-remove-custom-form-field">Remove</button></div>';
        echo '<div class="wpsc-option-fields">';
        echo '<p><label>Label<br><input type="text" name="' . esc_attr($prefix) . '[label]" value="' . esc_attr($field['label'] ?? '') . '" placeholder="Arrival date"></label></p>';
        echo '<p><label>Field key<br><select class="wpsc-field-key-select" name="' . esc_attr($prefix) . '[key]">';
        foreach ($key_options as $key => $item) {
            echo '<option value="' . esc_attr($key) . '" data-type="' . esc_attr($item['type']) . '"' . selected($field_key ?: 'message', $key, false) . '>' . esc_html($item['label']) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Type<br><select name="' . esc_attr($prefix) . '[type]">';
        foreach (['text' => 'Text', 'email' => 'Email', 'tel' => 'Phone', 'textarea' => 'Long text', 'select' => 'Dropdown', 'date' => 'Date', 'number' => 'Number'] as $type => $label) {
            echo '<option value="' . esc_attr($type) . '"' . selected($field['type'] ?? 'text', $type, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label></p>';
        echo '</div>';
        echo '<p><label>Placeholder<br><input type="text" class="regular-text" name="' . esc_attr($prefix) . '[placeholder]" value="' . esc_attr($field['placeholder'] ?? '') . '"></label></p>';
        echo '<p><label><input type="checkbox" name="' . esc_attr($prefix) . '[required]" value="1" ' . checked(($field['required'] ?? '0'), '1', false) . '> Required</label></p>';
        echo '<p><label>Dropdown options, one per line<br><textarea name="' . esc_attr($prefix) . '[options]" rows="3" class="large-text" placeholder="Studio&#10;One bedroom&#10;Two bedroom">' . esc_textarea($options) . '</textarea></label></p>';
        echo '</article>';
    }

    private function custom_form_field_key_options() {
        return [
            'name' => ['label' => 'Name', 'type' => 'text', 'description' => 'Visitor or customer name.'],
            'email' => ['label' => 'Email', 'type' => 'email', 'description' => 'Visitor email address.'],
            'phone' => ['label' => 'Phone', 'type' => 'tel', 'description' => 'Visitor phone or mobile number.'],
            'company' => ['label' => 'Business / company', 'type' => 'text', 'description' => 'Business name where applicable.'],
            'message' => ['label' => 'Message / notes', 'type' => 'textarea', 'description' => 'Main enquiry message shown in lead details.'],
            'service_required' => ['label' => 'Service required', 'type' => 'text', 'description' => 'Service enquiry details.'],
            'service_interest' => ['label' => 'Lead category', 'type' => 'text', 'description' => 'Optional category or interest label.'],
            'product' => ['label' => 'Product', 'type' => 'text', 'description' => 'Product or item related to the enquiry.'],
            'order_number' => ['label' => 'Order number', 'type' => 'text', 'description' => 'Order, invoice, or account reference.'],
            'booking_number' => ['label' => 'Booking number', 'type' => 'text', 'description' => 'Booking or appointment reference.'],
            'booking_type' => ['label' => 'Booking type', 'type' => 'text', 'description' => 'Appointment, booking, or stay type.'],
            'property_or_room' => ['label' => 'Property or room', 'type' => 'text', 'description' => 'Accommodation property, room, or listing.'],
            'guests' => ['label' => 'Guests', 'type' => 'number', 'description' => 'Number of guests or people.'],
            'preferred_date' => ['label' => 'Preferred date', 'type' => 'date', 'description' => 'Single preferred date.'],
            'date_range' => ['label' => 'Date range', 'type' => 'text', 'description' => 'Free-text date range such as arrival/departure.'],
            'preferred_time' => ['label' => 'Preferred time', 'type' => 'text', 'description' => 'Preferred contact or appointment time.'],
            'location' => ['label' => 'Location / suburb', 'type' => 'text', 'description' => 'Visitor location, suburb, or service area.'],
            'finance_amount' => ['label' => 'Finance amount / budget', 'type' => 'text', 'description' => 'Approximate amount, budget, or finance requirement.'],
            'support_topic' => ['label' => 'Support topic', 'type' => 'select', 'description' => 'Support category such as checkout, delivery, warranty, or account.'],
        ];
    }

    private function canned_fast_reply_picker($current_id, $selected_ids) {
        $selected_ids = array_map('intval', is_array($selected_ids) ? $selected_ids : []);
        echo '<fieldset class="wpsc-fieldset"><legend>Fast replies after this response</legend>';
        echo '<p class="description">Choose canned responses to show as quick next-step replies. Leave empty to use this response\'s own follow-up options.</p>';
        foreach ($this->repository->list_canned_responses(true) as $response) {
            if ((int) $response['id'] === (int) $current_id) {
                continue;
            }
            echo '<label><input type="checkbox" name="canned[fast_reply_ids][]" value="' . esc_attr($response['id']) . '" ' . checked(in_array((int) $response['id'], $selected_ids, true), true, false) . '> ' . esc_html($response['trigger_label']) . '</label> ';
        }
        echo '</fieldset>';
    }

    private function save_flow_builder($flow) {
        foreach ($flow as $id => $node) {
            $id = (int) $id;
            $response = $this->repository->get_canned_response($id);
            if (!$response) {
                continue;
            }

            $payload = wpsc_json_decode($response['action_payload'] ?? '{}');
            $payload['position'] = [
                'x' => isset($node['x']) ? (int) $node['x'] : 0,
                'y' => isset($node['y']) ? (int) $node['y'] : 0,
            ];
            $payload['options'] = [];

            foreach (($node['options'] ?? []) as $option) {
                $label = sanitize_text_field($option['label'] ?? '');
                if ($label === '') {
                    continue;
                }
                $payload['options'][] = [
                    'label' => $label,
                    'action_type' => sanitize_key($option['action_type'] ?? 'send_message'),
                    'response_text' => sanitize_textarea_field($option['response_text'] ?? ''),
                    'target_id' => (int) ($option['target_id'] ?? 0),
                    'image_url' => esc_url_raw($option['image_url'] ?? ''),
                ];
            }

            $this->repository->save_canned_response([
                'title' => $response['title'],
                'trigger_label' => $response['trigger_label'],
                'response_text' => $response['response_text'],
                'action_type' => $response['action_type'],
                'action_payload' => $payload,
                'sort_order' => $response['sort_order'],
                'is_active' => $response['is_active'],
            ], $id);
        }
    }

    private function update_business_info_flow() {
        foreach ($this->repository->list_canned_responses(false) as $response) {
            if ($response['title'] !== 'FAQ: Business Information') {
                continue;
            }

            $payload = wpsc_json_decode($response['action_payload'] ?? '{}');
            $existing_options = [];
            foreach (($payload['options'] ?? []) as $option) {
                if (!is_array($option) || empty($option['label'])) {
                    continue;
                }
                $existing_options[strtolower(trim((string) $option['label']))] = $option;
            }

            $payload['choice_display'] = 'cards';
            $payload['options'] = [
                $this->business_info_option_with_existing_media($existing_options, [
                    'label' => 'Phone and email',
                    'action_type' => 'send_message',
                    'response_text' => "Phone: {business_phone}\nEmail: {business_email}",
                    'target_id' => 0,
                ]),
                $this->business_info_option_with_existing_media($existing_options, [
                    'label' => 'Address',
                    'action_type' => 'send_message',
                    'response_text' => "Address / service area:\n{business_address}",
                    'target_id' => 0,
                ]),
                $this->business_info_option_with_existing_media($existing_options, [
                    'label' => 'Trading hours',
                    'action_type' => 'send_message',
                    'response_text' => 'Trading hours: {business_hours}',
                    'target_id' => 0,
                ]),
            ];

            $this->repository->save_canned_response([
                'title' => $response['title'],
                'trigger_label' => $response['trigger_label'],
                'response_text' => $response['response_text'],
                'action_type' => $response['action_type'],
                'action_payload' => $payload,
                'sort_order' => $response['sort_order'],
                'is_active' => $response['is_active'],
            ], (int) $response['id']);
            return;
        }
    }

    private function business_info_option_with_existing_media($existing_options, $option) {
        $key = strtolower(trim((string) ($option['label'] ?? '')));
        $existing = $existing_options[$key] ?? [];

        if (!empty($existing['image_url'])) {
            $option['image_url'] = esc_url_raw($existing['image_url']);
        }

        return $option;
    }

    private function handle_document_upload() {
        if (empty($_FILES['file'])) {
            $this->set_admin_notice('No document file was uploaded.', 'error');
            return false;
        }

        $allowed = [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'txt' => 'text/plain',
            'md' => 'text/markdown',
            'html' => 'text/html',
            'htm' => 'text/html',
            'csv' => 'text/csv',
            'json' => 'application/json',
        ];

        $file = $_FILES['file'];
        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $allowed);
        if (empty($check['ext']) || empty($check['type'])) {
            $this->set_admin_notice('This document type is not allowed. Please upload PDF, DOC, DOCX, TXT, MD, HTML, CSV, or JSON.', 'error');
            return false;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        $upload = wp_handle_upload($file, ['test_form' => false, 'mimes' => $allowed]);
        if (isset($upload['error'])) {
            $this->set_admin_notice($upload['error'], 'error');
            return false;
        }

        $document = $this->repository->add_document([
            'title' => sanitize_text_field(wp_unslash($_POST['title'] ?? pathinfo($file['name'], PATHINFO_FILENAME))),
            'file_name' => $file['name'],
            'file_path' => $upload['url'],
            'file_local_path' => $upload['file'],
            'mime_type' => $upload['type'],
            'status' => 'uploaded',
        ]);

        if (!$this->settings->get_openai_api_key()) {
            $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. Add an OpenAI API key in AI Settings, then retry indexing.',
            ]);
            $this->set_admin_notice('Document saved locally. Add an OpenAI API key, then retry indexing.', 'success');
            return true;
        }

        $indexed = (new WPSC_AI_Service($this->settings))->index_document($upload['file'], $file['name']);
        if (is_wp_error($indexed)) {
            $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(),
            ]);
            $this->set_admin_notice('Document saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(), 'error');
            return true;
        }

        $this->repository->update_document((int) $document['id'], [
            'status' => $indexed['status'] ?? 'processing',
            'indexing_error' => '',
            'openai_file_id' => $indexed['openai_file_id'],
            'vector_store_id' => $indexed['vector_store_id'],
        ]);
        return true;
    }

    private function handle_knowledge_source() {
        $source_type = sanitize_key(wp_unslash($_POST['source_type'] ?? ''));
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));

        if ($source_type === 'web') {
            return $this->handle_web_knowledge_source($title);
        }

        if ($source_type === 'faq') {
            return $this->handle_faq_knowledge_source($title);
        }

        if ($source_type === 'rich') {
            $content = $this->normalise_knowledge_text(wp_unslash($_POST['content'] ?? ''));
            if (!$title || !$content) {
                $this->set_admin_notice('Add a title and content before indexing rich text.', 'error');
                return false;
            }
            return $this->save_generated_knowledge_document($title, $title . '.md', "# {$title}\n\n" . $content, 'text/markdown');
        }

        if ($source_type === 'table') {
            $content = $this->normalise_knowledge_text(wp_unslash($_POST['content'] ?? ''));
            if (!$title || !$content) {
                $this->set_admin_notice('Add a title and rows before indexing table data.', 'error');
                return false;
            }
            return $this->save_generated_knowledge_document($title, $title . '.csv', $content, 'text/csv');
        }

        $this->set_admin_notice('Choose a valid knowledge source type.', 'error');
        return false;
    }

    private function handle_web_knowledge_source($title) {
        $url = esc_url_raw(wp_unslash($_POST['source_url'] ?? ''));
        if (!$url || !wp_http_validate_url($url)) {
            $this->set_admin_notice('Enter a valid public HTTP or HTTPS URL.', 'error');
            return false;
        }

        $response = wp_remote_get($url, [
            'timeout' => 15,
            'redirection' => 3,
            'limit_response_size' => 1024 * 1024,
            'user-agent' => 'Q Digital Chatbot Knowledgebase',
        ]);
        if (is_wp_error($response)) {
            $this->set_admin_notice('Could not fetch the page: ' . $response->get_error_message(), 'error');
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            $this->set_admin_notice('The page returned HTTP ' . $code . '.', 'error');
            return false;
        }

        $html = (string) wp_remote_retrieve_body($response);
        $html = preg_replace('/<(script|style|noscript)\b[^>]*>.*?<\/\1>/is', ' ', $html);
        $text = $this->normalise_knowledge_text(wp_strip_all_tags($html));
        if (!$text) {
            $this->set_admin_notice('The page did not contain readable text.', 'error');
            return false;
        }

        if (!$title) {
            $host = wp_parse_url($url, PHP_URL_HOST);
            $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
            $title = trim(($host ?: 'Imported page') . ($path ? ' / ' . $path : ''));
        }

        return $this->save_generated_knowledge_document($title, $title . '.txt', "Source URL: {$url}\n\n" . $text, 'text/plain');
    }

    private function handle_faq_knowledge_source($title) {
        $questions = isset($_POST['faq_question']) && is_array($_POST['faq_question']) ? wp_unslash($_POST['faq_question']) : [];
        $answers = isset($_POST['faq_answer']) && is_array($_POST['faq_answer']) ? wp_unslash($_POST['faq_answer']) : [];
        $pairs = [];

        foreach ($questions as $index => $question) {
            $question = sanitize_text_field($question);
            $answer = $this->normalise_knowledge_text($answers[$index] ?? '');
            if (!$question || !$answer) {
                continue;
            }
            $pairs[] = "## Q: {$question}\n\nA: {$answer}";
        }

        if (!$pairs) {
            $this->set_admin_notice('Add at least one FAQ question and answer before indexing.', 'error');
            return false;
        }

        $title = $title ?: 'FAQ knowledge';
        return $this->save_generated_knowledge_document($title, $title . '.md', "# {$title}\n\n" . implode("\n\n", $pairs), 'text/markdown');
    }

    private function save_generated_knowledge_document($title, $filename, $contents, $mime_type) {
        $path = $this->write_generated_knowledge_file($filename, $contents);
        if (!$path) {
            $this->set_admin_notice('Could not create the generated knowledge file.', 'error');
            return false;
        }

        $uploads = wp_upload_dir();
        $relative = str_replace('\\', '/', ltrim(substr($path, strlen(trailingslashit($uploads['basedir']))), '/\\'));
        $url = trailingslashit($uploads['baseurl']) . implode('/', array_map('rawurlencode', explode('/', $relative)));
        $document = $this->repository->add_document([
            'title' => $title,
            'file_name' => basename($path),
            'file_path' => $url,
            'file_local_path' => $path,
            'mime_type' => $mime_type,
            'status' => 'uploaded',
        ]);

        if (!$this->settings->get_openai_api_key()) {
            $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. Add an OpenAI API key in AI Settings, then retry indexing.',
            ]);
            $this->set_admin_notice('Knowledge source saved locally. Add an OpenAI API key, then retry indexing.', 'success');
            return true;
        }

        $indexed = (new WPSC_AI_Service($this->settings))->index_document($path, basename($path));
        if (is_wp_error($indexed)) {
            $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(),
            ]);
            $this->set_admin_notice('Knowledge source saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(), 'error');
            return true;
        }

        $this->repository->update_document((int) $document['id'], [
            'status' => $indexed['status'] ?? 'processing',
            'indexing_error' => '',
            'openai_file_id' => $indexed['openai_file_id'],
            'vector_store_id' => $indexed['vector_store_id'],
        ]);
        return true;
    }

    private function write_generated_knowledge_file($filename, $contents) {
        $uploads = wp_upload_dir();
        if (empty($uploads['basedir'])) {
            return '';
        }

        $dir = trailingslashit($uploads['basedir']) . 'wpsc-knowledgebase/' . gmdate('Y/m');
        if (!wp_mkdir_p($dir)) {
            return '';
        }

        $filename = wp_unique_filename($dir, sanitize_file_name($filename));
        $path = trailingslashit($dir) . $filename;
        return file_put_contents($path, $contents) === false ? '' : $path;
    }

    private function normalise_knowledge_text($text) {
        $text = wp_strip_all_tags((string) $text);
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\R{3,}/', "\n\n", $text);
        return trim($text);
    }

    private function handle_retrieval_test() {
        $query = sanitize_text_field(wp_unslash($_POST['retrieval_query'] ?? ''));
        $max_results = min(50, max(1, (int) ($_POST['max_results'] ?? 5)));
        $payload = [
            'query' => $query,
            'max_results' => $max_results,
            'results' => [],
            'error' => '',
        ];

        $result = (new WPSC_AI_Service($this->settings))->test_retrieval($query, $max_results);
        if (is_wp_error($result)) {
            $payload['error'] = $result->get_error_message();
            $this->set_admin_notice($result->get_error_message(), 'error');
        } else {
            $payload['results'] = $result;
            $count = isset($result['data']) && is_array($result['data']) ? count($result['data']) : 0;
            $this->set_admin_notice(sprintf('Retrieved %d matching chunk(s).', $count), 'success');
        }

        set_transient('wpsc_retrieval_test_' . get_current_user_id(), $payload, HOUR_IN_SECONDS);
    }

    private function knowledge_gap_candidates() {
        $items = [];
        foreach ($this->repository->list_feedback_events(30) as $event) {
            $data = wpsc_json_decode($event['event_data'] ?? '{}');
            if (($data['rating'] ?? '') !== 'negative') {
                continue;
            }
            $title = trim((string) ($data['comment'] ?? 'Negative chat feedback'));
            $items[] = [
                'title' => wp_trim_words($title ?: 'Negative chat feedback', 10),
                'summary' => '1 occurrence(s) - 1 negative rating(s)' . (!empty($event['current_url']) ? ' - ' . $event['current_url'] : ''),
                'url' => !empty($event['conversation_id']) ? admin_url('admin.php?page=wpsc-conversations&conversation_id=' . (int) $event['conversation_id']) : admin_url('admin.php?page=wpsc-feedback'),
            ];
        }

        foreach ($this->repository->list_bug_report_events(30) as $event) {
            $data = wpsc_json_decode($event['event_data'] ?? '{}');
            $title = trim((string) ($data['comment'] ?? $data['reason'] ?? 'Reported knowledge issue'));
            $items[] = [
                'title' => wp_trim_words($title ?: 'Reported knowledge issue', 10),
                'summary' => '1 occurrence(s) - reported from visitor chat' . (!empty($event['current_url']) ? ' - ' . $event['current_url'] : ''),
                'url' => !empty($event['conversation_id']) ? admin_url('admin.php?page=wpsc-conversations&conversation_id=' . (int) $event['conversation_id']) : admin_url('admin.php?page=wpsc-reported-bugs'),
            ];
        }

        return array_slice($items, 0, 5);
    }

    private function refresh_processing_documents() {
        if (!$this->settings->get_openai_api_key()) {
            return;
        }

        $ai = new WPSC_AI_Service($this->settings);
        foreach ($this->repository->list_documents(20) as $document) {
            if (($document['status'] ?? '') !== 'processing' || empty($document['openai_file_id']) || empty($document['vector_store_id'])) {
                continue;
            }

            $status = $ai->vector_file_status($document['vector_store_id'], $document['openai_file_id']);
            if (is_wp_error($status)) {
                $this->repository->update_document((int) $document['id'], [
                    'indexing_error' => 'OpenAI status refresh failed: ' . $status->get_error_message(),
                ]);
                continue;
            }

            $this->repository->update_document((int) $document['id'], [
                'status' => $status,
                'indexing_error' => $status === 'failed' ? 'OpenAI reported that indexing failed.' : '',
            ]);
        }
    }

    private function retry_document_index($document_id) {
        $document = $this->repository->get_document($document_id);
        if (!$document) {
            $this->set_admin_notice('Document not found.', 'error');
            return false;
        }

        if (!$this->settings->get_openai_api_key()) {
            $this->repository->update_document($document_id, [
                'status' => 'uploaded',
                'indexing_error' => 'OpenAI API key is not configured.',
            ]);
            $this->set_admin_notice('OpenAI API key is not configured. Add it in AI Settings, then retry.', 'error');
            return false;
        }

        $path = $this->resolve_document_local_path($document);
        if (!$path || !file_exists($path)) {
            $this->repository->update_document($document_id, [
                'status' => 'failed',
                'indexing_error' => 'Local uploaded file could not be found. Re-upload the document.',
            ]);
            $this->set_admin_notice('Local uploaded file could not be found. Re-upload the document.', 'error');
            return false;
        }

        $this->repository->update_document($document_id, [
            'status' => 'processing',
            'indexing_error' => '',
            'file_local_path' => $path,
        ]);

        $indexed = (new WPSC_AI_Service($this->settings))->index_document($path, $document['file_name']);
        if (is_wp_error($indexed)) {
            $this->repository->update_document($document_id, [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(),
            ]);
            $this->set_admin_notice('OpenAI indexing failed: ' . $indexed->get_error_message(), 'error');
            return false;
        }

        $this->repository->update_document($document_id, [
            'status' => $indexed['status'] ?? 'processing',
            'indexing_error' => '',
            'openai_file_id' => $indexed['openai_file_id'],
            'vector_store_id' => $indexed['vector_store_id'],
        ]);
        return true;
    }

    private function resolve_document_local_path($document) {
        if (!empty($document['file_local_path']) && file_exists($document['file_local_path'])) {
            return $document['file_local_path'];
        }

        if (empty($document['file_path'])) {
            return '';
        }

        $uploads = wp_upload_dir();
        if (!empty($uploads['baseurl']) && !empty($uploads['basedir']) && strpos($document['file_path'], $uploads['baseurl']) === 0) {
            $relative = ltrim(substr($document['file_path'], strlen($uploads['baseurl'])), '/\\');
            return trailingslashit($uploads['basedir']) . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relative);
        }

        return '';
    }

    private function prepare_canned_form_data($data) {
        $messages = [];
        foreach (preg_split('/\r\n|\r|\n/', (string) ($data['messages_text'] ?? '')) as $line) {
            $line = trim($line);
            if ($line !== '') {
                $messages[] = $line;
            }
        }

        $options = [];
        if (!empty($data['options']) && is_array($data['options'])) {
            foreach ($data['options'] as $option) {
                $label = sanitize_text_field($option['label'] ?? '');
                if ($label === '') {
                    continue;
                }
                $options[] = [
                    'label' => $label,
                    'action_type' => sanitize_key($option['action_type'] ?? 'send_message'),
                    'response_text' => sanitize_textarea_field($option['response_text'] ?? ''),
                    'target_id' => (int) ($option['target_id'] ?? 0),
                    'image_url' => esc_url_raw($option['image_url'] ?? ''),
                ];
            }
        } else {
            foreach (preg_split('/\r\n|\r|\n/', (string) ($data['options_text'] ?? '')) as $line) {
                $line = trim($line);
                if ($line === '') {
                    continue;
                }

                $parts = array_map('trim', explode('|', $line, 5));
                $label = $parts[0] ?? '';
                $action = $parts[1] ?? 'send_message';
                $response = $parts[2] ?? '';

                if ($label === '') {
                    continue;
                }

                $options[] = [
                    'label' => $label,
                    'action_type' => $action,
                    'response_text' => $response !== '' ? $response : $label,
                    'target_id' => isset($parts[3]) ? (int) $parts[3] : 0,
                    'image_url' => isset($parts[4]) ? esc_url_raw($parts[4]) : '',
                ];
            }
        }

        $card_style = in_array(($data['card_style'] ?? 'split'), ['split', 'cover'], true) ? $data['card_style'] : 'split';
        $card_text_color = sanitize_hex_color($data['card_text_color'] ?? '');
        if (!$card_text_color) {
            $card_text_color = $this->settings->get('card_default_text_color', '#ffffff');
        }
        $card_label_background_color = sanitize_hex_color($data['card_label_background_color'] ?? '') ?: $this->settings->get('card_default_background_color', '#111827');
        $card_position = in_array(($data['card_text_position'] ?? 'bottom'), ['bottom', 'center'], true) ? $data['card_text_position'] : 'bottom';
        $card_image_shape = in_array(($data['card_image_shape'] ?? $this->settings->get('card_default_image_shape', 'square')), ['landscape', 'square', 'portrait'], true) ? ($data['card_image_shape'] ?? $this->settings->get('card_default_image_shape', 'square')) : 'square';

        unset($data['messages_text'], $data['options_text'], $data['options']);
        $data['action_payload'] = [
            'messages' => $messages,
            'options' => $options,
            'choice_display' => in_array(($data['choice_display'] ?? 'bubbles'), ['bubbles', 'cards'], true) ? $data['choice_display'] : 'bubbles',
            'card_image_url' => esc_url_raw($data['card_image_url'] ?? ''),
            'card_style' => $card_style,
            'card_text_color' => $card_text_color,
            'card_label_background_color' => $card_label_background_color,
            'card_overlay_opacity' => min(100, max(0, (int) ($data['card_overlay_opacity'] ?? 88))),
            'card_text_position' => $card_position,
            'card_image_shape' => $card_image_shape,
            'content_element' => $this->prepare_content_element($data['content_element'] ?? []),
            'fast_reply_ids' => !empty($data['fast_reply_ids']) && is_array($data['fast_reply_ids']) ? array_slice(array_filter(array_map('absint', $data['fast_reply_ids'])), 0, 5) : [],
        ];
        unset($data['choice_display'], $data['card_image_url'], $data['card_style'], $data['card_text_color'], $data['card_label_background_color'], $data['card_overlay_opacity'], $data['card_text_position'], $data['card_image_shape'], $data['content_element'], $data['fast_reply_ids']);

        return $data;
    }

    private function prepare_content_element($element) {
        if (empty($element['enabled'])) {
            return [];
        }

        $slides = [];
        foreach (($element['slides'] ?? []) as $slide) {
            if (empty($slide['image_url'])) {
                continue;
            }
            $slides[] = [
                'image_url' => esc_url_raw($slide['image_url']),
                'alt' => sanitize_text_field($slide['alt'] ?? ''),
            ];
        }

        if (!$slides) {
            return [];
        }

        return [
            'type' => 'slideshow',
            'title' => sanitize_text_field($element['title'] ?? ''),
            'description' => sanitize_textarea_field($element['description'] ?? ''),
            'features' => array_values(array_filter(array_map('sanitize_text_field', preg_split('/\r\n|\r|\n/', (string) ($element['features'] ?? ''))))),
            'button_text' => sanitize_text_field($element['button_text'] ?? ''),
            'button_url' => esc_url_raw($element['button_url'] ?? ''),
            'slides' => array_slice($slides, 0, 12),
        ];
    }

    private function export_leads_csv() {
        $lead_type = sanitize_key($_POST['lead_type'] ?? '');
        $date_from = $this->sanitize_date_param($_POST['lead_from'] ?? '');
        $date_to = $this->sanitize_date_param($_POST['lead_to'] ?? '');
        $leads = array_values(array_filter($this->repository->list_leads(5000, ['date_from' => $date_from, 'date_to' => $date_to]), function ($lead) use ($lead_type) {
            return !$lead_type || $this->lead_type_for_lead($lead) === $lead_type;
        }));
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=wp-smart-chatbot-' . ($lead_type ?: 'leads') . '-' . gmdate('Y-m-d-His') . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID', 'Name', 'Email', 'Phone', 'Business', 'Message', 'Service', 'Location', 'Status', 'Created']);
        foreach ($leads as $lead) {
            fputcsv($out, [
                $lead['id'],
                $lead['name'],
                $lead['email'],
                $lead['phone'],
                $lead['company'],
                wpsc_format_date_values_in_text($lead['message']),
                $lead['service_interest'],
                $lead['location'],
                $lead['status'],
                wpsc_format_datetime($lead['created_at']),
            ]);
        }
        fclose($out);
        exit;
    }

    private function export_settings() {
        $settings = $this->settings->all();
        unset($settings['openai_api_key']);

        $payload = [
            'plugin' => 'wp-smart-chatbot',
            'version' => WPSC_VERSION,
            'exported_at' => gmdate('c'),
            'settings' => $settings,
            'canned_responses' => [],
        ];

        if (!empty($_POST['include_canned'])) {
            foreach ($this->repository->list_canned_responses(false) as $response) {
                unset($response['id'], $response['created_at'], $response['updated_at']);
                $payload['canned_responses'][] = $response;
            }
        }

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=wp-smart-chatbot-export-' . gmdate('Y-m-d-His') . '.json');
        echo wp_json_encode($payload, JSON_PRETTY_PRINT);
        exit;
    }

    private function import_settings() {
        if (empty($_FILES['import_file']['tmp_name'])) {
            $this->set_admin_notice('No import file was uploaded.', 'error');
            return false;
        }

        $file = $_FILES['import_file'];
        if (!empty($file['size']) && (int) $file['size'] > 2 * 1024 * 1024) {
            $this->set_admin_notice('Import files must be 2 MB or smaller.', 'error');
            return false;
        }

        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], ['json' => 'application/json']);
        if (empty($check['ext'])) {
            $this->set_admin_notice('Please upload a valid JSON export file.', 'error');
            return false;
        }

        $raw = file_get_contents($file['tmp_name']);
        if ($raw === false) {
            $this->set_admin_notice('The import file could not be read.', 'error');
            return false;
        }

        $payload = json_decode($raw, true);
        if (!is_array($payload) || ($payload['plugin'] ?? '') !== 'wp-smart-chatbot') {
            $this->set_admin_notice('This file is not a Q Digital Chatbot export.', 'error');
            return false;
        }

        if (!empty($payload['settings']) && is_array($payload['settings'])) {
            unset($payload['settings']['openai_api_key']);
            $this->settings->update($payload['settings']);
        }

        if (!empty($_POST['import_canned']) && !empty($payload['canned_responses']) && is_array($payload['canned_responses'])) {
            if (!empty($_POST['replace_canned'])) {
                foreach ($this->repository->list_canned_responses(false) as $existing) {
                    $this->repository->delete_canned_response((int) $existing['id']);
                }
            }

            foreach ($payload['canned_responses'] as $response) {
                if (is_array($response)) {
                    $this->repository->save_canned_response($response);
                }
            }
        }

        return true;
    }

    private function ai_generate_canned() {
        $prompt = sanitize_textarea_field(wp_unslash($_POST['ai_prompt'] ?? ''));
        $count = min(10, max(1, (int) ($_POST['ai_count'] ?? 5)));

        if (!$prompt) {
            $this->set_admin_notice('Please enter a prompt for the AI generator.', 'error');
            return false;
        }

        $generated = (new WPSC_AI_Service($this->settings))->generate_canned_responses($prompt, $count);
        if (is_wp_error($generated)) {
            $this->set_admin_notice($generated->get_error_message(), 'error');
            return false;
        }

        $created = 0;
        foreach ($generated as $response) {
            $this->repository->save_canned_response($response);
            $created++;
        }

        $this->set_admin_notice(sprintf('Created %d AI-generated canned responses.', $created), 'success');
        return true;
    }

    private function input($name, $label, $value = '', $type = 'text') {
        echo '<p><label>' . esc_html($label) . '<br><input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" class="regular-text"></label></p>';
    }

    private function textarea($name, $label, $value = '') {
        echo '<p><label>' . esc_html($label) . '<br><textarea name="' . esc_attr($name) . '" rows="5" class="large-text">' . esc_textarea($value) . '</textarea></label></p>';
    }

    private function media_image_input($name, $label, $value = '') {
        echo '<div class="wpsc-media-field">';
        echo '<label>' . esc_html($label) . '</label>';
        echo '<div class="wpsc-logo-preview">';
        if ($value) {
            echo '<img src="' . esc_url($value) . '" alt="">';
        }
        echo '</div>';
        echo '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" class="wpsc-media-url">';
        echo '<p><button type="button" class="button wpsc-media-pick">Choose image</button> <button type="button" class="button wpsc-media-clear">Remove</button></p>';
        echo '</div>';
    }

    private function redirect_with_notice($notice) {
        wp_safe_redirect(add_query_arg('wpsc_notice', $notice, wp_get_referer() ?: admin_url('admin.php?page=wpsc-dashboard')));
        exit;
    }

    private function redirect_to_page($page, $notice) {
        wp_safe_redirect(add_query_arg('wpsc_notice', $notice, admin_url('admin.php?page=' . sanitize_key($page))));
        exit;
    }

    private function notice() {
        $custom = get_transient('wpsc_admin_notice_' . get_current_user_id());
        if (is_array($custom) && !empty($custom['message'])) {
            delete_transient('wpsc_admin_notice_' . get_current_user_id());
            $class = !empty($custom['type']) && $custom['type'] === 'error' ? 'notice-error' : 'notice-success';
            echo '<div class="notice ' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($custom['message']) . '</p></div>';
            return;
        }

        if (empty($_GET['wpsc_notice'])) {
            return;
        }
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(ucwords(str_replace('_', ' ', sanitize_key($_GET['wpsc_notice'])))) . '</p></div>';
    }

    private function set_admin_notice($message, $type = 'success') {
        set_transient('wpsc_admin_notice_' . get_current_user_id(), [
            'message' => sanitize_text_field($message),
            'type' => sanitize_key($type),
        ], 60);
    }
}
