(function () {
  'use strict';

  function showAdminRealtimeError(message) {
    const text = message || 'Q Digital Chatbot could not refresh live updates.';
    let notice = document.querySelector('.wpsc-realtime-error');
    if (!notice) {
      notice = document.createElement('div');
      notice.className = 'notice notice-error wpsc-realtime-error';
      const wrap = document.querySelector('.wrap.wpsc-admin') || document.querySelector('.wrap') || document.body;
      wrap.insertBefore(notice, wrap.firstChild);
    }
    notice.innerHTML = '<p><strong>Q Digital Chatbot live update issue:</strong> ' + escapeHtml(text) + '</p>';
  }

  function clearAdminRealtimeError() {
    const notice = document.querySelector('.wpsc-realtime-error');
    if (notice) {
      notice.remove();
    }
  }

  document.addEventListener('click', function (event) {
    const sourceCard = event.target.closest('[data-kb-source]');
    if (sourceCard) {
      const source = sourceCard.dataset.kbSource;
      document.querySelectorAll('.wpsc-kb-source-card').forEach(function (card) {
        card.classList.toggle('is-active', card.dataset.kbSource === source);
      });
      document.querySelectorAll('.wpsc-kb-source-panel').forEach(function (panel) {
        panel.hidden = panel.dataset.kbPanel !== source;
      });
      const panel = document.querySelector('.wpsc-kb-source-panel[data-kb-panel="' + source + '"]');
      if (panel) {
        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        const first = panel.querySelector('input:not([type="hidden"]), textarea, select');
        if (first) {
          first.focus();
        }
      }
      return;
    }

    const sourceTrigger = event.target.closest('.wpsc-kb-source-trigger[data-kb-source]');
    if (sourceTrigger) {
      const card = document.querySelector('.wpsc-kb-source-card[data-kb-source="' + sourceTrigger.dataset.kbSource + '"]');
      if (card) {
        card.click();
      }
      if (sourceTrigger.dataset.kbSource === 'faq' && sourceTrigger.dataset.gapQuestion) {
        const panel = document.querySelector('.wpsc-kb-source-panel[data-kb-panel="faq"]');
        if (panel) {
          const title = panel.querySelector('input[name="title"]');
          const questions = Array.from(panel.querySelectorAll('input[name="faq_question[]"]'));
          let target = questions.find(function (input) {
            return !input.value.trim();
          });
          if (!target) {
            const addButton = panel.querySelector('.wpsc-add-faq-pair');
            if (addButton) {
              addButton.click();
              target = panel.querySelector('.wpsc-faq-pair:last-child input[name="faq_question[]"]');
            }
          }
          if (title && !title.value.trim()) {
            title.value = 'Knowledge gap answers';
          }
          if (target && !target.value.trim()) {
            target.value = sourceTrigger.dataset.gapQuestion;
            const answer = target.closest('.wpsc-faq-pair').querySelector('textarea[name="faq_answer[]"]');
            if (answer) {
              answer.focus();
            }
          }
        }
      }
      return;
    }

    const addFaqPair = event.target.closest('.wpsc-add-faq-pair');
    if (addFaqPair) {
      const list = document.querySelector('.wpsc-faq-pairs');
      if (!list) {
        return;
      }
      const row = document.createElement('div');
      row.className = 'wpsc-faq-pair';
      row.innerHTML = '<input type="text" name="faq_question[]" placeholder="Question"><textarea name="faq_answer[]" rows="3" placeholder="Answer"></textarea>';
      list.appendChild(row);
      row.querySelector('input').focus();
      return;
    }

    const conversationRow = event.target.closest('.wpsc-clickable-conversation[data-conversation-url]');
    if (conversationRow && !event.target.closest('a, button, input, select, textarea, label')) {
      window.location.href = conversationRow.dataset.conversationUrl;
      return;
    }

    const pickButton = event.target.closest('.wpsc-media-pick');
    const clearButton = event.target.closest('.wpsc-media-clear');

    if (pickButton) {
      const field = pickButton.closest('.wpsc-media-field');
      const input = field.querySelector('.wpsc-media-url');
      const preview = field.querySelector('.wpsc-logo-preview');

      if (!window.wp || !wp.media) {
        return;
      }

      const frame = wp.media({
        title: 'Choose chatbot image',
        button: { text: 'Use this image' },
        library: { type: 'image' },
        multiple: false
      });

      frame.on('select', function () {
        const attachment = frame.state().get('selection').first().toJSON();
        input.value = attachment.url || '';
        preview.innerHTML = attachment.url ? '<img src="' + attachment.url + '" alt="">' : '';
      });

      frame.open();
    }

    if (clearButton) {
      const field = clearButton.closest('.wpsc-media-field');
      field.querySelector('.wpsc-media-url').value = '';
      field.querySelector('.wpsc-logo-preview').innerHTML = '';
    }

    const addOption = event.target.closest('.wpsc-add-canned-option');
    if (addOption) {
      const template = document.getElementById('wpsc-canned-option-template');
      const list = document.querySelector('.wpsc-canned-options');
      if (!template || !list) {
        return;
      }
      const index = Date.now().toString();
      const html = template.innerHTML.replace(/__INDEX__/g, index);
      const wrap = document.createElement('div');
      wrap.innerHTML = html;
      list.appendChild(wrap.firstElementChild);
    }

    const removeOption = event.target.closest('.wpsc-remove-canned-option');
    if (removeOption) {
      const card = removeOption.closest('.wpsc-canned-option-card');
      const list = document.querySelector('.wpsc-canned-options');
      if (card && list && list.querySelectorAll('.wpsc-canned-option-card').length > 1) {
        card.remove();
      } else if (card) {
        card.querySelectorAll('input[type="text"], input[type="hidden"], textarea').forEach(function (field) {
          field.value = '';
        });
        card.querySelector('.wpsc-logo-preview').innerHTML = '';
      }
    }

    const addSlide = event.target.closest('.wpsc-add-slideshow-slide');
    if (addSlide) {
      const template = document.getElementById('wpsc-slideshow-slide-template');
      const list = document.querySelector('.wpsc-slideshow-slides');
      if (!template || !list) {
        return;
      }
      const index = Date.now().toString();
      const wrap = document.createElement('div');
      wrap.innerHTML = template.innerHTML.replace(/__INDEX__/g, index);
      list.appendChild(wrap.firstElementChild);
    }

    const removeSlide = event.target.closest('.wpsc-remove-slideshow-slide');
    if (removeSlide) {
      const card = removeSlide.closest('.wpsc-slideshow-slide');
      const list = document.querySelector('.wpsc-slideshow-slides');
      if (card && list && list.querySelectorAll('.wpsc-slideshow-slide').length > 1) {
        card.remove();
      } else if (card) {
        card.querySelectorAll('input').forEach(function (field) {
          field.value = '';
        });
        card.querySelector('.wpsc-logo-preview').innerHTML = '';
      }
    }

    const addCustomField = event.target.closest('.wpsc-add-custom-form-field');
    if (addCustomField) {
      const template = document.getElementById('wpsc-custom-form-field-template');
      const list = document.querySelector('.wpsc-custom-form-fields');
      if (!template || !list) {
        return;
      }
      const index = Date.now().toString();
      const wrap = document.createElement('div');
      wrap.innerHTML = template.innerHTML.replace(/__INDEX__/g, index);
      list.appendChild(wrap.firstElementChild);
    }

    const removeCustomField = event.target.closest('.wpsc-remove-custom-form-field');
    if (removeCustomField) {
      const card = removeCustomField.closest('.wpsc-custom-field-card');
      const list = document.querySelector('.wpsc-custom-form-fields');
      if (card && list && list.querySelectorAll('.wpsc-custom-field-card').length > 1) {
        card.remove();
      } else if (card) {
        card.querySelectorAll('input[type="text"], textarea').forEach(function (field) {
          field.value = '';
        });
        card.querySelector('input[type="checkbox"]').checked = false;
      }
    }
  });

  document.addEventListener('keydown', function (event) {
    const conversationRow = event.target.closest('.wpsc-clickable-conversation[data-conversation-url]');
    if (!conversationRow || (event.key !== 'Enter' && event.key !== ' ')) {
      return;
    }
    event.preventDefault();
    window.location.href = conversationRow.dataset.conversationUrl;
  });

  document.addEventListener('change', function (event) {
    if (!event.target.classList.contains('wpsc-field-key-select')) {
      return;
    }

    const option = event.target.options[event.target.selectedIndex];
    const recommendedType = option ? option.dataset.type : '';
    const card = event.target.closest('.wpsc-custom-field-card');
    const typeSelect = card ? card.querySelector('select[name$="[type]"]') : null;
    if (typeSelect && recommendedType) {
      typeSelect.value = recommendedType;
    }
  });

  document.addEventListener('input', function (event) {
    if (!event.target.classList.contains('wpsc-range-with-output')) {
      return;
    }
    const output = event.target.parentElement ? event.target.parentElement.querySelector('.wpsc-range-output') : null;
    if (output) {
      output.textContent = event.target.value + '%';
    }
  });

  const canvas = document.getElementById('wpsc-flow-canvas');
  const lines = document.getElementById('wpsc-flow-lines');
  let activeNode = null;
  let offsetX = 0;
  let offsetY = 0;

  function drawFlowLines() {
    if (!canvas || !lines) {
      return;
    }

    lines.innerHTML = '';
    const canvasRect = canvas.getBoundingClientRect();
    canvas.querySelectorAll('.wpsc-flow-node').forEach(function (node) {
      const sourceRect = node.getBoundingClientRect();
      const sourceX = sourceRect.right - canvasRect.left + canvas.scrollLeft;
      const sourceY = sourceRect.top - canvasRect.top + canvas.scrollTop + 38;

      node.querySelectorAll('.wpsc-flow-target').forEach(function (targetSelect, index) {
        const targetId = targetSelect.value;
        if (!targetId || targetId === '0') {
          return;
        }
        const target = canvas.querySelector('.wpsc-flow-node[data-id="' + targetId + '"]');
        if (!target) {
          return;
        }
        const targetRect = target.getBoundingClientRect();
        const targetX = targetRect.left - canvasRect.left + canvas.scrollLeft;
        const targetY = targetRect.top - canvasRect.top + canvas.scrollTop + 40 + index * 18;
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        const midX = sourceX + Math.max(80, (targetX - sourceX) / 2);
        path.setAttribute('d', 'M ' + sourceX + ' ' + sourceY + ' C ' + midX + ' ' + sourceY + ', ' + midX + ' ' + targetY + ', ' + targetX + ' ' + targetY);
        path.setAttribute('class', 'wpsc-flow-line');
        lines.appendChild(path);
      });
    });
  }

  if (canvas) {
    canvas.addEventListener('mousedown', function (event) {
      const node = event.target.closest('.wpsc-flow-node');
      if (!node || event.target.matches('input, textarea, select, a, button')) {
        return;
      }
      activeNode = node;
      const rect = node.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      node.classList.add('is-dragging');
      event.preventDefault();
    });

    document.addEventListener('mousemove', function (event) {
      if (!activeNode) {
        return;
      }
      const rect = canvas.getBoundingClientRect();
      const x = Math.max(0, event.clientX - rect.left + canvas.scrollLeft - offsetX);
      const y = Math.max(0, event.clientY - rect.top + canvas.scrollTop - offsetY);
      activeNode.style.left = x + 'px';
      activeNode.style.top = y + 'px';
      activeNode.querySelector('.wpsc-node-x').value = Math.round(x);
      activeNode.querySelector('.wpsc-node-y').value = Math.round(y);
      drawFlowLines();
    });

    document.addEventListener('mouseup', function () {
      if (activeNode) {
        activeNode.classList.remove('is-dragging');
      }
      activeNode = null;
    });

    canvas.addEventListener('change', function (event) {
      if (event.target.classList.contains('wpsc-flow-target')) {
        drawFlowLines();
      }
    });

    window.addEventListener('resize', drawFlowLines);
    setTimeout(drawFlowLines, 100);
  }

  function adminApi(path, options) {
    const opts = options || {};
    opts.headers = Object.assign({
      'Content-Type': 'application/json',
      'X-WP-Nonce': window.WPSCAdmin ? WPSCAdmin.nonce : ''
    }, opts.headers || {});

    return fetch((WPSCAdmin.restUrl || '').replace(/\/$/, '') + path, opts).then(function (response) {
      return response.json().then(function (json) {
        if (!response.ok) {
          throw new Error(json.message || 'Request failed');
        }
        return json;
      });
    });
  }

  function messageHtml(message) {
    const sender = String(message.sender_type || 'system').replace(/[^a-z0-9_-]/gi, '');
    const id = Number(message.id || 0);
    const div = document.createElement('div');
    div.className = 'wpsc-message wpsc-' + sender;
    if (id) {
      div.dataset.messageId = String(id);
    }

    const strong = document.createElement('strong');
    const metadata = parseMetadata(message.metadata);
    strong.textContent = message.sender_type === 'agent' && metadata.agent_name ? 'agent: ' + metadata.agent_name : (message.sender_type || 'system');
    const small = document.createElement('small');
    small.textContent = message.created_at_formatted || message.created_at || '';

    div.appendChild(strong);
    const attachment = attachmentNode(message, metadata);
    if (attachment) {
      div.appendChild(attachment);
    } else {
      const body = document.createElement('p');
      body.textContent = message.body || '';
      div.appendChild(body);
    }
    if (metadata.action_type === 'ask_contact') {
      const marker = document.createElement('div');
      marker.className = 'wpsc-message-marker';
      marker.textContent = (metadata.form_label || 'Lead capture form') + ' shown to visitor';
      div.appendChild(marker);
    }
    div.appendChild(small);
    return div;
  }

  function isSafeUrl(url) {
    try {
      const parsed = new URL(String(url || ''), window.location.href);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (error) {
      return false;
    }
  }

  function attachmentNode(message, metadata) {
    const url = metadata.file_url || metadata.image_url || hrefFromHtml(message.body || '');
    if (!url || !isSafeUrl(url)) {
      return null;
    }

    const fileName = metadata.file_name || filenameFromUrl(url) || 'Attachment';
    const type = metadata.attachment_type || message.message_type || '';
    const isImage = type === 'image' || /\.(jpe?g|png)$/i.test(fileName) || /\.(jpe?g|png)(\?|#|$)/i.test(url);
    const wrap = document.createElement('div');
    wrap.className = 'wpsc-message-attachment ' + (isImage ? 'wpsc-message-attachment-image' : 'wpsc-message-attachment-file');
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';

    if (isImage) {
      const image = document.createElement('img');
      image.src = url;
      image.alt = fileName || 'Image attachment';
      link.appendChild(image);
    } else {
      const badge = document.createElement('span');
      badge.className = 'wpsc-file-badge';
      badge.textContent = 'PDF';
      const text = document.createElement('span');
      text.textContent = fileName || 'PDF attachment';
      link.appendChild(badge);
      link.appendChild(text);
    }

    wrap.appendChild(link);
    return wrap;
  }

  function hrefFromHtml(html) {
    const match = String(html || '').match(/href=["']([^"']+)["']/i);
    return match ? match[1] : '';
  }

  function filenameFromUrl(url) {
    try {
      const path = new URL(url, window.location.href).pathname;
      return decodeURIComponent(path.split('/').pop() || '');
    } catch (error) {
      return '';
    }
  }

  function parseMetadata(value) {
    if (!value) {
      return {};
    }
    if (typeof value === 'object') {
      return value;
    }
    try {
      return JSON.parse(value);
    } catch (error) {
      return {};
    }
  }

  function appendAdminMessages(transcript, messages) {
    if (!transcript || !messages || !messages.length) {
      return;
    }

    let lastId = Number(transcript.dataset.lastMessageId || 0);
    messages.forEach(function (message) {
      const id = Number(message.id || 0);
      if (id && transcript.querySelector('[data-message-id="' + id + '"]')) {
        lastId = Math.max(lastId, id);
        return;
      }
      transcript.appendChild(messageHtml(message));
      lastId = Math.max(lastId, id);
    });
    transcript.dataset.lastMessageId = String(lastId);
    transcript.scrollTop = transcript.scrollHeight;
  }

  function leadTypeLabel(lead) {
    const service = String((lead && lead.service_interest) || '').toLowerCase();
    if (service.indexOf('order') !== -1) {
      return 'Orders';
    }
    if (service.indexOf('service') !== -1) {
      return 'Services';
    }
    if (service.indexOf('booking') !== -1) {
      return 'Bookings';
    }
    if (service.indexOf('finance') !== -1) {
      return 'Finance Enquiries';
    }
    if (service.indexOf('support') !== -1) {
      return 'Support Tickets';
    }
    return lead && lead.service_interest ? lead.service_interest : 'General Leads';
  }

  function parseLeadDetails(message) {
    const rows = [];
    String(message || '').split(/\r\n|\r|\n/).forEach(function (line) {
      const trimmed = line.trim();
      if (!trimmed) {
        return;
      }
      const index = trimmed.indexOf(':');
      if (index > 0) {
        rows.push([trimmed.slice(0, index).trim(), trimmed.slice(index + 1).trim()]);
      } else {
        rows.push(['Message', trimmed]);
      }
    });
    return rows;
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function (char) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[char];
    });
  }

  function getLeadTypeKey(lead) {
    const service = String((lead && lead.service_interest) || '').toLowerCase().trim();
    if (service.indexOf('order') !== -1) return 'order';
    if (service.indexOf('service') !== -1) return 'service';
    if (service.indexOf('booking') !== -1) return 'booking';
    if (service.indexOf('finance') !== -1) return 'finance';
    if (service.indexOf('support') !== -1) return 'support';
    if (service.indexOf('accommodation') !== -1) return 'accommodation';
    if (service) return 'custom';
    return 'lead';
  }

  function renderLeadSummary(lead) {
    const wrap = document.querySelector('.wpsc-conversation-lead-summary');
    if (!wrap) {
      return;
    }
    if (!lead) {
      wrap.innerHTML = '';
      wrap.style.display = 'none';
      return;
    }
    wrap.style.display = '';

    // Extract initials
    const name = lead.name || '';
    const parts = name.trim().split(/\s+/);
    let initials = '';
    if (parts.length > 0 && parts[0]) {
      initials += parts[0][0].toUpperCase();
      if (parts.length > 1 && parts[parts.length - 1]) {
        initials += parts[parts.length - 1][0].toUpperCase();
      }
    }
    initials = initials || 'U';

    const title = leadTypeLabel(lead);
    const typeKey = getLeadTypeKey(lead);
    const detailRows = parseLeadDetails(lead.message_formatted || lead.message);

    let html = '<section class="wpsc-lead-summary">';
    html += '<div class="wpsc-lead-contact-profile">';
    html += '<div class="wpsc-lead-avatar">' + escapeHtml(initials) + '</div>';
    html += '<div class="wpsc-lead-main-info">';
    html += '<div class="wpsc-lead-name-row">';
    html += '<span class="wpsc-lead-name">' + escapeHtml(lead.name || '') + '</span>';
    html += '<span class="wpsc-lead-badge-status wpsc-badge-' + escapeHtml(typeKey) + '">' + escapeHtml(title) + ' (' + escapeHtml(lead.status || '') + ')</span>';
    html += '</div>';

    html += '<div class="wpsc-lead-meta-row">';
    if (lead.email) {
      html += '<span class="wpsc-lead-meta-item wpsc-meta-email" title="Email"><span class="dashicons dashicons-email"></span> ' + escapeHtml(lead.email) + '</span>';
    }
    if (lead.phone) {
      html += '<span class="wpsc-lead-meta-item wpsc-meta-phone" title="Phone"><span class="dashicons dashicons-phone"></span> ' + escapeHtml(lead.phone) + '</span>';
    }
    if (lead.company) {
      html += '<span class="wpsc-lead-meta-item wpsc-meta-company" title="Business"><span class="dashicons dashicons-store"></span> ' + escapeHtml(lead.company) + '</span>';
    }
    html += '<span class="wpsc-lead-meta-item wpsc-meta-captured" title="Captured At"><span class="dashicons dashicons-clock"></span> ' + escapeHtml(lead.created_at_formatted || lead.created_at || '') + '</span>';
    html += '</div>';
    html += '</div>';
    html += '</div>';

    // Extra details
    if (detailRows.length || lead.service_interest) {
      html += '<div class="wpsc-lead-extra-details">';
      if (lead.service_interest) {
        html += '<div class="wpsc-lead-extra-item"><strong>Type:</strong> ' + escapeHtml(lead.service_interest) + '</div>';
      }
      detailRows.forEach(function (row) {
        if (row[1] && String(row[1]).trim() !== '') {
          html += '<div class="wpsc-lead-extra-item"><strong>' + escapeHtml(row[0]) + ':</strong> ' + escapeHtml(row[1]) + '</div>';
        }
      });
      html += '</div>';
    }

    html += '</section>';
    wrap.innerHTML = html;
  }

  function updatePendingBadges(count) {
    count = Number(count || 0);
    const title = count ? 'Q Digital Chatbot: ' + count + ' waiting for reply' : 'Q Digital Chatbot';
    const adminBarItem = document.querySelector('#wp-admin-bar-wpsc-pending-replies');
    if (adminBarItem) {
      const link = adminBarItem.querySelector('.ab-item');
      if (link) {
        link.textContent = title;
        if (WPSCAdmin.conversationsUrl) {
          link.href = WPSCAdmin.conversationsUrl;
        }
      }
      adminBarItem.classList.toggle('wpsc-admin-bar-alert', count > 0);
    }

    document.querySelectorAll('#adminmenu a[href*="page=wpsc-dashboard"], #adminmenu a[href*="page=wpsc-conversations"]').forEach(function (link) {
      let badge = link.querySelector('.awaiting-mod');
      if (count > 0 && !badge) {
        badge = document.createElement('span');
        badge.className = 'awaiting-mod';
        link.appendChild(document.createTextNode(' '));
        link.appendChild(badge);
      }
      if (badge) {
        badge.textContent = String(count);
        badge.style.display = count > 0 ? '' : 'none';
      }
    });
  }

  function pollPendingNotifications() {
    if (!window.WPSCAdmin || !WPSCAdmin.restUrl) {
      return;
    }

    adminApi('/admin/notifications/pending', { method: 'GET' }).then(function (data) {
      clearAdminRealtimeError();
      updatePendingBadges(data.pending_count || 0);
    }).catch(function (error) {
      showAdminRealtimeError(error.message || 'Pending-reply badges could not refresh.');
    });
  }

  function initAdminConversationRealtime() {
    const transcript = document.querySelector('.wpsc-transcript[data-conversation-id]');
    if (!transcript || !window.WPSCAdmin || !WPSCAdmin.restUrl) {
      return;
    }

    const conversationId = transcript.dataset.conversationId;
    transcript.scrollTop = transcript.scrollHeight;

    function pollConversation() {
      const after = Number(transcript.dataset.lastMessageId || 0);
      adminApi('/admin/conversations/' + encodeURIComponent(conversationId) + '?after=' + encodeURIComponent(after), {
        method: 'GET'
      }).then(function (data) {
        clearAdminRealtimeError();
        appendAdminMessages(transcript, data.messages || []);
        if (data.conversation && data.conversation.status) {
          const status = document.querySelector('.wpsc-conversation-status');
          if (status) {
            status.textContent = data.conversation.status;
          }
        }
        renderLeadSummary(data.lead || null);
        updatePendingBadges(data.pending_count || 0);
      }).catch(function (error) {
        showAdminRealtimeError(error.message || 'Conversation messages could not refresh.');
      });
    }

    const replyForm = document.querySelector('.wpsc-reply-form[data-conversation-id="' + conversationId + '"]');
    if (replyForm) {
      const replyTextarea = replyForm.querySelector('textarea[name="message"]');
      const replyAgentName = replyForm.querySelector('input[name="agent_name"]');
      let typingHeartbeat = null;

      function sendTypingHeartbeat(active) {
        adminApi('/admin/conversations/' + encodeURIComponent(conversationId) + '/typing', {
          method: 'POST',
          body: JSON.stringify({
            active: !!active,
            agent_name: replyAgentName ? replyAgentName.value.trim() : ''
          })
        }).catch(function () {
          // Typing presence is best-effort; message sending remains unaffected.
        });
      }

      function stopTypingHeartbeat(notifyVisitor) {
        if (typingHeartbeat) {
          window.clearInterval(typingHeartbeat);
          typingHeartbeat = null;
        }
        if (notifyVisitor) {
          sendTypingHeartbeat(false);
        }
      }

      function startTypingHeartbeat() {
        if (!replyTextarea || !replyTextarea.value.trim()) {
          stopTypingHeartbeat(true);
          return;
        }
        if (!typingHeartbeat) {
          sendTypingHeartbeat(true);
          typingHeartbeat = window.setInterval(function () {
            sendTypingHeartbeat(true);
          }, 3000);
        }
      }

      if (replyTextarea) {
        replyTextarea.addEventListener('input', startTypingHeartbeat);
      }
      if (replyAgentName) {
        replyAgentName.addEventListener('input', function () {
          if (replyTextarea && replyTextarea.value.trim()) {
            sendTypingHeartbeat(true);
          }
        });
      }

      replyForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const textarea = replyTextarea;
        const agentNameInput = replyAgentName;
        const message = textarea ? textarea.value.trim() : '';
        if (!message) {
          return;
        }
        stopTypingHeartbeat(true);

        adminApi('/admin/conversations/' + encodeURIComponent(conversationId) + '/reply', {
          method: 'POST',
          body: JSON.stringify({ message: message, agent_name: agentNameInput ? agentNameInput.value.trim() : '' })
        }).then(function (created) {
          if (textarea) {
            textarea.value = '';
          }
          appendAdminMessages(transcript, [created]);
          pollPendingNotifications();
        }).catch(function (error) {
          window.alert(error.message || 'Reply failed');
        });
      });
    }

    const leadForm = document.querySelector('.wpsc-lead-request-form[data-conversation-id="' + conversationId + '"]');
    if (leadForm) {
      leadForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const submit = event.submitter || leadForm.querySelector('input[type="submit"], button[type="submit"]');
        const formType = submit && submit.dataset.formType ? submit.dataset.formType : (leadForm.querySelector('input[name="form_type"]') || {}).value || 'lead';
        const originalLabel = submit ? (submit.value || submit.textContent || '') : '';
        if (submit) {
          submit.disabled = true;
          submit.dataset.originalValue = originalLabel;
          if ('value' in submit) {
            submit.value = 'Sending...';
          } else {
            submit.textContent = 'Sending...';
          }
        }
        adminApi('/admin/conversations/' + encodeURIComponent(conversationId) + '/form-request', {
          method: 'POST',
          body: JSON.stringify({ form_type: formType })
        }).then(function (created) {
          appendAdminMessages(transcript, [created]);
          if (submit) {
            if ('value' in submit) {
              submit.value = 'Form sent';
            } else {
              submit.textContent = 'Form sent';
            }
            window.setTimeout(function () {
              submit.disabled = false;
              if ('value' in submit) {
                submit.value = submit.dataset.originalValue || 'Send lead capture form';
              } else {
                submit.textContent = submit.dataset.originalValue || 'Send lead capture form';
              }
            }, 1800);
          }
        }).catch(function (error) {
          if (submit) {
            submit.disabled = false;
            if ('value' in submit) {
              submit.value = submit.dataset.originalValue || 'Send lead capture form';
            } else {
              submit.textContent = submit.dataset.originalValue || 'Send lead capture form';
            }
          }
          window.alert(error.message || 'Could not send the lead capture form');
        });
      });
    }

    window.setInterval(pollConversation, Number(WPSCAdmin.conversationPollMs || 3000));
  }

  if (window.WPSCAdmin && WPSCAdmin.restUrl) {
    initAdminConversationRealtime();
    pollPendingNotifications();
    window.setInterval(pollPendingNotifications, Number(WPSCAdmin.notificationPollMs || 5000));
  }
})();
