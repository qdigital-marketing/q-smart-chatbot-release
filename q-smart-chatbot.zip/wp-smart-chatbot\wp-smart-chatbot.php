<?php
/**
 * Plugin Name: Q Digital Smart Chatbot
 * Description: AI chatbot, live chat, canned replies, knowledgebase, lead capture and notifications for WordPress.
 * Version: 1.0.1
 * Author: Q Digital Marketing
 * Author URI: https://qdigital.com.au/
 * Text Domain: wp-smart-chatbot
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WPSC_VERSION', '1.0.1');
define('WPSC_TESTED_UP_TO', '7.0.1');
define('WPSC_SLUG', 'q-smart-chatbot');
define('WPSC_PACKAGE_NAME', WPSC_SLUG . '.zip');
define('WPSC_PLUGIN_FILE', __FILE__);
define('WPSC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPSC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPSC_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WPSC_REST_NAMESPACE', 'wpsc/v1');
define('WPSC_GITHUB_REPO', 'qdigital-marketing/q-smart-chatbot-release');
define('WPSC_RELEASE_API', 'https://api.github.com/repos/' . WPSC_GITHUB_REPO . '/releases/latest');

require_once WPSC_PLUGIN_DIR . 'includes/helpers.php';
require_once WPSC_PLUGIN_DIR . 'includes/class-loader.php';

WPSC_Loader::register();

register_activation_hook(__FILE__, ['WPSC_Activator', 'activate']);
register_deactivation_hook(__FILE__, ['WPSC_Deactivator', 'deactivate']);

function wpsc_run_plugin() {
    $plugin = new WPSC_Plugin();
    $plugin->run();
}

wpsc_run_plugin();
