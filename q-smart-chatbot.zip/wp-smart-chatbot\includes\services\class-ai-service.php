<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_AI_Service {
    private $settings;
    private $client;

    public function __construct(WPSC_Settings_Service $settings) {
        $this->settings = $settings;
        $this->client = new WPSC_OpenAI_Client($settings->get_openai_api_key());
    }

    public function answer($message, $conversation = null) {
        if ($this->settings->get('ai_enabled') !== '1' || !$this->client->has_key()) {
            return new WP_Error('wpsc_ai_disabled', __('AI is not enabled.', 'wp-smart-chatbot'));
        }

        $input = [
            [
                'role' => 'system',
                'content' => trim($this->settings->get('custom_instructions') . "\n\n" . $this->runtime_guard_instructions()),
            ],
            [
                'role' => 'user',
                'content' => sanitize_textarea_field($message),
            ],
        ];

        $payload = [
            'model' => $this->settings->get('openai_model', 'gpt-4.1-mini'),
            'input' => $input,
            'temperature' => (float) $this->settings->get('openai_temperature', '0.3'),
            'max_output_tokens' => min(360, max(120, (int) $this->settings->get('openai_max_tokens', '280'))),
            'store' => false,
        ];

        $vector_store_id = $this->settings->get('openai_vector_store_id', '');
        if ($vector_store_id) {
            $payload['tools'] = [[
                'type' => 'file_search',
                'vector_store_ids' => [$vector_store_id],
            ]];
        }

        $result = $this->client->response($payload);
        if (is_wp_error($result)) {
            return $result;
        }

        return [
            'body' => $this->clean_answer_text($this->extract_text($result)),
            'model' => $payload['model'],
            'usage' => isset($result['usage']) ? $result['usage'] : [],
            'raw' => $result,
        ];
    }

    public function index_document($path, $filename) {
        $file = $this->client->upload_file($path, $filename);
        if (is_wp_error($file)) {
            return $file;
        }

        $vector_store_id = $this->settings->get('openai_vector_store_id', '');
        if (!$vector_store_id) {
            $store = $this->client->create_vector_store(get_bloginfo('name') . ' Knowledgebase');
            if (is_wp_error($store)) {
                return $store;
            }
            $vector_store_id = $store['id'] ?? '';
            if ($vector_store_id) {
                $this->settings->update(['openai_vector_store_id' => $vector_store_id]);
            }
        }

        $status = 'uploaded';

        if ($vector_store_id && !empty($file['id'])) {
            $attached = $this->client->attach_file_to_vector_store($vector_store_id, $file['id']);
            if (is_wp_error($attached)) {
                return $attached;
            }
            $openai_status = sanitize_key($attached['status'] ?? '');
            if ($openai_status === 'completed') {
                $status = 'indexed';
            } elseif ($openai_status === 'failed') {
                return new WP_Error('wpsc_openai_indexing_failed', __('OpenAI could not index this file.', 'wp-smart-chatbot'), ['openai_file_id' => $file['id'] ?? '', 'vector_store_id' => $vector_store_id]);
            } else {
                $status = 'processing';
            }
        }

        return [
            'openai_file_id' => $file['id'] ?? '',
            'vector_store_id' => $vector_store_id,
            'status' => $status,
        ];
    }

    public function generate_canned_responses($prompt, $count = 5) {
        if (!$this->client->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        $count = min(10, max(1, (int) $count));
        $instruction = 'Create canned chatbot responses for a WordPress service-business chatbot. Return only valid JSON. The JSON must be an array of objects. Each object must contain title, trigger_label, response_text, action_type, sort_order, and is_active. action_type must be one of send_message, open_url, ask_contact, ask_lead, ask_order, ask_service, ask_booking, ask_accommodation, ask_finance, ask_support, handover, start_ai. Keep response_text helpful, concise, and safe. Do not include markdown.';

        $payload = [
            'model' => $this->settings->get('openai_model', 'gpt-4.1-mini'),
            'input' => [
                [
                    'role' => 'system',
                    'content' => $instruction,
                ],
                [
                    'role' => 'user',
                    'content' => 'Create ' . $count . " canned responses from this brief:\n" . sanitize_textarea_field($prompt),
                ],
            ],
            'temperature' => 0.4,
            'max_output_tokens' => max(700, $count * 220),
            'store' => false,
        ];

        $result = $this->client->response($payload);
        if (is_wp_error($result)) {
            return $result;
        }

        $text = trim($this->extract_text($result));
        $text = preg_replace('/^```(?:json)?\s*/i', '', $text);
        $text = preg_replace('/\s*```$/', '', $text);
        $decoded = json_decode($text, true);

        if (!is_array($decoded)) {
            return new WP_Error('wpsc_ai_invalid_json', __('The AI response could not be parsed. Try a more specific prompt.', 'wp-smart-chatbot'));
        }

        $responses = [];
        foreach ($decoded as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $action = sanitize_key($item['action_type'] ?? 'send_message');
            if (!in_array($action, ['send_message', 'open_url', 'ask_contact', 'ask_lead', 'ask_order', 'ask_service', 'ask_booking', 'ask_accommodation', 'ask_finance', 'ask_support', 'handover', 'start_ai'], true)) {
                $action = 'send_message';
            }

            $title = sanitize_text_field($item['title'] ?? '');
            $trigger = sanitize_text_field($item['trigger_label'] ?? '');
            $body = sanitize_textarea_field($item['response_text'] ?? '');

            if (!$title || !$trigger || !$body) {
                continue;
            }

            $responses[] = [
                'title' => $title,
                'trigger_label' => $trigger,
                'response_text' => $body,
                'action_type' => $action,
                'action_payload' => isset($item['action_payload']) && is_array($item['action_payload']) ? $item['action_payload'] : [],
                'sort_order' => isset($item['sort_order']) ? (int) $item['sort_order'] : $index + 1,
                'is_active' => empty($item['is_active']) ? 0 : 1,
            ];
        }

        if (!$responses) {
            return new WP_Error('wpsc_ai_no_responses', __('The AI did not return any usable canned responses.', 'wp-smart-chatbot'));
        }

        return array_slice($responses, 0, $count);
    }

    public function vector_file_status($vector_store_id, $file_id) {
        if (!$vector_store_id || !$file_id) {
            return new WP_Error('wpsc_openai_missing_ids', __('Vector store and file IDs are required.', 'wp-smart-chatbot'));
        }

        $result = $this->client->get_vector_store_file($vector_store_id, $file_id);
        if (is_wp_error($result)) {
            return $result;
        }

        $status = sanitize_key($result['status'] ?? '');
        if ($status === 'completed') {
            return 'indexed';
        }

        if ($status === 'failed') {
            return 'failed';
        }

        return 'processing';
    }

    public function test_retrieval($query, $max_results = 5) {
        if (!$this->client->has_key()) {
            return new WP_Error('wpsc_openai_missing_key', __('OpenAI API key is not configured.', 'wp-smart-chatbot'));
        }

        $vector_store_id = $this->settings->get('openai_vector_store_id', '');
        if (!$vector_store_id) {
            return new WP_Error('wpsc_openai_missing_vector_store', __('Upload and index at least one document before testing retrieval.', 'wp-smart-chatbot'));
        }

        $query = sanitize_text_field($query);
        if ($query === '') {
            return new WP_Error('wpsc_retrieval_query_required', __('Enter a question to test retrieval.', 'wp-smart-chatbot'));
        }

        return $this->client->search_vector_store($vector_store_id, $query, $max_results);
    }

    private function runtime_guard_instructions() {
        return 'Critical chat style rules: keep the visitor-facing answer concise and complete. Prefer 1-3 short paragraphs or up to 4 bullets. Do not include citations, source markers, bracketed references, uploaded document names, file names, vector store references, or phrases like "according to the uploaded document". If the answer would be long, summarize and offer to connect the visitor with the team.';
    }

    private function extract_text($result) {
        if (!empty($result['output_text'])) {
            return $result['output_text'];
        }

        if (!empty($result['output']) && is_array($result['output'])) {
            $parts = [];
            foreach ($result['output'] as $item) {
                if (empty($item['content']) || !is_array($item['content'])) {
                    continue;
                }
                foreach ($item['content'] as $content) {
                    if (isset($content['text'])) {
                        $parts[] = $content['text'];
                    }
                }
            }
            if ($parts) {
                return implode("\n", $parts);
            }
        }

        return $this->settings->get('fallback_message');
    }

    private function clean_answer_text($text) {
        $text = wp_strip_all_tags((string) $text);
        $text = preg_replace('/【[^】]*】/u', '', $text);
        $text = preg_replace('/\[\s*\d+\s*(?::|：)[^\]\r\n]{0,160}\]/u', '', $text);
        $text = preg_replace('/\[\s*\d+\s*\]/u', '', $text);
        $text = preg_replace('/\(\s*(?:source|citation|file|document)[^)]+\)/iu', '', $text);
        $text = preg_replace('/\b(?:according to|based on|from|in)\s+(?:the\s+)?(?:uploaded\s+)?(?:document|file|knowledgebase|knowledge base)[^.!?\r\n]*[.!?]?/iu', '', $text);
        $text = preg_replace('/(?:^|\n)\s*(?:sources?|citations?|references?)\s*:\s*.*$/imu', '', $text);
        $text = preg_replace('/[ \t]+\n/', "\n", $text);
        $text = preg_replace("/\n{3,}/", "\n\n", $text);
        $text = trim($text);

        if ($text === '') {
            return $this->settings->get('fallback_message');
        }

        return $this->soft_limit_answer($text);
    }

    private function soft_limit_answer($text) {
        $limit = 760;
        if (strlen($text) <= $limit) {
            return $text;
        }

        $snippet = substr($text, 0, $limit);
        $last_sentence = max(strrpos($snippet, '. '), strrpos($snippet, '! '), strrpos($snippet, '? '));
        if ($last_sentence && $last_sentence > 280) {
            return trim(substr($snippet, 0, $last_sentence + 1));
        }

        $last_space = strrpos($snippet, ' ');
        return trim(substr($snippet, 0, $last_space ?: $limit)) . '.';
    }
}
