<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Repository {
    public function get_or_create_conversation($session_id, $visitor_uuid, $current_url = '', $referrer = '') {
        global $wpdb;

        $table = wpsc_table('conversations');
        $conversation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE session_id = %s AND visitor_uuid = %s ORDER BY id DESC LIMIT 1",
            $session_id,
            $visitor_uuid
        ), ARRAY_A);

        $now = wpsc_now();

        if ($conversation) {
            $wpdb->update($table, [
                'current_url' => esc_url_raw($current_url),
                'updated_at' => $now,
            ], ['id' => (int) $conversation['id']]);
            return $this->get_conversation((int) $conversation['id']);
        }

        $wpdb->insert($table, [
            'session_id' => sanitize_text_field($session_id),
            'visitor_uuid' => sanitize_text_field($visitor_uuid),
            'status' => 'bot',
            'source_url' => esc_url_raw($current_url),
            'current_url' => esc_url_raw($current_url),
            'referrer' => esc_url_raw($referrer),
            'user_ip_hash' => wpsc_client_ip_hash(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_textarea_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            'last_message_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $this->get_conversation((int) $wpdb->insert_id);
    }

    public function get_conversation($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . wpsc_table('conversations') . " WHERE id = %d", $id), ARRAY_A);
    }

    public function get_conversation_for_visitor($id, $session_id, $visitor_uuid) {
        global $wpdb;

        if (!$id || !$session_id || !$visitor_uuid) {
            return null;
        }

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . wpsc_table('conversations') . " WHERE id = %d AND session_id = %s AND visitor_uuid = %s LIMIT 1",
            (int) $id,
            sanitize_text_field($session_id),
            sanitize_text_field($visitor_uuid)
        ), ARRAY_A);
    }

    public function list_conversations($args = []) {
        global $wpdb;
        $limit = isset($args['limit']) ? min(100, max(1, (int) $args['limit'])) : 50;
        $status = isset($args['status']) ? sanitize_text_field($args['status']) : '';
        $statuses = isset($args['statuses']) && is_array($args['statuses']) ? array_values(array_filter(array_map('sanitize_text_field', $args['statuses']))) : [];
        $table = wpsc_table('conversations');

        if ($statuses) {
            $placeholders = implode(',', array_fill(0, count($statuses), '%s'));
            $params = array_merge($statuses, [$limit]);
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE status IN ($placeholders) ORDER BY last_message_at DESC LIMIT %d", $params), ARRAY_A);
        }

        if ($status) {
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE status = %s ORDER BY last_message_at DESC LIMIT %d", $status, $limit), ARRAY_A);
        }

        return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table ORDER BY last_message_at DESC LIMIT %d", $limit), ARRAY_A);
    }

    public function update_conversation($id, $data) {
        global $wpdb;
        $allowed = ['lead_id', 'assigned_agent_id', 'status', 'current_url', 'priority', 'last_message_at'];
        $clean = [];

        foreach ($allowed as $key) {
            if (array_key_exists($key, $data)) {
                $clean[$key] = is_string($data[$key]) ? sanitize_text_field($data[$key]) : $data[$key];
            }
        }

        $clean['updated_at'] = wpsc_now();
        return $wpdb->update(wpsc_table('conversations'), $clean, ['id' => (int) $id]);
    }

    public function delete_conversation($id) {
        global $wpdb;
        $id = (int) $id;
        foreach ($this->list_messages($id, 0) as $message) {
            $metadata = wpsc_json_decode($message['metadata'] ?? '{}');
            if (!empty($metadata['local_path'])) {
                wpsc_delete_local_upload_file($metadata['local_path']);
            }
        }
        $wpdb->delete(wpsc_table('messages'), ['conversation_id' => $id]);
        $wpdb->delete(wpsc_table('events'), ['conversation_id' => $id]);
        return $wpdb->delete(wpsc_table('conversations'), ['id' => $id]);
    }

    public function add_message($conversation_id, $sender_type, $body, $args = []) {
        global $wpdb;

        $wpdb->insert(wpsc_table('messages'), [
            'conversation_id' => (int) $conversation_id,
            'sender_type' => sanitize_key($sender_type),
            'sender_id' => isset($args['sender_id']) ? (int) $args['sender_id'] : null,
            'message_type' => isset($args['message_type']) ? sanitize_key($args['message_type']) : 'text',
            'body' => wp_kses_post($body),
            'metadata' => isset($args['metadata']) ? wpsc_json_encode($args['metadata']) : '{}',
            'ai_model' => isset($args['ai_model']) ? sanitize_text_field($args['ai_model']) : null,
            'ai_tokens_input' => isset($args['ai_tokens_input']) ? (int) $args['ai_tokens_input'] : 0,
            'ai_tokens_output' => isset($args['ai_tokens_output']) ? (int) $args['ai_tokens_output'] : 0,
            'confidence_score' => isset($args['confidence_score']) ? (float) $args['confidence_score'] : null,
            'is_private_note' => !empty($args['is_private_note']) ? 1 : 0,
            'created_at' => wpsc_now(),
        ]);

        $id = (int) $wpdb->insert_id;
        $this->update_conversation($conversation_id, ['last_message_at' => wpsc_now()]);
        return $this->get_message($id);
    }

    public function get_message($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . wpsc_table('messages') . " WHERE id = %d", $id), ARRAY_A);
    }

    public function list_messages($conversation_id, $after = 0) {
        global $wpdb;
        $table = wpsc_table('messages');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE conversation_id = %d AND id > %d ORDER BY id ASC LIMIT 100",
            (int) $conversation_id,
            (int) $after
        ), ARRAY_A);
    }

    public function create_lead($data) {
        global $wpdb;
        $now = wpsc_now();

        $wpdb->insert(wpsc_table('leads'), [
            'name' => sanitize_text_field($data['name'] ?? ''),
            'email' => sanitize_email($data['email'] ?? ''),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'company' => sanitize_text_field($data['company'] ?? ''),
            'message' => sanitize_textarea_field($data['message'] ?? ''),
            'service_interest' => sanitize_text_field($data['service_interest'] ?? ''),
            'location' => sanitize_text_field($data['location'] ?? ''),
            'preferred_contact_method' => sanitize_text_field($data['preferred_contact_method'] ?? ''),
            'consent' => !empty($data['consent']) ? 1 : 0,
            'conversation_id' => isset($data['conversation_id']) ? (int) $data['conversation_id'] : null,
            'status' => 'new',
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $lead = $this->get_lead((int) $wpdb->insert_id);
        if (!empty($lead['conversation_id'])) {
            $this->update_conversation((int) $lead['conversation_id'], ['lead_id' => (int) $lead['id']]);
        }
        return $lead;
    }

    public function get_lead($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . wpsc_table('leads') . " WHERE id = %d", $id), ARRAY_A);
    }

    public function list_leads($limit = 50, $args = []) {
        global $wpdb;
        $where = [];
        $params = [];
        if (!empty($args['status'])) {
            $where[] = 'status = %s';
            $params[] = sanitize_key($args['status']);
        }
        if (!empty($args['date_from'])) {
            $where[] = 'created_at >= %s';
            $params[] = sanitize_text_field($args['date_from']) . ' 00:00:00';
        }
        if (!empty($args['date_to'])) {
            $where[] = 'created_at <= %s';
            $params[] = sanitize_text_field($args['date_to']) . ' 23:59:59';
        }
        $sql = "SELECT * FROM " . wpsc_table('leads');
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC LIMIT %d';
        $params[] = min(5000, max(1, (int) $limit));
        return $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    }

    public function update_lead($id, $data) {
        global $wpdb;
        $clean = [];
        foreach (['status', 'assigned_to', 'lead_score', 'company'] as $key) {
            if (array_key_exists($key, $data)) {
                $clean[$key] = is_string($data[$key]) ? sanitize_text_field($data[$key]) : (int) $data[$key];
            }
        }
        $clean['updated_at'] = wpsc_now();
        $wpdb->update(wpsc_table('leads'), $clean, ['id' => (int) $id]);
        return $this->get_lead((int) $id);
    }

    public function delete_lead($id) {
        global $wpdb;
        return $wpdb->delete(wpsc_table('leads'), ['id' => (int) $id]);
    }

    public function count_canned_responses() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('canned_responses'));
    }

    public function list_canned_responses($active_only = false) {
        global $wpdb;
        $table = wpsc_table('canned_responses');
        if ($active_only) {
            return $wpdb->get_results("SELECT * FROM $table WHERE is_active = 1 ORDER BY sort_order ASC, title ASC", ARRAY_A);
        }
        return $wpdb->get_results("SELECT * FROM $table ORDER BY sort_order ASC, title ASC", ARRAY_A);
    }

    public function get_canned_response($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . wpsc_table('canned_responses') . " WHERE id = %d", $id), ARRAY_A);
    }

    public function find_canned_response_by_label($label) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . wpsc_table('canned_responses') . " WHERE is_active = 1 AND trigger_label = %s LIMIT 1",
            sanitize_text_field($label)
        ), ARRAY_A);
    }

    public function save_canned_response($data, $id = 0) {
        global $wpdb;
        $now = wpsc_now();
        $payload = $data['action_payload'] ?? [];
        if (is_string($payload)) {
            $decoded = json_decode($payload, true);
            $payload = is_array($decoded) ? $decoded : [];
        }

        $row = [
            'title' => sanitize_text_field($data['title'] ?? ''),
            'trigger_label' => sanitize_text_field($data['trigger_label'] ?? ''),
            'response_text' => sanitize_textarea_field($data['response_text'] ?? ''),
            'action_type' => sanitize_key($data['action_type'] ?? 'send_message'),
            'action_payload' => wpsc_json_encode($payload),
            'sort_order' => isset($data['sort_order']) ? (int) $data['sort_order'] : 0,
            'is_active' => empty($data['is_active']) ? 0 : 1,
            'updated_at' => $now,
        ];

        if ($id) {
            $wpdb->update(wpsc_table('canned_responses'), $row, ['id' => (int) $id]);
            return $this->get_canned_response((int) $id);
        }

        $row['created_at'] = $now;
        $wpdb->insert(wpsc_table('canned_responses'), $row);
        return $this->get_canned_response((int) $wpdb->insert_id);
    }

    public function delete_canned_response($id) {
        global $wpdb;
        return $wpdb->delete(wpsc_table('canned_responses'), ['id' => (int) $id]);
    }

    public function add_document($data) {
        global $wpdb;
        $now = wpsc_now();
        $wpdb->insert(wpsc_table('documents'), [
            'title' => sanitize_text_field($data['title'] ?? ''),
            'file_name' => sanitize_file_name($data['file_name'] ?? ''),
            'file_path' => isset($data['file_path']) ? esc_url_raw($data['file_path']) : '',
            'file_local_path' => isset($data['file_local_path']) ? sanitize_text_field($data['file_local_path']) : '',
            'mime_type' => sanitize_text_field($data['mime_type'] ?? ''),
            'status' => sanitize_key($data['status'] ?? 'uploaded'),
            'indexing_error' => isset($data['indexing_error']) ? sanitize_textarea_field($data['indexing_error']) : '',
            'openai_file_id' => sanitize_text_field($data['openai_file_id'] ?? ''),
            'vector_store_id' => sanitize_text_field($data['vector_store_id'] ?? ''),
            'visibility' => sanitize_key($data['visibility'] ?? 'global'),
            'created_by' => get_current_user_id(),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        return $this->get_document((int) $wpdb->insert_id);
    }

    public function get_document($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . wpsc_table('documents') . " WHERE id = %d", $id), ARRAY_A);
    }

    public function list_documents($limit = 50) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM " . wpsc_table('documents') . " ORDER BY created_at DESC LIMIT %d", min(100, max(1, (int) $limit))), ARRAY_A);
    }

    public function update_document($id, $data) {
        global $wpdb;
        $clean = [];
        foreach (['status', 'openai_file_id', 'vector_store_id', 'indexing_error', 'file_local_path'] as $key) {
            if (isset($data[$key])) {
                $clean[$key] = $key === 'indexing_error' ? sanitize_textarea_field($data[$key]) : sanitize_text_field($data[$key]);
            }
        }
        $clean['updated_at'] = wpsc_now();
        $wpdb->update(wpsc_table('documents'), $clean, ['id' => (int) $id]);
        return $this->get_document((int) $id);
    }

    public function delete_document($id, $delete_file = false) {
        global $wpdb;
        $document = $this->get_document((int) $id);
        if ($delete_file && $document && !empty($document['file_local_path'])) {
            wpsc_delete_local_upload_file($document['file_local_path']);
        }
        return $wpdb->delete(wpsc_table('documents'), ['id' => (int) $id]);
    }

    public function add_event($event_type, $data = [], $conversation_id = null) {
        global $wpdb;
        $wpdb->insert(wpsc_table('events'), [
            'conversation_id' => $conversation_id ? (int) $conversation_id : null,
            'event_type' => sanitize_key($event_type),
            'event_data' => wpsc_json_encode($data),
            'created_at' => wpsc_now(),
        ]);
        return (int) $wpdb->insert_id;
    }

    public function has_event($conversation_id, $event_type) {
        global $wpdb;
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . wpsc_table('events') . " WHERE conversation_id = %d AND event_type = %s LIMIT 1",
            (int) $conversation_id,
            sanitize_key($event_type)
        ));
    }

    public function timed_out_handover_conversations($timeout_seconds, $limit = 25) {
        global $wpdb;
        $timeout_seconds = max(1, (int) $timeout_seconds);
        $limit = min(100, max(1, (int) $limit));
        $cutoff = gmdate('Y-m-d H:i:s', time() - $timeout_seconds);
        $conversations = wpsc_table('conversations');
        $events = wpsc_table('events');

        return $wpdb->get_results($wpdb->prepare(
            "SELECT c.* FROM $conversations c
             WHERE c.status = %s
             AND c.last_message_at <= %s
             AND NOT EXISTS (
                SELECT 1 FROM $events e
                WHERE e.conversation_id = c.id
                AND e.event_type = %s
             )
             ORDER BY c.last_message_at ASC
             LIMIT %d",
            'waiting_human',
            $cutoff,
            'handover_timeout_fallback_sent',
            $limit
        ), ARRAY_A);
    }

    public function list_feedback_events($limit = 20) {
        global $wpdb;
        $events = wpsc_table('events');
        $conversations = wpsc_table('conversations');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT e.*, c.status, c.current_url FROM $events e LEFT JOIN $conversations c ON c.id = e.conversation_id WHERE e.event_type = %s ORDER BY e.created_at DESC LIMIT %d",
            'chat_feedback',
            min(1000, max(1, (int) $limit))
        ), ARRAY_A);
    }

    public function list_bug_report_events($limit = 100) {
        global $wpdb;
        $events = wpsc_table('events');
        $conversations = wpsc_table('conversations');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT e.*, c.status, c.current_url FROM $events e LEFT JOIN $conversations c ON c.id = e.conversation_id WHERE e.event_type = %s ORDER BY e.created_at DESC LIMIT %d",
            'bug_reported',
            min(1000, max(1, (int) $limit))
        ), ARRAY_A);
    }

    public function bug_report_count($limit = 1000) {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . wpsc_table('events') . " WHERE event_type = %s LIMIT %d",
            'bug_reported',
            min(1000, max(1, (int) $limit))
        ));
    }

    public function feedback_counts($limit = 500) {
        $counts = [
            'total_feedback' => 0,
            'positive' => 0,
            'negative' => 0,
            'resolved' => 0,
            'unresolved' => 0,
        ];

        foreach ($this->list_feedback_events($limit) as $event) {
            $data = wpsc_json_decode($event['event_data'] ?? '{}');
            $counts['total_feedback']++;
            if (($data['rating'] ?? '') === 'positive') {
                $counts['positive']++;
            }
            if (($data['rating'] ?? '') === 'negative') {
                $counts['negative']++;
            }
            if (($data['resolved'] ?? '') === 'yes') {
                $counts['resolved']++;
            }
            if (($data['resolved'] ?? '') === 'no') {
                $counts['unresolved']++;
            }
        }

        return $counts;
    }

    public function latest_feedback_by_conversation_ids($conversation_ids) {
        global $wpdb;
        $conversation_ids = array_values(array_unique(array_filter(array_map('intval', (array) $conversation_ids))));
        if (!$conversation_ids) {
            return [];
        }

        $events = wpsc_table('events');
        $placeholders = implode(',', array_fill(0, count($conversation_ids), '%d'));
        $params = array_merge(['chat_feedback'], $conversation_ids);
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $events WHERE event_type = %s AND conversation_id IN ($placeholders) ORDER BY created_at DESC",
            $params
        ), ARRAY_A);
        $latest = [];
        foreach ($rows as $row) {
            $conversation_id = (int) ($row['conversation_id'] ?? 0);
            if (!$conversation_id || isset($latest[$conversation_id])) {
                continue;
            }
            $latest[$conversation_id] = $row;
        }
        return $latest;
    }

    public function dashboard_counts() {
        global $wpdb;
        return [
            'active_chats' => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('conversations') . " WHERE status IN ('bot','human','waiting_human')"),
            'waiting_human' => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('conversations') . " WHERE status = 'waiting_human'"),
            'new_chats' => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('conversations') . " WHERE status = 'bot'"),
            'new_leads' => (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('leads') . " WHERE status = 'new'"),
            'reported_bugs' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . wpsc_table('events') . " WHERE event_type = %s", 'bug_reported')),
            'conversations_today' => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . wpsc_table('conversations') . " WHERE created_at >= %s", gmdate('Y-m-d 00:00:00'))),
        ];
    }

    public function pending_response_count() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . wpsc_table('conversations') . " WHERE status = 'waiting_human'");
    }
}
