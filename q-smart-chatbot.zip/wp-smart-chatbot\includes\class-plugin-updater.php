<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Plugin_Updater {
    const CACHE_KEY = 'wpsc_update_release';
    const CACHE_TTL = 21600;

    public static function init() {
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'check_for_update']);
        add_filter('plugins_api', [__CLASS__, 'plugin_info'], 20, 3);
        add_filter('plugin_action_links_' . WPSC_PLUGIN_BASENAME, [__CLASS__, 'plugin_action_links']);
        add_filter('plugin_row_meta', [__CLASS__, 'plugin_row_meta'], 10, 2);
    }

    public static function plugin_action_links($links) {
        $custom_links = [
            'dashboard' => sprintf(
                '<a href="%1$s">%2$s</a>',
                esc_url(admin_url('admin.php?page=wpsc-dashboard')),
                esc_html__('Dashboard', 'wp-smart-chatbot')
            ),
            'settings' => sprintf(
                '<a href="%1$s">%2$s</a>',
                esc_url(admin_url('admin.php?page=wpsc-settings')),
                esc_html__('Settings', 'wp-smart-chatbot')
            ),
        ];

        return array_merge($custom_links, $links);
    }

    public static function plugin_row_meta($links, $file) {
        if (WPSC_PLUGIN_BASENAME !== $file) {
            return $links;
        }

        foreach ($links as $key => $link) {
            if (false !== strpos($link, 'Visit plugin site')) {
                unset($links[$key]);
            }
        }

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://github.com/' . WPSC_GITHUB_REPO . '/releases'),
            esc_html__('Releases', 'wp-smart-chatbot')
        );

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://github.com/' . WPSC_GITHUB_REPO . '/issues'),
            esc_html__('Support', 'wp-smart-chatbot')
        );

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://qdigital.com.au/'),
            esc_html__('Q Digital', 'wp-smart-chatbot')
        );

        return $links;
    }

    public static function check_for_update($transient) {
        if (empty($transient) || !is_object($transient)) {
            return $transient;
        }

        if (empty($transient->checked) || !isset($transient->checked[WPSC_PLUGIN_BASENAME])) {
            return $transient;
        }

        $release = self::get_latest_release();
        if (!$release || empty($release['version'])) {
            return $transient;
        }

        $update = self::build_update_object($release);

        if (empty($transient->response) || !is_array($transient->response)) {
            $transient->response = [];
        }

        if (empty($transient->no_update) || !is_array($transient->no_update)) {
            $transient->no_update = [];
        }

        if (version_compare($release['version'], WPSC_VERSION, '>')) {
            $transient->response[WPSC_PLUGIN_BASENAME] = $update;
        } else {
            $transient->no_update[WPSC_PLUGIN_BASENAME] = $update;
        }

        return $transient;
    }

    public static function plugin_info($result, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug) || WPSC_SLUG !== $args->slug) {
            return $result;
        }

        $release = self::get_latest_release();
        if (!$release) {
            return $result;
        }

        $info = new stdClass();
        $info->name = 'Q Digital Smart Chatbot';
        $info->slug = WPSC_SLUG;
        $info->version = $release['version'];
        $info->author = '<a href="https://qdigital.com.au/">Q Digital Marketing</a>';
        $info->homepage = 'https://github.com/' . WPSC_GITHUB_REPO;
        $info->requires = '6.0';
        $info->tested = WPSC_TESTED_UP_TO;
        $info->requires_php = '7.4';
        $info->download_link = $release['download_url'];
        $info->last_updated = $release['published_at'];
        $info->sections = [
            'description' => 'AI chatbot, live chat, canned replies, knowledgebase, lead capture and notifications for WordPress.',
            'changelog' => wp_kses_post(wpautop($release['body'] ? $release['body'] : 'No changelog provided.')),
        ];
        $info->banners = [];
        $info->icons = [
            '1x' => WPSC_PLUGIN_URL . 'assets/admin/images/Q-logo.png',
        ];

        return $info;
    }

    private static function build_update_object($release) {
        $update = new stdClass();
        $update->id = 'github.com/' . WPSC_GITHUB_REPO;
        $update->slug = WPSC_SLUG;
        $update->plugin = WPSC_PLUGIN_BASENAME;
        $update->new_version = $release['version'];
        $update->url = 'https://github.com/' . WPSC_GITHUB_REPO;
        $update->package = $release['download_url'];
        $update->tested = WPSC_TESTED_UP_TO;
        $update->requires_php = '7.4';
        $update->icons = [
            '1x' => WPSC_PLUGIN_URL . 'assets/admin/images/Q-logo.png',
        ];

        return $update;
    }

    private static function get_latest_release() {
        $cached = get_site_transient(self::CACHE_KEY);
        if (false !== $cached) {
            return $cached;
        }

        $response = wp_remote_get(WPSC_RELEASE_API, [
            'timeout' => 15,
            'headers' => [
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Q-Smart-Chatbot/' . WPSC_VERSION . '; ' . home_url('/'),
            ],
        ]);

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data) || empty($data['tag_name'])) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        if (!self::has_release_asset($data)) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        $version = ltrim($data['tag_name'], 'vV');
        $release = [
            'version' => $version,
            'download_url' => self::get_package_url($version),
            'published_at' => !empty($data['published_at']) ? $data['published_at'] : '',
            'body' => !empty($data['body']) ? $data['body'] : '',
        ];

        set_site_transient(self::CACHE_KEY, $release, self::CACHE_TTL);

        return $release;
    }

    private static function has_release_asset($data) {
        if (!empty($data['assets']) && is_array($data['assets'])) {
            foreach ($data['assets'] as $asset) {
                if (!empty($asset['name']) && WPSC_PACKAGE_NAME === $asset['name'] && !empty($asset['browser_download_url'])) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function get_package_url($version) {
        return sprintf(
            'https://raw.githubusercontent.com/%1$s/v%2$s/%3$s',
            WPSC_GITHUB_REPO,
            rawurlencode($version),
            WPSC_PACKAGE_NAME
        );
    }
}
