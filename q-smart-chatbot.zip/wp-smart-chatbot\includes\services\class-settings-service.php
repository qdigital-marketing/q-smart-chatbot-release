<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Settings_Service {
    const OPTION = 'wpsc_settings';

    public static function ensure_defaults() {
        $existing = get_option(self::OPTION, []);
        update_option(self::OPTION, wp_parse_args(is_array($existing) ? $existing : [], wpsc_default_settings()));
    }

    public function all() {
        $settings = get_option(self::OPTION, []);
        return wp_parse_args(is_array($settings) ? $settings : [], wpsc_default_settings());
    }

    public function get($key, $default = null) {
        $settings = $this->all();
        return array_key_exists($key, $settings) ? $settings[$key] : $default;
    }

    public function update($data) {
        $current = $this->all();
        $allowed = array_keys(wpsc_default_settings());

        foreach ($allowed as $key) {
            if (!array_key_exists($key, $data)) {
                continue;
            }

            if (in_array($key, ['greeting', 'offline_greeting', 'fallback_message', 'handover_connecting_message', 'handover_requested_message', 'handover_unavailable_message', 'custom_instructions', 'welcome_nudge_text', 'welcome_screen_message', 'feedback_confirm_title', 'feedback_closed_note', 'feedback_first_question', 'feedback_resolved_question', 'feedback_rating_question', 'feedback_comment_label', 'feedback_saving_message', 'feedback_success_message', 'feedback_error_message'], true)) {
                $current[$key] = sanitize_textarea_field($data[$key]);
            } elseif ($key === 'agent_name_mode') {
                $mode = sanitize_key($data[$key]);
                $current[$key] = in_array($mode, ['team', 'user', 'hidden'], true) ? $mode : wpsc_default_settings()[$key];
            } elseif ($key === 'chat_header_style') {
                $style = sanitize_key($data[$key]);
                $current[$key] = in_array($style, ['brand_bar', 'floating_pill', 'compact_center'], true) ? $style : wpsc_default_settings()[$key];
            } elseif ($key === 'chat_header_logo_shape') {
                $shape = sanitize_key($data[$key]);
                $current[$key] = in_array($shape, ['circle', 'square', 'rounded_square', 'rectangle'], true) ? $shape : wpsc_default_settings()[$key];
            } elseif ($key === 'chat_header_logo_fit') {
                $fit = sanitize_key($data[$key]);
                $current[$key] = in_array($fit, ['contain', 'cover'], true) ? $fit : wpsc_default_settings()[$key];
            } elseif ($key === 'launcher_icon_style') {
                $style = sanitize_key($data[$key]);
                $current[$key] = in_array($style, ['message', 'dots', 'logo'], true) ? $style : wpsc_default_settings()[$key];
            } elseif ($key === 'business_days') {
                $days = $data[$key];
                if (!is_array($days)) {
                    $days = trim((string) $days) === '' ? [] : explode(',', (string) $days);
                }
                $days = array_values(array_unique(array_intersect(array_map('intval', $days), [0, 1, 2, 3, 4, 5, 6])));
                $current[$key] = implode(',', $days);
            } elseif ($key === 'featured_canned_response_ids') {
                $ids = is_array($data[$key]) ? $data[$key] : explode(',', (string) $data[$key]);
                $ids = array_filter(array_map('absint', $ids));
                $current[$key] = implode(',', array_slice($ids, 0, 3));
            } elseif (in_array($key, ['business_open_time', 'business_close_time'], true)) {
                $time = sanitize_text_field($data[$key]);
                $current[$key] = preg_match('/^\d{2}:\d{2}$/', $time) ? $time : wpsc_default_settings()[$key];
            } elseif ($key === 'date_format') {
                $format = sanitize_text_field($data[$key]);
                $current[$key] = array_key_exists($format, wpsc_datetime_format_options()) ? $format : wpsc_default_settings()[$key];
            } elseif ($key === 'custom_forms') {
                $current[$key] = wpsc_json_encode($this->sanitize_custom_forms($data[$key]));
            } elseif (in_array($key, ['header_logo_url', 'notification_webhook_url'], true)) {
                $current[$key] = esc_url_raw($data[$key]);
            } elseif ($key === 'card_default_style') {
                $style = sanitize_key($data[$key]);
                $current[$key] = in_array($style, ['split', 'cover'], true) ? $style : wpsc_default_settings()[$key];
            } elseif ($key === 'card_default_text_position') {
                $position = sanitize_key($data[$key]);
                $current[$key] = in_array($position, ['bottom', 'center'], true) ? $position : wpsc_default_settings()[$key];
            } elseif ($key === 'card_default_image_shape') {
                $shape = sanitize_key($data[$key]);
                $current[$key] = in_array($shape, ['landscape', 'square', 'portrait'], true) ? $shape : wpsc_default_settings()[$key];
            } elseif ($key === 'card_default_overlay_opacity') {
                $current[$key] = (string) min(100, max(0, (int) $data[$key]));
            } elseif ($key === 'typing_delay') {
                $current[$key] = (string) min(10000, max(0, (int) $data[$key]));
            } elseif ($key === 'media_retention_days') {
                $current[$key] = (string) min(3650, max(0, (int) $data[$key]));
            } elseif ($key === 'chat_header_logo_size') {
                $current[$key] = (string) min(96, max(24, (int) $data[$key]));
            } elseif ($key === 'delete_data_on_uninstall') {
                $current[$key] = empty($data[$key]) ? '0' : '1';
                update_option('wpsc_delete_data_on_uninstall', $current[$key]);
            } elseif (in_array($key, ['lead_email', 'support_email', 'business_email'], true)) {
                $current[$key] = sanitize_email($data[$key]);
            } elseif (strpos($key, 'color') !== false) {
                $current[$key] = sanitize_hex_color($data[$key]) ?: wpsc_default_settings()[$key];
            } elseif ($key === 'openai_api_key') {
                $incoming = trim((string) $data[$key]);
                if ($incoming && strpos($incoming, '***') === false) {
                    $current[$key] = $this->encrypt_secret($incoming);
                }
            } else {
                $current[$key] = sanitize_text_field($data[$key]);
            }
        }

        update_option(self::OPTION, $current);
        return $this->all();
    }

    public function custom_forms() {
        return $this->sanitize_custom_forms(wpsc_json_decode($this->get('custom_forms', '[]')));
    }

    public function save_custom_form($form) {
        $forms = $this->custom_forms();
        $clean = $this->sanitize_custom_form($form);
        if (empty($clean['id'])) {
            $clean['id'] = 'custom_' . substr(md5((string) microtime(true) . wp_rand()), 0, 10);
        }

        $updated = false;
        foreach ($forms as $index => $existing) {
            if ($existing['id'] === $clean['id']) {
                $forms[$index] = $clean;
                $updated = true;
                break;
            }
        }
        if (!$updated) {
            $forms[] = $clean;
        }

        $settings = $this->all();
        $settings['custom_forms'] = wpsc_json_encode($forms);
        update_option(self::OPTION, $settings);
        return $clean;
    }

    public function delete_custom_form($id) {
        $id = sanitize_key($id);
        $forms = array_values(array_filter($this->custom_forms(), function ($form) use ($id) {
            return $form['id'] !== $id;
        }));
        $settings = $this->all();
        $settings['custom_forms'] = wpsc_json_encode($forms);
        update_option(self::OPTION, $settings);
    }

    public function public_config(WPSC_Repository $repository) {
        $settings = $this->all();
        $business_name = $settings['business_name'];
        $availability = $this->availability($settings);

        return [
            'enabled' => $settings['enabled'] === '1',
            'businessName' => $business_name,
            'businessPhone' => $settings['business_phone'],
            'businessEmail' => $settings['business_email'],
            'businessAddress' => $settings['business_address'],
            'botName' => $settings['bot_name'],
            'agentNameMode' => $settings['agent_name_mode'],
            'agentDisplayName' => $settings['agent_display_name'] ?: wpsc_default_settings()['agent_display_name'],
            'greeting' => str_replace('{business_name}', $business_name, $settings['greeting']),
            'offlineGreeting' => $settings['offline_greeting'],
            'handoverConnectingMessage' => $settings['handover_connecting_message'],
            'handoverRequestedMessage' => $settings['handover_requested_message'],
            'handoverUnavailableMessage' => $settings['handover_unavailable_message'],
            'businessHoursEnabled' => $settings['business_hours_enabled'] === '1',
            'offlineAutoFormEnabled' => $settings['offline_auto_form_enabled'] === '1',
            'isBusinessOnline' => $availability['is_online'],
            'businessStatusText' => $availability['status_text'],
            'businessTimezone' => $settings['business_timezone'],
            'headerLogoUrl' => $settings['header_logo_url'],
            'chatHeaderStyle' => $settings['chat_header_style'],
            'chatHeaderLogoShape' => $settings['chat_header_logo_shape'],
            'chatHeaderLogoSize' => (int) $settings['chat_header_logo_size'],
            'chatHeaderLogoFit' => $settings['chat_header_logo_fit'],
            'chatHeaderShowName' => $settings['chat_header_show_name'] === '1',
            'chatHeaderShowStatus' => $settings['chat_header_show_status'] === '1',
            'launcherIconStyle' => $settings['launcher_icon_style'],
            'launcherColor' => $settings['launcher_color'] ?: $settings['primary_color'],
            'welcomeNudgeEnabled' => $settings['welcome_nudge_enabled'] === '1',
            'welcomeNudgeDelay' => (int) $settings['welcome_nudge_delay'],
            'welcomeNudgeText' => str_replace('{business_name}', $business_name, $settings['welcome_nudge_text']),
            'welcomeScreenEnabled' => $settings['welcome_screen_enabled'] === '1',
            'welcomeScreenTitle' => str_replace('{business_name}', $business_name, $settings['welcome_screen_title']),
            'welcomeScreenSubtitle' => str_replace('{business_name}', $business_name, $settings['welcome_screen_subtitle']),
            'welcomeScreenCardTitle' => str_replace('{business_name}', $business_name, $settings['welcome_screen_card_title']),
            'welcomeScreenMessage' => str_replace('{business_name}', $business_name, $settings['welcome_screen_message']),
            'welcomeScreenButtonText' => $settings['welcome_screen_button_text'],
            'feedbackEnabled' => $settings['feedback_enabled'] === '1',
            'feedbackConfirmCloseEnabled' => $settings['feedback_confirm_close_enabled'] === '1',
            'feedbackConfirmTitle' => $settings['feedback_confirm_title'],
            'feedbackConfirmButtonLabel' => $settings['feedback_confirm_button_label'],
            'feedbackClosedNote' => $settings['feedback_closed_note'],
            'feedbackFirstQuestion' => $settings['feedback_first_question'],
            'feedbackResolvedQuestion' => $settings['feedback_resolved_question'],
            'feedbackRatingQuestion' => $settings['feedback_rating_question'],
            'feedbackCommentLabel' => $settings['feedback_comment_label'],
            'feedbackYesLabel' => $settings['feedback_yes_label'],
            'feedbackNoLabel' => $settings['feedback_no_label'],
            'feedbackPositiveLabel' => $settings['feedback_positive_label'],
            'feedbackNegativeLabel' => $settings['feedback_negative_label'],
            'feedbackSubmitLabel' => $settings['feedback_submit_label'],
            'feedbackSkipLabel' => $settings['feedback_skip_label'],
            'feedbackSavingMessage' => $settings['feedback_saving_message'],
            'feedbackSuccessMessage' => $settings['feedback_success_message'],
            'feedbackErrorMessage' => $settings['feedback_error_message'],
            'fallbackMessage' => $settings['fallback_message'],
            'primaryColor' => $settings['primary_color'],
            'secondaryColor' => $settings['secondary_color'],
            'textColor' => $settings['text_color'],
            'backgroundColor' => $settings['background_color'],
            'cardDefaultStyle' => $settings['card_default_style'],
            'cardDefaultTextColor' => $settings['card_default_text_color'],
            'cardDefaultBackgroundColor' => $settings['card_default_background_color'],
            'cardDefaultOverlayOpacity' => (int) $settings['card_default_overlay_opacity'],
            'cardDefaultTextPosition' => $settings['card_default_text_position'],
            'cardDefaultImageShape' => $settings['card_default_image_shape'],
            'carouselButtonBgColor' => $settings['carousel_button_bg_color'],
            'carouselButtonTextColor' => $settings['carousel_button_text_color'],
            'carouselButtonRadius' => (int) $settings['carousel_button_radius'],
            'position' => $settings['position'],
            'autoOpenDelay' => (int) $settings['auto_open_delay'],
            'typingDelay' => (int) $settings['typing_delay'],
            'handoverTimeout' => (int) $settings['handover_timeout'],
            'quickRepliesEnabled' => $settings['quick_replies_enabled'] === '1',
            'mediaUploadsEnabled' => $settings['media_uploads_enabled'] === '1',
            'mediaUploadImagesEnabled' => $settings['media_upload_images_enabled'] === '1',
            'mediaUploadPdfsEnabled' => $settings['media_upload_pdfs_enabled'] === '1',
            'quickReplies' => array_map(function ($item) {
                $payload = wpsc_json_decode($item['action_payload'] ?? '{}');
                return [
                    'id' => (int) $item['id'],
                    'label' => $item['trigger_label'],
                    'action' => $item['action_type'],
                    'payload' => $payload,
                ];
            }, $this->featured_canned_responses($repository)),
        ];
    }

    public function featured_canned_responses(WPSC_Repository $repository) {
        $ids = array_filter(array_map('absint', explode(',', (string) $this->get('featured_canned_response_ids', ''))));
        $all = $repository->list_canned_responses(true);

        if (!$ids) {
            return array_slice($all, 0, 3);
        }

        $featured = [];
        foreach ($ids as $id) {
            foreach ($all as $item) {
                if ((int) $item['id'] === $id) {
                    $featured[] = $item;
                    break;
                }
            }
        }

        return array_slice($featured ?: $all, 0, 3);
    }

    public function availability($settings = null) {
        $settings = $settings ?: $this->all();

        if (($settings['business_hours_enabled'] ?? '0') !== '1') {
            return [
                'is_online' => true,
                'status_text' => __('Live handover availability is not restricted by business hours.', 'wp-smart-chatbot'),
            ];
        }

        try {
            $timezone = new DateTimeZone($settings['business_timezone'] ?: wp_timezone_string());
        } catch (Exception $exception) {
            $timezone = wp_timezone();
        }

        $now = new DateTime('now', $timezone);
        $day = (int) $now->format('w');
        $days = array_map('intval', explode(',', (string) ($settings['business_days'] ?? '')));

        $open_time = $settings['business_open_time'] ?? '09:00';
        $close_time = $settings['business_close_time'] ?? '17:00';
        $open = DateTime::createFromFormat('Y-m-d H:i', $now->format('Y-m-d') . ' ' . $open_time, $timezone);
        $close = DateTime::createFromFormat('Y-m-d H:i', $now->format('Y-m-d') . ' ' . $close_time, $timezone);
        $is_overnight = $open && $close && $close <= $open;

        if ($is_overnight && $close) {
            $close->modify('+1 day');
        }

        $is_online = in_array($day, $days, true) && $open && $close && $now >= $open && $now <= $close;

        if (!$is_online && $is_overnight) {
            $yesterday = (clone $now)->modify('-1 day');
            $previous_day = (int) $yesterday->format('w');
            $previous_open = DateTime::createFromFormat('Y-m-d H:i', $yesterday->format('Y-m-d') . ' ' . $open_time, $timezone);
            $previous_close = DateTime::createFromFormat('Y-m-d H:i', $yesterday->format('Y-m-d') . ' ' . $close_time, $timezone);
            if ($previous_close) {
                $previous_close->modify('+1 day');
            }
            $is_online = in_array($previous_day, $days, true) && $previous_open && $previous_close && $now >= $previous_open && $now <= $previous_close;
            if ($is_online) {
                $close = $previous_close;
            }
        }

        return [
            'is_online' => $is_online,
            'status_text' => $is_online
                ? sprintf(__('People are online now until %s %s.', 'wp-smart-chatbot'), $close->format('g:i A'), $settings['business_timezone'])
                : sprintf(__('People are offline right now. Usual hours are %s-%s %s.', 'wp-smart-chatbot'), $settings['business_open_time'], $settings['business_close_time'], $settings['business_timezone']),
        ];
    }

    public function get_openai_api_key() {
        if (defined('WPSC_OPENAI_API_KEY') && WPSC_OPENAI_API_KEY) {
            return WPSC_OPENAI_API_KEY;
        }

        return $this->decrypt_secret($this->get('openai_api_key', ''));
    }

    public function masked_openai_key() {
        if (defined('WPSC_OPENAI_API_KEY') && WPSC_OPENAI_API_KEY) {
            return 'Defined in wp-config.php';
        }

        return wpsc_mask_secret($this->get_openai_api_key());
    }

    public function replace_placeholders($text) {
        $settings = $this->all();
        $replacements = [
            '{business_name}' => $settings['business_name'],
            '{business_phone}' => $settings['business_phone'] ?: __('Not configured', 'wp-smart-chatbot'),
            '{business_email}' => $settings['business_email'] ?: __('Not configured', 'wp-smart-chatbot'),
            '{business_address}' => $settings['business_address'] ?: __('Not configured', 'wp-smart-chatbot'),
            '{business_hours}' => $this->formatted_business_hours($settings),
        ];

        return str_replace(array_keys($replacements), array_values($replacements), (string) $text);
    }

    private function sanitize_custom_forms($forms) {
        if (!is_array($forms)) {
            return [];
        }

        $clean = [];
        foreach ($forms as $form) {
            if (!is_array($form)) {
                continue;
            }
            $item = $this->sanitize_custom_form($form);
            if (!empty($item['name'])) {
                $clean[] = $item;
            }
        }
        return array_slice($clean, 0, 30);
    }

    private function sanitize_custom_form($form) {
        $id = sanitize_key($form['id'] ?? '');
        $name = sanitize_text_field($form['name'] ?? '');
        $submit_label = sanitize_text_field($form['submit_label'] ?? __('Send details', 'wp-smart-chatbot'));
        $service_interest = sanitize_text_field($form['service_interest'] ?? $name);
        $fields = [];

        foreach (($form['fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $label = sanitize_text_field($field['label'] ?? '');
            if ($label === '') {
                continue;
            }
            $key = sanitize_key($field['key'] ?? '');
            if ($key === '') {
                $key = sanitize_key(strtolower(str_replace(' ', '_', $label)));
            }
            $type = sanitize_key($field['type'] ?? 'text');
            if (!in_array($type, ['text', 'email', 'tel', 'textarea', 'select', 'date', 'number'], true)) {
                $type = 'text';
            }
            $raw_options = $field['options'] ?? '';
            $options = is_array($raw_options) ? $raw_options : preg_split('/\r\n|\r|\n/', (string) $raw_options);
            $fields[] = [
                'key' => $key,
                'label' => $label,
                'type' => $type,
                'placeholder' => sanitize_text_field($field['placeholder'] ?? ''),
                'required' => empty($field['required']) ? '0' : '1',
                'options' => array_values(array_filter(array_map('sanitize_text_field', $options))),
            ];
        }

        $has_contact_field = false;
        foreach ($fields as $field) {
            if (in_array($field['type'], ['email', 'tel'], true) || in_array($field['key'], ['email', 'phone', 'mobile', 'telephone'], true)) {
                $has_contact_field = true;
                break;
            }
        }

        if (!$has_contact_field) {
            array_unshift($fields, [
                'key' => 'phone',
                'label' => __('Phone', 'wp-smart-chatbot'),
                'type' => 'tel',
                'placeholder' => __('Phone', 'wp-smart-chatbot'),
                'required' => '0',
                'options' => [],
            ]);
            array_unshift($fields, [
                'key' => 'email',
                'label' => __('Email', 'wp-smart-chatbot'),
                'type' => 'email',
                'placeholder' => __('Email', 'wp-smart-chatbot'),
                'required' => '0',
                'options' => [],
            ]);
        }

        return [
            'id' => $id,
            'name' => $name,
            'service_interest' => $service_interest ?: $name,
            'submit_label' => $submit_label ?: __('Send details', 'wp-smart-chatbot'),
            'fields' => array_slice($fields, 0, 20),
        ];
    }

    private function formatted_business_hours($settings) {
        if (($settings['business_hours_enabled'] ?? '0') !== '1') {
            return __('Business hours are not configured.', 'wp-smart-chatbot');
        }

        $labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        $days = array_map('intval', explode(',', (string) ($settings['business_days'] ?? '')));
        $day_names = [];
        foreach ($days as $day) {
            if (isset($labels[$day])) {
                $day_names[] = $labels[$day];
            }
        }

        return implode(', ', $day_names) . ' ' . ($settings['business_open_time'] ?? '09:00') . '-' . ($settings['business_close_time'] ?? '17:00') . ' ' . ($settings['business_timezone'] ?? '');
    }

    private function encrypt_secret($secret) {
        if (!function_exists('openssl_encrypt')) {
            return base64_encode($secret);
        }

        $key = hash('sha256', wp_salt('auth'), true);
        $iv = substr(hash('sha256', wp_salt('secure_auth'), true), 0, 16);
        return 'enc:' . base64_encode(openssl_encrypt($secret, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv));
    }

    private function decrypt_secret($secret) {
        if (!$secret) {
            return '';
        }

        if (strpos($secret, 'enc:') !== 0) {
            return base64_decode($secret, true) ?: $secret;
        }

        if (!function_exists('openssl_decrypt')) {
            return '';
        }

        $key = hash('sha256', wp_salt('auth'), true);
        $iv = substr(hash('sha256', wp_salt('secure_auth'), true), 0, 16);
        $decoded = base64_decode(substr($secret, 4), true);
        return $decoded ? openssl_decrypt($decoded, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv) : '';
    }
}
