<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_REST_Controller {
    private $settings;
    private $repository;
    private $chat;
    private $rate_limit;

    public function __construct(WPSC_Settings_Service $settings, WPSC_Repository $repository, WPSC_Chat_Service $chat) {
        $this->settings = $settings;
        $this->repository = $repository;
        $this->chat = $chat;
        $this->rate_limit = new WPSC_Rate_Limit_Service();
    }

    public function register_routes() {
        $this->public_route('POST', '/session/start', 'start_session');
        $this->public_route('POST', '/chat/message', 'send_message');
        $this->public_route('GET', '/chat/messages', 'get_messages');
        $this->public_route('POST', '/chat/quick-reply', 'quick_reply');
        $this->public_route('POST', '/lead/capture', 'capture_lead');
        $this->public_route('POST', '/handover/request', 'request_handover');
        $this->public_route('POST', '/chat/feedback', 'submit_feedback');
        $this->public_route('POST', '/chat/image', 'upload_image');
        $this->public_route('POST', '/report/bug', 'report_bug');
        $this->public_route('GET', '/widget/config', 'widget_config');
        $this->public_route('POST', '/events/track', 'track_event');

        $this->admin_route('GET', '/admin/conversations', 'admin_conversations');
        $this->admin_route('GET', '/admin/conversations/(?P<id>\d+)', 'admin_conversation');
        $this->admin_route('POST', '/admin/conversations/(?P<id>\d+)/reply', 'admin_reply');
        $this->admin_route('POST', '/admin/conversations/(?P<id>\d+)/typing', 'admin_typing');
        $this->admin_route('POST', '/admin/conversations/(?P<id>\d+)/lead-request', 'admin_lead_request');
        $this->admin_route('POST', '/admin/conversations/(?P<id>\d+)/form-request', 'admin_form_request');
        $this->admin_route('POST', '/admin/conversations/(?P<id>\d+)/status', 'admin_status');
        $this->admin_route('GET', '/admin/notifications/pending', 'admin_pending_notifications');
        $this->admin_route('GET', '/admin/leads', 'admin_leads');
        $this->admin_route('PATCH', '/admin/leads/(?P<id>\d+)', 'admin_update_lead');
        $this->admin_route('POST', '/admin/documents/upload', 'admin_upload_document');
        $this->admin_route('GET', '/admin/documents', 'admin_documents');
        $this->admin_route('DELETE', '/admin/documents/(?P<id>\d+)', 'admin_delete_document');
        $this->admin_route('GET', '/admin/canned-responses', 'admin_canned_responses');
        $this->admin_route('POST', '/admin/canned-responses', 'admin_save_canned_response');
        $this->admin_route('PATCH', '/admin/canned-responses/(?P<id>\d+)', 'admin_save_canned_response');
        $this->admin_route('DELETE', '/admin/canned-responses/(?P<id>\d+)', 'admin_delete_canned_response');
        $this->admin_route('GET', '/admin/settings', 'admin_get_settings');
        $this->admin_route('PATCH', '/admin/settings', 'admin_save_settings');
        $this->admin_route('POST', '/admin/test-notification', 'admin_test_notification');
    }

    public function start_session(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('session', 40, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        return rest_ensure_response($this->chat->start_session($request->get_json_params() ?: $request->get_params()));
    }

    public function send_message(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('message', 25, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $result = $this->chat->receive_message($request->get_json_params() ?: $request->get_params());
        return is_wp_error($result) ? $result : rest_ensure_response($result);
    }

    public function get_messages(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('poll', 180, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $conversation = $this->public_conversation_from_request($request, true);
        if (is_wp_error($conversation)) {
            return $conversation;
        }
        $conversation_id = (int) $conversation['id'];
        $after = (int) $request->get_param('after');
        $raw_messages = $this->repository->list_messages($conversation_id, $after);
        $last_message_id = $after;
        foreach ($raw_messages as $message) {
            $last_message_id = max($last_message_id, (int) ($message['id'] ?? 0));
        }
        $messages = array_values(array_filter($raw_messages, [$this, 'is_public_chat_message']));

        return rest_ensure_response([
            'messages' => $messages,
            'conversation' => $conversation,
            'typing' => $this->public_typing_status($conversation),
            'last_message_id' => $last_message_id,
        ]);
    }

    public function quick_reply(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('quick_reply', 30, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $result = $this->chat->quick_reply($request->get_json_params() ?: $request->get_params());
        return is_wp_error($result) ? $result : rest_ensure_response($result);
    }

    public function capture_lead(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('lead', 10, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $data = $this->normalise_lead_contact_fields($request->get_json_params() ?: $request->get_params());
        if (empty($data['email']) && empty($data['phone'])) {
            return new WP_Error('wpsc_lead_contact_required', __('Please provide an email address or phone number.', 'wp-smart-chatbot'), ['status' => 400]);
        }
        if (!empty($data['conversation_id'])) {
            $conversation = $this->public_conversation_from_request($request, true);
            if (is_wp_error($conversation)) {
                return $conversation;
            }
            $data['conversation_id'] = (int) $conversation['id'];
        }
        return rest_ensure_response($this->chat->capture_lead($data));
    }

    public function request_handover(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('handover', 10, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $conversation = $this->public_conversation_from_request($request, true);
        if (is_wp_error($conversation)) {
            return $conversation;
        }
        $result = $this->chat->request_handover((int) $conversation['id']);
        return is_wp_error($result) ? $result : rest_ensure_response($result);
    }

    public function submit_feedback(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('feedback', 8, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }

        $conversation = $this->public_conversation_from_request($request, true);
        if (is_wp_error($conversation)) {
            return $conversation;
        }

        $data = $request->get_json_params() ?: $request->get_params();
        $allowed_values = ['yes', 'no'];
        $allowed_ratings = ['positive', 'negative'];
        $first_time = sanitize_key($data['first_time'] ?? '');
        $resolved = sanitize_key($data['resolved'] ?? '');
        $rating = sanitize_key($data['rating'] ?? '');

        if (!in_array($first_time, $allowed_values, true) || !in_array($resolved, $allowed_values, true) || !in_array($rating, $allowed_ratings, true)) {
            return new WP_Error('wpsc_feedback_required', __('Please complete the required feedback fields.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $feedback = [
            'first_time' => $first_time,
            'resolved' => $resolved,
            'rating' => $rating,
            'comment' => sanitize_textarea_field($data['comment'] ?? ''),
            'current_url' => esc_url_raw($data['current_url'] ?? ''),
            'user_agent' => sanitize_text_field(substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)),
        ];

        $event_id = $this->repository->add_event('chat_feedback', $feedback, (int) $conversation['id']);
        $summary = sprintf(
            'Chat feedback: first time: %s; resolved: %s; rating: %s%s',
            $first_time,
            $resolved,
            $rating,
            $feedback['comment'] ? '; comment: ' . $feedback['comment'] : ''
        );
        $this->repository->add_message((int) $conversation['id'], 'system', $summary, [
            'message_type' => 'feedback',
            'metadata' => $feedback,
            'is_private_note' => true,
        ]);
        $this->repository->update_conversation((int) $conversation['id'], ['status' => 'closed']);

        return rest_ensure_response(['event_id' => $event_id, 'saved' => true]);
    }

    public function upload_image(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('media_upload', 6, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }

        $allow_images = $this->settings->get('media_upload_images_enabled', '1') === '1';
        $allow_pdfs = $this->settings->get('media_upload_pdfs_enabled', '1') === '1';
        if ($this->settings->get('media_uploads_enabled', '1') !== '1' || (!$allow_images && !$allow_pdfs)) {
            return new WP_Error('wpsc_media_uploads_disabled', __('Media uploads are not enabled for this chatbot.', 'wp-smart-chatbot'), ['status' => 403]);
        }

        $conversation = $this->public_conversation_from_request($request, true);
        if (is_wp_error($conversation)) {
            return $conversation;
        }

        if (empty($_FILES['file'])) {
            return new WP_Error('wpsc_missing_media', __('Please choose a JPG, PNG, or PDF file to upload.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $file = $_FILES['file'];
        if (!empty($file['size']) && (int) $file['size'] > 5 * 1024 * 1024) {
            return new WP_Error('wpsc_media_too_large', __('Uploads must be 5 MB or smaller.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $allowed = [];
        if ($allow_images) {
            $allowed['jpg'] = 'image/jpeg';
            $allowed['jpeg'] = 'image/jpeg';
            $allowed['png'] = 'image/png';
        }
        if ($allow_pdfs) {
            $allowed['pdf'] = 'application/pdf';
        }
        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $allowed);
        if (empty($check['ext']) || empty($check['type']) || !in_array($check['type'], array_values($allowed), true)) {
            return new WP_Error('wpsc_media_type_blocked', sprintf(__('Only %s files can be uploaded.', 'wp-smart-chatbot'), $this->allowed_media_label($allow_images, $allow_pdfs)), ['status' => 400]);
        }

        $base = wpsc_chat_media_base();
        if (!$base) {
            return new WP_Error('wpsc_media_upload_unavailable', __('Chat media storage is not available.', 'wp-smart-chatbot'), ['status' => 500]);
        }
        wpsc_clear_old_chat_media((int) $this->settings->get('media_retention_days', '30'));
        $subdir = gmdate('Y/m');
        $target_dir = trailingslashit($base['dir']) . $subdir;
        if (!wp_mkdir_p($target_dir)) {
            return new WP_Error('wpsc_media_upload_unavailable', __('Could not create the chatbot media folder.', 'wp-smart-chatbot'), ['status' => 500]);
        }
        $filename = wp_unique_filename($target_dir, sanitize_file_name($file['name']));
        $target_path = trailingslashit($target_dir) . $filename;
        if (!@move_uploaded_file($file['tmp_name'], $target_path)) {
            return new WP_Error('wpsc_media_upload_failed', __('The file could not be saved.', 'wp-smart-chatbot'), ['status' => 400]);
        }
        @chmod($target_path, 0644);

        $url = esc_url_raw(trailingslashit($base['url']) . $subdir . '/' . rawurlencode($filename));
        $attachment_type = strpos($check['type'], 'image/') === 0 ? 'image' : 'pdf';
        $label = $attachment_type === 'image' ? __('Image attachment', 'wp-smart-chatbot') : __('PDF attachment', 'wp-smart-chatbot');
        $message = $this->repository->add_message((int) $conversation['id'], 'visitor', '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($label) . '</a>', [
            'message_type' => $attachment_type,
            'metadata' => [
                'attachment_type' => $attachment_type,
                'file_url' => $url,
                'image_url' => $attachment_type === 'image' ? $url : '',
                'file_name' => $filename,
                'mime_type' => sanitize_text_field($check['type']),
                'local_path' => $target_path,
            ],
        ]);
        $this->repository->update_conversation((int) $conversation['id'], ['status' => 'waiting_human']);

        return rest_ensure_response([
            'message_id' => (int) ($message['id'] ?? 0),
            'file_url' => $url,
            'image_url' => $attachment_type === 'image' ? $url : '',
            'attachment_type' => $attachment_type,
            'file_name' => $filename,
        ]);
    }

    private function allowed_media_label($allow_images, $allow_pdfs) {
        if ($allow_images && $allow_pdfs) {
            return __('JPG, PNG, and PDF', 'wp-smart-chatbot');
        }

        if ($allow_images) {
            return __('JPG and PNG image', 'wp-smart-chatbot');
        }

        return __('PDF', 'wp-smart-chatbot');
    }

    public function report_bug(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('bug_report', 8, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $data = $request->get_json_params() ?: $request->get_params();
        $conversation_id = isset($data['conversation_id']) ? (int) $data['conversation_id'] : null;
        if ($conversation_id) {
            $conversation = $this->public_conversation_from_request($request, true);
            if (is_wp_error($conversation)) {
                return $conversation;
            }
            $conversation_id = (int) $conversation['id'];
        }
        $event_id = $this->repository->add_event('bug_reported', [
            'reason' => sanitize_text_field($data['reason'] ?? ''),
            'comment' => sanitize_textarea_field($data['comment'] ?? ''),
            'current_url' => esc_url_raw($data['current_url'] ?? ''),
        ], $conversation_id);
        return rest_ensure_response(['event_id' => $event_id]);
    }

    public function widget_config() {
        return rest_ensure_response($this->settings->public_config($this->repository));
    }

    public function track_event(WP_REST_Request $request) {
        $rate = $this->rate_limit->check('event', 120, 60);
        if (is_wp_error($rate)) {
            return $rate;
        }
        $data = $request->get_json_params() ?: $request->get_params();
        $conversation_id = isset($data['conversation_id']) ? (int) $data['conversation_id'] : null;
        if ($conversation_id) {
            $conversation = $this->public_conversation_from_request($request, true);
            if (is_wp_error($conversation)) {
                return $conversation;
            }
            $conversation_id = (int) $conversation['id'];
        }
        $event_data = [];
        if (!empty($data['event_data']) && is_array($data['event_data'])) {
            foreach (array_slice($data['event_data'], 0, 20, true) as $key => $value) {
                if (is_scalar($value)) {
                    $event_data[sanitize_key($key)] = sanitize_text_field(substr((string) $value, 0, 500));
                }
            }
        }
        $event_id = $this->repository->add_event(
            sanitize_key($data['event_type'] ?? 'widget_event'),
            $event_data,
            $conversation_id
        );
        return rest_ensure_response(['event_id' => $event_id]);
    }

    public function admin_conversations(WP_REST_Request $request) {
        $conversations = $this->repository->list_conversations([
            'status' => $request->get_param('status'),
            'limit' => $request->get_param('limit') ?: 50,
        ]);

        return rest_ensure_response(array_map([$this, 'format_conversation_for_admin'], $conversations));
    }

    public function admin_conversation(WP_REST_Request $request) {
        $id = (int) $request['id'];
        $after = (int) $request->get_param('after');
        $conversation = $this->repository->get_conversation($id);
        if (!$conversation) {
            return new WP_Error('wpsc_conversation_missing', __('Conversation not found.', 'wp-smart-chatbot'), ['status' => 404]);
        }
        $lead = !empty($conversation['lead_id']) ? $this->repository->get_lead((int) $conversation['lead_id']) : null;

        return rest_ensure_response([
            'conversation' => $this->format_conversation_for_admin($conversation),
            'lead' => $lead ? $this->format_lead_for_admin($lead) : null,
            'messages' => array_map([$this, 'format_message_for_admin'], $this->repository->list_messages($id, $after)),
            'pending_count' => $this->repository->pending_response_count(),
        ]);
    }

    public function admin_reply(WP_REST_Request $request) {
        $message = sanitize_textarea_field($request->get_param('message'));
        if (!$message) {
            return new WP_Error('wpsc_empty_reply', __('Reply cannot be empty.', 'wp-smart-chatbot'), ['status' => 400]);
        }
        $id = (int) $request['id'];
        $agent_name = sanitize_text_field($request->get_param('agent_name'));
        if (!$agent_name) {
            $agent_name = $this->default_agent_display_name();
        }
        $this->repository->update_conversation($id, ['status' => 'human']);
        $created = $this->repository->add_message($id, 'agent', $message, [
            'sender_id' => get_current_user_id(),
            'metadata' => [
                'agent_name' => $agent_name,
                'agent_name_mode' => $this->settings->get('agent_name_mode', 'team'),
            ],
        ]);
        delete_transient($this->typing_transient_key($id));

        return rest_ensure_response($this->format_message_for_admin($created));
    }

    public function admin_typing(WP_REST_Request $request) {
        $id = (int) $request['id'];
        $conversation = $this->repository->get_conversation($id);
        if (!$conversation) {
            return new WP_Error('wpsc_conversation_missing', __('Conversation not found.', 'wp-smart-chatbot'), ['status' => 404]);
        }

        $active = filter_var($request->get_param('active'), FILTER_VALIDATE_BOOLEAN);
        if (!$active) {
            delete_transient($this->typing_transient_key($id));
            return rest_ensure_response(['active' => false]);
        }

        $agent_name = sanitize_text_field((string) $request->get_param('agent_name'));
        if (!$agent_name) {
            $agent_name = sanitize_text_field($this->settings->get('agent_display_name', 'Customer Support Team'));
        }
        if (!$agent_name) {
            $agent_name = __('Customer Support Team', 'wp-smart-chatbot');
        }

        $typing = [
            'active' => true,
            'agent_name' => $agent_name,
            'expires_at' => time() + 8,
        ];
        set_transient($this->typing_transient_key($id), $typing, 10);

        return rest_ensure_response($typing);
    }

    public function admin_lead_request(WP_REST_Request $request) {
        $request->set_param('form_type', 'lead');
        return $this->admin_form_request($request);
    }

    public function admin_form_request(WP_REST_Request $request) {
        $id = (int) $request['id'];
        $conversation = $this->repository->get_conversation($id);
        if (!$conversation) {
            return new WP_Error('wpsc_conversation_missing', __('Conversation not found.', 'wp-smart-chatbot'), ['status' => 404]);
        }

        $type = sanitize_key($request->get_param('form_type') ?: 'lead');
        $forms = $this->admin_form_request_types();
        if (empty($forms[$type])) {
            return new WP_Error('wpsc_invalid_form_type', __('Invalid form request type.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $message = sanitize_textarea_field($request->get_param('message'));
        if (!$message) {
            $message = $forms[$type]['message'];
        }

        $this->repository->update_conversation($id, ['status' => 'human']);
        $created = $this->repository->add_message($id, 'bot', $message, [
            'sender_id' => get_current_user_id(),
            'metadata' => [
                'action_type' => 'ask_contact',
                'form_type' => $forms[$type]['form_type'] ?? $type,
                'form_label' => $forms[$type]['label'],
                'custom_form' => $forms[$type]['custom_form'] ?? null,
                'source' => 'agent_form_request',
            ],
        ]);
        $this->repository->add_event('agent_requested_' . $type . '_details', ['message_id' => $created['id']], $id);

        return rest_ensure_response($this->format_message_for_admin($created));
    }

    private function admin_form_request_types() {
        $forms = [
            'lead' => [
                'label' => __('Lead details form', 'wp-smart-chatbot'),
                'service_interest' => 'General lead capture',
                'message' => __('Please leave your name, email, phone number, and a short message so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'order' => [
                'label' => __('Order details form', 'wp-smart-chatbot'),
                'service_interest' => 'Order details',
                'message' => __('Please leave your contact details and order information so the team can check it manually.', 'wp-smart-chatbot'),
            ],
            'service' => [
                'label' => __('Service enquiry form', 'wp-smart-chatbot'),
                'service_interest' => 'Service enquiry',
                'message' => __('Please leave your contact details and the service you need so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'booking' => [
                'label' => __('Booking details form', 'wp-smart-chatbot'),
                'service_interest' => 'Booking details',
                'message' => __('Please leave your contact details and preferred booking information so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'accommodation' => [
                'label' => __('Accommodation enquiry form', 'wp-smart-chatbot'),
                'service_interest' => 'Accommodation enquiry',
                'message' => __('Please leave your contact details, preferred dates, and accommodation requirements so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'finance' => [
                'label' => __('Finance enquiry form', 'wp-smart-chatbot'),
                'service_interest' => 'Finance enquiry',
                'message' => __('Please leave your contact details and finance enquiry so the team can follow up.', 'wp-smart-chatbot'),
            ],
            'support' => [
                'label' => __('Support ticket form', 'wp-smart-chatbot'),
                'service_interest' => 'Support ticket',
                'message' => __('Please leave your contact details and support issue so the team can investigate.', 'wp-smart-chatbot'),
            ],
        ];

        foreach ($this->settings->custom_forms() as $form) {
            $forms['custom_' . $form['id']] = [
                'label' => $form['name'],
                'service_interest' => $form['service_interest'] ?: $form['name'],
                'message' => sprintf(__('Please complete the %s form so the team can follow up.', 'wp-smart-chatbot'), $form['name']),
                'form_type' => 'custom',
                'custom_form' => $form,
            ];
        }

        return $forms;
    }

    public function admin_pending_notifications() {
        return rest_ensure_response([
            'pending_count' => $this->repository->pending_response_count(),
            'conversations' => array_map([$this, 'format_conversation_for_admin'], $this->repository->list_conversations([
                'status' => 'waiting_human',
                'limit' => 10,
            ])),
        ]);
    }

    public function admin_status(WP_REST_Request $request) {
        $status = sanitize_key($request->get_param('status'));
        if (!in_array($status, ['open', 'bot', 'waiting_human', 'human', 'offline', 'closed'], true)) {
            return new WP_Error('wpsc_invalid_status', __('Invalid conversation status.', 'wp-smart-chatbot'), ['status' => 400]);
        }
        $this->repository->update_conversation((int) $request['id'], ['status' => $status]);
        return rest_ensure_response($this->format_conversation_for_admin($this->repository->get_conversation((int) $request['id'])));
    }

    public function admin_leads() {
        return rest_ensure_response(array_map([$this, 'format_lead_for_admin'], $this->repository->list_leads()));
    }

    public function admin_update_lead(WP_REST_Request $request) {
        return rest_ensure_response($this->format_lead_for_admin($this->repository->update_lead((int) $request['id'], $request->get_json_params() ?: $request->get_params())));
    }

    public function admin_upload_document(WP_REST_Request $request) {
        if (empty($_FILES['file'])) {
            return new WP_Error('wpsc_missing_file', __('Please upload a file.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $allowed = [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'txt' => 'text/plain',
            'md' => 'text/markdown',
            'html' => 'text/html',
            'htm' => 'text/html',
            'csv' => 'text/csv',
            'json' => 'application/json',
        ];

        $file = $_FILES['file'];
        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $allowed);
        if (empty($check['ext']) || empty($check['type'])) {
            return new WP_Error('wpsc_file_type_blocked', __('This document type is not allowed.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        $upload = wp_handle_upload($file, ['test_form' => false, 'mimes' => $allowed]);
        if (isset($upload['error'])) {
            return new WP_Error('wpsc_upload_failed', $upload['error'], ['status' => 400]);
        }

        $document = $this->repository->add_document([
            'title' => sanitize_text_field($request->get_param('title') ?: pathinfo($file['name'], PATHINFO_FILENAME)),
            'file_name' => $file['name'],
            'file_path' => $upload['url'],
            'file_local_path' => $upload['file'],
            'mime_type' => $upload['type'],
            'status' => 'uploaded',
        ]);

        if (!$this->settings->get_openai_api_key()) {
            $document = $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. Add an OpenAI API key in AI Settings, then retry indexing.',
            ]);
            return rest_ensure_response([
                'document' => $document,
                'warning' => 'Document saved locally. OpenAI API key is not configured.',
            ]);
        }

        $path = $upload['file'];
        $indexed = (new WPSC_AI_Service($this->settings))->index_document($path, $file['name']);
        if (is_wp_error($indexed)) {
            $document = $this->repository->update_document((int) $document['id'], [
                'status' => 'uploaded',
                'indexing_error' => 'Saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(),
            ]);
            return rest_ensure_response([
                'document' => $document,
                'warning' => 'Document saved locally. OpenAI indexing failed: ' . $indexed->get_error_message(),
            ]);
        }

        $document = $this->repository->update_document((int) $document['id'], [
            'status' => $indexed['status'] ?? 'processing',
            'indexing_error' => '',
            'openai_file_id' => $indexed['openai_file_id'],
            'vector_store_id' => $indexed['vector_store_id'],
        ]);

        return rest_ensure_response($document);
    }

    public function admin_documents() {
        $this->refresh_processing_documents();
        return rest_ensure_response($this->repository->list_documents());
    }

    public function admin_delete_document(WP_REST_Request $request) {
        $this->repository->delete_document((int) $request['id'], true);
        return rest_ensure_response(['deleted' => true]);
    }

    public function admin_canned_responses() {
        return rest_ensure_response($this->repository->list_canned_responses(false));
    }

    public function admin_save_canned_response(WP_REST_Request $request) {
        $id = isset($request['id']) ? (int) $request['id'] : 0;
        return rest_ensure_response($this->repository->save_canned_response($request->get_json_params() ?: $request->get_params(), $id));
    }

    public function admin_delete_canned_response(WP_REST_Request $request) {
        $this->repository->delete_canned_response((int) $request['id']);
        return rest_ensure_response(['deleted' => true]);
    }

    public function admin_get_settings() {
        $settings = $this->settings->all();
        $settings['openai_api_key'] = $this->settings->masked_openai_key();
        return rest_ensure_response($settings);
    }

    public function admin_save_settings(WP_REST_Request $request) {
        $settings = $this->settings->update($request->get_json_params() ?: $request->get_params());
        $settings['openai_api_key'] = $this->settings->masked_openai_key();
        return rest_ensure_response($settings);
    }

    public function admin_test_notification() {
        $sent = wp_mail($this->settings->get('support_email', get_option('admin_email')), __('Q Digital Chatbot test notification', 'wp-smart-chatbot'), __('This is a test notification from Q Digital Chatbot.', 'wp-smart-chatbot'));
        return rest_ensure_response(['sent' => (bool) $sent]);
    }

    private function public_route($methods, $route, $callback) {
        register_rest_route(WPSC_REST_NAMESPACE, $route, [
            'methods' => $methods,
            'callback' => [$this, $callback],
            'permission_callback' => '__return_true',
        ]);
    }

    private function admin_route($methods, $route, $callback) {
        register_rest_route(WPSC_REST_NAMESPACE, $route, [
            'methods' => $methods,
            'callback' => [$this, $callback],
            'permission_callback' => [$this, 'can_manage'],
        ]);
    }

    public function can_manage() {
        return current_user_can('manage_options');
    }

    private function refresh_processing_documents() {
        if (!$this->settings->get_openai_api_key()) {
            return;
        }

        $ai = new WPSC_AI_Service($this->settings);
        foreach ($this->repository->list_documents(20) as $document) {
            if (($document['status'] ?? '') !== 'processing' || empty($document['openai_file_id']) || empty($document['vector_store_id'])) {
                continue;
            }

            $status = $ai->vector_file_status($document['vector_store_id'], $document['openai_file_id']);
            if (is_wp_error($status)) {
                $this->repository->update_document((int) $document['id'], [
                    'indexing_error' => 'OpenAI status refresh failed: ' . $status->get_error_message(),
                ]);
                continue;
            }

            $this->repository->update_document((int) $document['id'], [
                'status' => $status,
                'indexing_error' => $status === 'failed' ? 'OpenAI reported that indexing failed.' : '',
            ]);
        }
    }

    private function format_conversation_for_admin($conversation) {
        if (!is_array($conversation)) {
            return $conversation;
        }

        foreach (['created_at', 'updated_at', 'last_message_at'] as $field) {
            if (!empty($conversation[$field])) {
                $conversation[$field . '_formatted'] = wpsc_format_datetime($conversation[$field]);
            }
        }

        return $conversation;
    }

    private function format_message_for_admin($message) {
        if (!is_array($message)) {
            return $message;
        }

        if (!empty($message['created_at'])) {
            $message['created_at_formatted'] = wpsc_format_datetime($message['created_at']);
        }

        return $message;
    }

    private function default_agent_display_name() {
        $mode = $this->settings->get('agent_name_mode', 'team');
        if ($mode === 'hidden') {
            return '';
        }
        if ($mode === 'user') {
            $user = wp_get_current_user();
            if ($user && $user->exists()) {
                return sanitize_text_field($user->display_name ?: $user->user_login);
            }
        }

        $name = sanitize_text_field($this->settings->get('agent_display_name'));
        return $name ?: wpsc_default_settings()['agent_display_name'];
    }

    private function format_lead_for_admin($lead) {
        if (!is_array($lead)) {
            return $lead;
        }

        foreach (['created_at', 'updated_at'] as $field) {
            if (!empty($lead[$field])) {
                $lead[$field . '_formatted'] = wpsc_format_datetime($lead[$field]);
            }
        }

        if (!empty($lead['message'])) {
            $lead['message_formatted'] = wpsc_format_date_values_in_text($lead['message']);
        }

        return $lead;
    }

    private function normalise_lead_contact_fields($data) {
        if (!is_array($data)) {
            return [];
        }

        foreach ($data as $key => $value) {
            $clean_key = strtolower((string) $key);
            $clean_value = is_scalar($value) ? trim((string) $value) : '';
            if ($clean_value === '') {
                continue;
            }

            if (empty($data['email']) && strpos($clean_key, 'email') !== false) {
                $data['email'] = $clean_value;
            }

            if (
                empty($data['phone'])
                && (strpos($clean_key, 'phone') !== false || strpos($clean_key, 'mobile') !== false || strpos($clean_key, 'telephone') !== false)
            ) {
                $data['phone'] = $clean_value;
            }
        }

        return $data;
    }

    private function public_conversation_from_request(WP_REST_Request $request, $required = true) {
        $conversation_id = (int) $request->get_param('conversation_id');
        if (!$conversation_id) {
            return $required
                ? new WP_Error('wpsc_missing_conversation', __('Conversation ID is required.', 'wp-smart-chatbot'), ['status' => 400])
                : null;
        }

        $session_id = sanitize_text_field((string) $request->get_param('session_id'));
        $visitor_uuid = sanitize_text_field((string) $request->get_param('visitor_uuid'));
        if (!$session_id || !$visitor_uuid) {
            return new WP_Error('wpsc_missing_session', __('Session details are required.', 'wp-smart-chatbot'), ['status' => 400]);
        }

        $conversation = $this->repository->get_conversation_for_visitor($conversation_id, $session_id, $visitor_uuid);
        if (!$conversation) {
            return new WP_Error('wpsc_conversation_forbidden', __('This conversation does not belong to the current visitor session.', 'wp-smart-chatbot'), ['status' => 403]);
        }

        return $conversation;
    }

    private function typing_transient_key($conversation_id) {
        return 'wpsc_typing_' . (int) $conversation_id;
    }

    private function public_typing_status($conversation) {
        if (!is_array($conversation) || !in_array(($conversation['status'] ?? ''), ['human', 'waiting_human'], true)) {
            return ['active' => false];
        }

        $typing = get_transient($this->typing_transient_key((int) $conversation['id']));
        if (
            !is_array($typing)
            || empty($typing['active'])
            || (int) ($typing['expires_at'] ?? 0) < time()
        ) {
            return ['active' => false];
        }

        return [
            'active' => true,
            'agent_name' => sanitize_text_field($typing['agent_name'] ?? '') ?: __('Customer Support Team', 'wp-smart-chatbot'),
        ];
    }

    public function is_public_chat_message($message) {
        if (!empty($message['is_private_note'])) {
            return false;
        }

        return ($message['sender_type'] ?? '') !== 'system';
    }
}
