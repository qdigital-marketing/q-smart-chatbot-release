<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Rate_Limit_Service {
    public function check($bucket, $limit = 30, $window = 60) {
        $key = 'wpsc_rl_' . md5($bucket . '|' . wpsc_client_ip_hash());
        $now = time();
        $state = get_transient($key);

        if (!is_array($state) || empty($state['reset_at']) || (int) $state['reset_at'] <= $now) {
            $state = [
                'count' => 0,
                'reset_at' => $now + max(1, (int) $window),
            ];
        }

        if ((int) $state['count'] >= $limit) {
            return new WP_Error('wpsc_rate_limited', __('Too many requests. Please slow down and try again.', 'wp-smart-chatbot'), ['status' => 429]);
        }

        $state['count'] = (int) $state['count'] + 1;
        set_transient($key, $state, max(1, (int) $state['reset_at'] - $now));
        return true;
    }
}
