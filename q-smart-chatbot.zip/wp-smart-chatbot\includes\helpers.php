<?php

if (!defined('ABSPATH')) {
    exit;
}

function wpsc_table($name) {
    global $wpdb;
    return $wpdb->prefix . 'wpsc_' . $name;
}

function wpsc_now() {
    return current_time('mysql', true);
}

function wpsc_datetime_format_options() {
    return [
        'd/m/Y g:i A' => '31/12/2026 5:30 PM',
        'd/m/Y H:i' => '31/12/2026 17:30',
        'j M Y, g:i A' => '31 Dec 2026, 5:30 PM',
        'Y-m-d H:i' => '2026-12-31 17:30',
        'm/d/Y g:i A' => '12/31/2026 5:30 PM',
    ];
}

function wpsc_datetime_format() {
    $settings = get_option('wpsc_settings', []);
    $format = is_array($settings) ? ($settings['date_format'] ?? '') : '';
    return array_key_exists($format, wpsc_datetime_format_options()) ? $format : 'd/m/Y g:i A';
}

function wpsc_date_format() {
    $formats = [
        'd/m/Y g:i A' => 'd/m/Y',
        'd/m/Y H:i' => 'd/m/Y',
        'j M Y, g:i A' => 'j M Y',
        'Y-m-d H:i' => 'Y-m-d',
        'm/d/Y g:i A' => 'm/d/Y',
    ];

    $datetime_format = wpsc_datetime_format();
    return $formats[$datetime_format] ?? 'd/m/Y';
}

function wpsc_format_datetime($value, $format = null) {
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }

    try {
        $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        $datetime = new DateTime($value, new DateTimeZone('UTC'));
        return wp_date($format ?: wpsc_datetime_format(), $datetime->getTimestamp(), $timezone);
    } catch (Exception $exception) {
        return $value;
    }
}

function wpsc_format_date_value($value) {
    $value = trim((string) $value);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value;
    }

    try {
        $date = new DateTime($value . ' 00:00:00', new DateTimeZone('UTC'));
        return wp_date(wpsc_date_format(), $date->getTimestamp(), new DateTimeZone('UTC'));
    } catch (Exception $exception) {
        return $value;
    }
}

function wpsc_format_date_values_in_text($text) {
    $lines = [];
    foreach (preg_split('/\r\n|\r|\n/', (string) $text) as $line) {
        $trimmed = trim($line);
        if ($trimmed === '') {
            $lines[] = $line;
            continue;
        }

        if (strpos($trimmed, ':') !== false) {
            [$label, $value] = array_map('trim', explode(':', $trimmed, 2));
            if ($label !== '' && $value !== '') {
                $lines[] = $label . ': ' . wpsc_format_date_value($value);
                continue;
            }
        }

        $lines[] = wpsc_format_date_value($line);
    }

    return implode("\n", $lines);
}

function wpsc_delete_local_upload_file($path) {
    $path = (string) $path;
    if ($path === '') {
        return false;
    }

    $uploads = function_exists('wp_upload_dir') ? wp_upload_dir() : [];
    if (empty($uploads['basedir'])) {
        return false;
    }

    $real_path = realpath($path);
    $upload_base = realpath($uploads['basedir']);
    if (!$real_path || !$upload_base || ($real_path !== $upload_base && strpos($real_path, $upload_base . DIRECTORY_SEPARATOR) !== 0) || !is_file($real_path)) {
        return false;
    }

    return function_exists('wp_delete_file') ? (bool) wp_delete_file($real_path) : @unlink($real_path);
}

function wpsc_chat_media_base() {
    $uploads = function_exists('wp_upload_dir') ? wp_upload_dir() : [];
    if (empty($uploads['basedir']) || empty($uploads['baseurl'])) {
        return null;
    }

    return [
        'dir' => trailingslashit($uploads['basedir']) . 'wpsc-chatbot-media',
        'url' => trailingslashit($uploads['baseurl']) . 'wpsc-chatbot-media',
    ];
}

function wpsc_chat_media_files() {
    $base = wpsc_chat_media_base();
    if (!$base || !is_dir($base['dir'])) {
        return [];
    }

    $base_dir = realpath($base['dir']);
    if (!$base_dir) {
        return [];
    }

    $files = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $path = $file->getPathname();
        $real_path = realpath($path);
        if (!$real_path || ($real_path !== $base_dir && strpos($real_path, $base_dir . DIRECTORY_SEPARATOR) !== 0)) {
            continue;
        }
        $relative = str_replace('\\', '/', ltrim(substr($real_path, strlen($base_dir)), DIRECTORY_SEPARATOR));
        $files[] = [
            'path' => $real_path,
            'name' => basename($real_path),
            'relative' => $relative,
            'url' => trailingslashit($base['url']) . implode('/', array_map('rawurlencode', explode('/', $relative))),
            'size' => filesize($real_path),
            'modified' => filemtime($real_path),
        ];
    }

    usort($files, function ($a, $b) {
        return ($b['modified'] ?? 0) <=> ($a['modified'] ?? 0);
    });
    return $files;
}

function wpsc_clear_old_chat_media($max_age_days) {
    $base = wpsc_chat_media_base();
    $max_age_days = max(0, (int) $max_age_days);
    if (!$base || !is_dir($base['dir']) || $max_age_days < 1) {
        return 0;
    }

    $base_dir = realpath($base['dir']);
    if (!$base_dir) {
        return 0;
    }

    $cutoff = time() - ($max_age_days * DAY_IN_SECONDS);
    $deleted = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($iterator as $item) {
        $real_path = realpath($item->getPathname());
        if (!$real_path || ($real_path !== $base_dir && strpos($real_path, $base_dir . DIRECTORY_SEPARATOR) !== 0)) {
            continue;
        }

        if ($item->isFile() && $item->getMTime() < $cutoff) {
            if (function_exists('wp_delete_file') ? wp_delete_file($real_path) : @unlink($real_path)) {
                $deleted++;
            }
        } elseif ($item->isDir()) {
            @rmdir($real_path);
        }
    }

    return $deleted;
}

function wpsc_clear_chat_media() {
    $base = wpsc_chat_media_base();
    if (!$base || !is_dir($base['dir'])) {
        return 0;
    }

    $base_dir = realpath($base['dir']);
    if (!$base_dir) {
        return 0;
    }

    $deleted = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($iterator as $item) {
        $real_path = realpath($item->getPathname());
        if (!$real_path || ($real_path !== $base_dir && strpos($real_path, $base_dir . DIRECTORY_SEPARATOR) !== 0)) {
            continue;
        }
        if ($item->isFile()) {
            if (function_exists('wp_delete_file') ? wp_delete_file($real_path) : @unlink($real_path)) {
                $deleted++;
            }
        } elseif ($item->isDir()) {
            @rmdir($real_path);
        }
    }

    return $deleted;
}

function wpsc_json_encode($value) {
    $json = wp_json_encode($value);
    return $json ? $json : '{}';
}

function wpsc_json_decode($value, $default = []) {
    if (!is_string($value) || $value === '') {
        return $default;
    }

    $decoded = json_decode($value, true);
    return is_array($decoded) ? $decoded : $default;
}

function wpsc_client_ip_hash() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    return $ip ? hash_hmac('sha256', $ip, wp_salt('auth')) : '';
}

function wpsc_default_settings() {
    return [
        'enabled' => '1',
        'business_name' => get_bloginfo('name'),
        'business_phone' => '',
        'business_email' => get_option('admin_email'),
        'business_address' => '',
        'bot_name' => 'Q Digital Chatbot',
        'agent_name_mode' => 'team',
        'agent_display_name' => 'Customer Support Team',
        'greeting' => 'Hi, welcome to {business_name}. How can I help today?',
        'offline_greeting' => 'Leave your details and the team will get back to you soon.',
        'fallback_message' => 'I am not completely sure about that one. I can pass your question to the team so they can give you the right answer.',
        'handover_connecting_message' => 'Trying to connect you to support...',
        'handover_requested_message' => 'I have let the team know you would like to speak to a person.',
        'handover_unavailable_message' => 'Unfortunately, we cannot connect you right now. Please leave your details so we can get back to you as soon as possible.',
        'business_hours_enabled' => '0',
        'offline_auto_form_enabled' => '1',
        'business_timezone' => function_exists('wp_timezone_string') && wp_timezone_string() ? wp_timezone_string() : 'Australia/Sydney',
        'business_days' => '1,2,3,4,5',
        'business_open_time' => '09:00',
        'business_close_time' => '17:00',
        'date_format' => 'd/m/Y g:i A',
        'header_logo_url' => '',
        'chat_header_style' => 'floating_pill',
        'chat_header_logo_shape' => 'rounded_square',
        'chat_header_logo_size' => '38',
        'chat_header_logo_fit' => 'contain',
        'chat_header_show_name' => '1',
        'chat_header_show_status' => '1',
        'launcher_icon_style' => 'message',
        'launcher_color' => '#1769aa',
        'welcome_nudge_enabled' => '1',
        'welcome_nudge_delay' => '7000',
        'welcome_nudge_text' => 'Welcome back, let us know if you have any questions.',
        'welcome_screen_enabled' => '1',
        'welcome_screen_title' => 'Welcome!',
        'welcome_screen_subtitle' => 'Text us',
        'welcome_screen_card_title' => '{business_name}',
        'welcome_screen_message' => 'Welcome back, let us know if you have any questions.',
        'welcome_screen_button_text' => "Let's chat",
        'feedback_enabled' => '1',
        'feedback_confirm_close_enabled' => '1',
        'feedback_confirm_title' => 'Do you really want to close the chat?',
        'feedback_confirm_button_label' => 'Close the chat',
        'feedback_closed_note' => 'You have closed the chat.',
        'feedback_first_question' => 'Is this the first time you have chatted with us about this case?',
        'feedback_resolved_question' => 'Was the case resolved during the chat?',
        'feedback_rating_question' => 'How would you rate this chat?',
        'feedback_comment_label' => 'Anything else we should know?',
        'feedback_yes_label' => 'Yes',
        'feedback_no_label' => 'No',
        'feedback_positive_label' => 'Positive',
        'feedback_negative_label' => 'Negative',
        'feedback_submit_label' => 'Submit',
        'feedback_skip_label' => 'Skip',
        'feedback_saving_message' => 'Saving feedback...',
        'feedback_success_message' => 'Thanks, your feedback has been saved.',
        'feedback_error_message' => 'Please complete the required fields.',
        'primary_color' => '#1769aa',
        'secondary_color' => '#16a085',
        'text_color' => '#16202a',
        'background_color' => '#ffffff',
        'position' => 'right',
        'auto_open_delay' => '0',
        'typing_delay' => '650',
        'handover_timeout' => '900',
        'lead_email' => get_option('admin_email'),
        'support_email' => get_option('admin_email'),
        'notification_webhook_enabled' => '0',
        'notification_webhook_url' => '',
        'ai_enabled' => '0',
        'openai_api_key' => '',
        'openai_model' => 'gpt-4.1-mini',
        'openai_temperature' => '0.3',
        'openai_max_tokens' => '280',
        'openai_vector_store_id' => '',
        'custom_instructions' => 'Answer as a helpful website receptionist. Keep replies brief and complete, usually 1-3 short paragraphs or bullets. Use the knowledgebase quietly as background context, but never mention uploaded documents, files, file names, citations, source markers, brackets, or knowledgebase references to the visitor. Do not invent prices or availability, and offer human handover when uncertain.',
        'knowledgebase_strict' => '0',
        'quick_replies_enabled' => '1',
        'media_uploads_enabled' => '1',
        'media_upload_images_enabled' => '1',
        'media_upload_pdfs_enabled' => '1',
        'media_retention_days' => '30',
        'delete_data_on_uninstall' => '0',
        'featured_canned_response_ids' => '',
        'canned_enabled' => '1',
        'admin_quick_lead_enabled' => '1',
        'admin_quick_order_enabled' => '1',
        'admin_quick_service_enabled' => '1',
        'admin_quick_booking_enabled' => '1',
        'admin_quick_accommodation_enabled' => '1',
        'admin_quick_finance_enabled' => '1',
        'admin_quick_support_enabled' => '1',
        'custom_forms' => '[]',
        'carousel_button_bg_color' => '#3f6fb6',
        'carousel_button_text_color' => '#ffffff',
        'carousel_button_radius' => '2',
        'card_default_style' => 'split',
        'card_default_text_color' => '#ffffff',
        'card_default_background_color' => '#111827',
        'card_default_overlay_opacity' => '88',
        'card_default_text_position' => 'bottom',
        'card_default_image_shape' => 'square',
    ];
}

function wpsc_mask_secret($secret) {
    $secret = (string) $secret;
    if ($secret === '') {
        return '';
    }

    if (strlen($secret) < 8) {
        return str_repeat('*', 8);
    }

    return substr($secret, 0, 3) . str_repeat('*', max(4, strlen($secret) - 6)) . substr($secret, -3);
}
