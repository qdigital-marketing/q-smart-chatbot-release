<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="wpsc-chatbot-root" class="wpsc-chatbot-root" aria-live="polite"></div>
