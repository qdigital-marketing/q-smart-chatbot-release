<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPSC_Loader {
    public static function register() {
        spl_autoload_register([__CLASS__, 'autoload']);
        self::load_core();
    }

    public static function autoload($class) {
        if (strpos($class, 'WPSC_') !== 0) {
            return;
        }

        $relative = strtolower(str_replace('_', '-', substr($class, 5)));
        $candidates = [
            WPSC_PLUGIN_DIR . 'includes/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/database/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/services/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/api/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/admin/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/public/class-' . $relative . '.php',
            WPSC_PLUGIN_DIR . 'includes/integrations/openai/class-' . $relative . '.php',
        ];

        foreach ($candidates as $file) {
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }

    private static function load_core() {
        $files = [
            'includes/class-activator.php',
            'includes/class-deactivator.php',
            'includes/database/class-schema.php',
            'includes/database/class-repository.php',
            'includes/services/class-settings-service.php',
            'includes/services/class-rate-limit-service.php',
            'includes/services/class-notification-service.php',
            'includes/integrations/openai/class-openai-client.php',
            'includes/services/class-ai-service.php',
            'includes/services/class-chat-service.php',
            'includes/api/class-rest-controller.php',
            'includes/admin/class-admin-menu.php',
            'includes/public/class-public-assets.php',
            'includes/class-plugin-updater.php',
            'includes/class-plugin.php',
        ];

        foreach ($files as $file) {
            require_once WPSC_PLUGIN_DIR . $file;
        }
    }
}
